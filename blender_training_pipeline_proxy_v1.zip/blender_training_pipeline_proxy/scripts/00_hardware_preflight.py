#!/usr/bin/env python3
from __future__ import annotations

import json, os, platform, urllib.request
from pathlib import Path

OUT = Path("reports/environment/hardware-preflight.json")
EXPECTED_SKU = "Standard_NC4as_T4_v3"


def imds() -> dict:
    req = urllib.request.Request(
        "http://169.254.169.254/metadata/instance?api-version=2021-02-01",
        headers={"Metadata": "true"},
    )
    with urllib.request.urlopen(req, timeout=3) as response:
        return json.load(response)


def mem_gib() -> float:
    for line in Path("/proc/meminfo").read_text().splitlines():
        if line.startswith("MemTotal:"):
            return int(line.split()[1]) / 1024 / 1024
    raise RuntimeError("MemTotal not found")


def nvidia_pci() -> list[dict]:
    found = []
    for dev in Path("/sys/bus/pci/devices").glob("*"):
        try:
            vendor = (dev / "vendor").read_text().strip().lower()
            if vendor != "0x10de":
                continue
            found.append({"slot": dev.name, "vendor": vendor, "device": (dev / "device").read_text().strip().lower(), "class": (dev / "class").read_text().strip().lower()})
        except OSError:
            pass
    return found


def main() -> None:
    compute = imds()["compute"]
    cpu = os.cpu_count() or 0
    ram = mem_gib()
    pci = nvidia_pci()
    checks = {
        "azure_sku_exact": compute.get("vmSize") == EXPECTED_SKU,
        "vcpu_exact": cpu == 4,
        "ram_expected_range": 26.0 <= ram <= 30.0,
        "nvidia_pci_visible": len(pci) >= 1,
        "tesla_t4_pci_id_exact": any(dev.get("device") == "0x1eb8" for dev in pci),
    }
    report = {
        "status": "pass" if all(checks.values()) else "fail",
        "checks": checks,
        "azure": {"vmSize": compute.get("vmSize"), "location": compute.get("location"), "name": compute.get("name")},
        "host": {"platform": platform.platform(), "cpu_count": cpu, "ram_gib": round(ram, 3)},
        "nvidia_pci": pci,
        "note": "Pre-driver PCI identity requires NVIDIA 10de:1eb8 (Tesla T4). Exact runtime name/VRAM/UUID are re-verified after GRID installation; no GPU gate may run before both proofs.",
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if report["status"] != "pass":
        raise SystemExit("hardware preflight failed; do not continue installation")


if __name__ == "__main__":
    main()
