# Claude Code Project Instructions — Blender Training Video Pipeline

## Mission
Build short instructional animations deterministically from validated configuration. The source of truth is text config + admitted assets + code. `.blend`, renders, audio cues, and videos are generated artifacts.

## Non-negotiable invariants

1. Use **OmegaConf**, not Hydra, for initial config layering: `base < project < scene < shot < CLI`.
2. Validate the fully resolved object with **Pydantic v2**, then emit immutable `resolved_config.json` plus a SHA-256 hash.
3. Production Blender receives resolved JSON only. Do not import OmegaConf, TTS, Ollama, or orchestration libraries into Blender's embedded Python.
4. No magic production values in builder code. Values come from the resolved config or asset contract.
5. Assets are referenced only by logical IDs from `assets/assets.yaml`.
6. Character performance composes named NLA actions; do not author bespoke raw performance keyframes when a vocabulary action exists.
6a. Proxy/future generated assets follow a style contract and asset spec. Generated `.blend` files are rebuildable outputs, never the editable source of truth.
7. The official Blender MCP is **inspection/debug only**. It must operate on a scratch copy, never the canonical repo build artifact.
8. Do not use MCP-generated scene mutations as deliverables. Diagnose, propose a patch, then modify config/builder code and rebuild.
9. Never assume the GPU. Before GPU work, require `reports/environment/hardware-verified.json` and confirm the live GPU UUID still matches it.
10. Acquire the host GPU lock before Cycles/OptiX, Ollama VLM inference, GPU faster-whisper, or optional GPU TTS.
11. There is **no host CUDA Toolkit dependency**. Do not install `cuda-toolkit`, `nvidia-cuda-toolkit`, or `nvcc`. Driver/runtime libraries inside a container or Python wheel are acceptable when required by that workload.
12. Render final output to EXR/PNG image sequences, never directly to video. FFmpeg/NVENC performs mux/encode.
13. Every QA revision is a **config-only proposal**. A vision model must never patch `bpy` builder code.
14. Cap automated preview-revise iterations; default policy is in config.
15. Use structured handoffs and preserve provenance hashes.

## Runtime boundaries

- Host pipeline: Python 3.11
- `bpy` integration test env: Python 3.13 + `bpy==5.2.1`
- Production Blender: Blender 5.2.1 embedded Python 3.13
- Local visual QA: Docker Ollama, `qwen3-vl:4b-instruct` default
- TTS: Docker Kokoro CPU default; GPU profile optional

## Agent routing

- architecture/schema: `pipeline-architect`
- VM/bootstrap/hardware: `environment-bootstrapper`
- asset creation/regeneration: `asset-factory`
- asset admission: `asset-validator`
- instructional/creative config: `animation-director`
- deterministic bpy code: `blender-builder`
- speech/visemes: `audio-lipsync-engineer`
- live Blender diagnosis: `blender-debugger`
- render/semantic QA: `render-qa`
- safe execution/publishing: `pipeline-runner`

Do not load every skill into every agent. Each agent is intentionally scoped to a small set of skills.
