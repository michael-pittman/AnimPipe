"""Build the generated camera rig entirely from validated configuration."""

from __future__ import annotations

import math
from typing import Any

import bpy

from .context import BuildContext, BuildError, opt, parse_easing, req

_MOVE_CHANNELS: dict[str, tuple[str, int]] = {
    "dolly": ("location", 1),
    "truck": ("location", 0),
    "pedestal": ("location", 2),
    "pan": ("rotation_euler", 2),
    "tilt": ("rotation_euler", 0),
}


def _key(obj: Any, data_path: str, index: int, frame: int, value: float, easing: str) -> None:
    setattr_indexed(obj, data_path, index, value)
    obj.keyframe_insert(data_path=data_path, index=index, frame=frame)
    interpolation, ease = parse_easing(easing)
    fcurve = _find_fcurve(obj, data_path, index)
    if fcurve is None:
        return
    for point in fcurve.keyframe_points:
        if int(point.co[0]) == int(frame):
            point.interpolation = interpolation
            point.easing = ease


def setattr_indexed(obj: Any, data_path: str, index: int, value: float) -> None:
    getattr(obj, data_path)[index] = value


def _find_fcurve(obj: Any, data_path: str, index: int) -> Any | None:
    anim = obj.animation_data
    if anim is None or anim.action is None:
        return None
    for fcurve in _all_fcurves(anim.action):
        if fcurve.data_path == data_path and fcurve.array_index == index:
            return fcurve
    return None


def _all_fcurves(action: Any) -> list[Any]:
    if hasattr(action, "fcurves") and len(action.fcurves):
        return list(action.fcurves)
    curves: list[Any] = []
    for layer in getattr(action, "layers", []):
        for strip in getattr(layer, "strips", []):
            for bag in getattr(strip, "channelbags", []):
                curves.extend(bag.fcurves)
    return curves


def build_camera(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> Any:
    cfg = ctx.cfg
    data = bpy.data.cameras.new("CAM_shot")
    camera = bpy.data.objects.new("CAM_shot", data)
    bpy.context.scene.collection.objects.link(camera)
    bpy.context.scene.camera = camera

    template_name = opt(cfg, "camera.template")
    template = None
    if template_name:
        templates = opt(cfg, "camera.templates", {}) or {}
        template = templates.get(str(template_name))
        if template is None:
            raise BuildError(
                f"camera.template '{template_name}' is not present in camera.templates"
            )

    data.lens = float(template.get("lens_mm") if template else req(cfg, "camera.lens_mm"))
    data.sensor_width = float(
        template.get("sensor_width_mm") if template else req(cfg, "camera.sensor_width_mm")
    )
    data.shift_x = float(template.get("shift_x", 0.0) if template else opt(cfg, "camera.shift_x", 0.0))
    data.shift_y = float(template.get("shift_y", 0.0) if template else opt(cfg, "camera.shift_y", 0.0))

    target_id = opt(cfg, "camera.framing_target")
    target_obj = None
    if target_id:
        handles = cast.get(target_id)
        if handles is None:
            raise BuildError(f"camera.framing_target '{target_id}' is not in this shot's cast")
        target_obj = handles["root"]

    if template:
        offset = tuple(float(v) for v in template["offset"])
        if target_obj is not None:
            origin = target_obj.matrix_world.translation
            camera.location = tuple(origin[i] + offset[i] for i in range(3))
        else:
            camera.location = offset
        camera.rotation_euler = tuple(
            math.radians(float(v)) for v in template.get("rotation_deg", (90.0, 0.0, 0.0))
        )
    else:
        camera.location = tuple(float(v) for v in req(cfg, "camera.initial_location"))
        camera.rotation_euler = tuple(
            math.radians(float(v)) for v in req(cfg, "camera.initial_rotation_deg")
        )

    track_target = target_obj
    if target_obj is not None and template:
        target_offset = tuple(float(v) for v in template.get("target_offset", (0.0, 0.0, 0.0)))
        if any(abs(v) > 1e-9 for v in target_offset):
            aim = bpy.data.objects.new("CAM_subject_target", None)
            bpy.context.scene.collection.objects.link(aim)
            aim.parent = target_obj
            aim.location = target_offset
            track_target = aim

    if track_target is not None and (not template or bool(template.get("track_subject", True))):
        track = camera.constraints.new("TRACK_TO")
        track.target = track_target
        track.track_axis = "TRACK_NEGATIVE_Z"
        track.up_axis = "UP_Y"

    dof = opt(cfg, "camera.dof", {}) or {}
    template_dof = bool(template.get("dof_enabled", False)) if template else False
    data.dof.use_dof = bool(dof.get("enabled", False) or template_dof)
    if data.dof.use_dof:
        data.dof.aperture_fstop = float(
            dof.get("f_stop", template.get("f_stop", 5.6) if template else 5.6)
        )
        focus_id = dof.get("focus_target")
        focus_obj = cast.get(focus_id, {}).get("root") if focus_id else track_target
        if focus_obj is None:
            raise BuildError("camera.dof.enabled is true but no focus target resolved")
        data.dof.focus_object = focus_obj

    _build_move(ctx, camera)
    ctx.assert_that(
        "camera created and set as scene camera",
        bpy.context.scene.camera is camera,
        f"lens {data.lens}mm, dof={data.dof.use_dof}",
    )
    return camera


def _build_move(ctx: BuildContext, camera: Any) -> None:
    move = opt(ctx.cfg, "camera.move", {}) or {}
    move_type = str(move.get("type", "static"))
    duration = int(move.get("duration_frames", 0))
    easing = str(move.get("easing", "BEZIER"))
    start_frame = int(req(ctx.cfg, "render.frame_start"))

    if move_type == "static" or duration <= 0:
        ctx.assert_that("camera move", True, "static")
        return
    if move_type == "orbit":
        orbit_deg = float(req(ctx.cfg, "camera.move_defaults.orbit_deg"))
        _build_orbit(camera, start_frame, duration, easing, orbit_deg)
        ctx.assert_that("camera move", True, f"orbit {orbit_deg}deg over {duration} frames")
        return
    if move_type == "follow_path":
        _build_follow_path(ctx, camera, move, start_frame, duration, easing)
        return

    channel = _MOVE_CHANNELS.get(move_type)
    if channel is None:
        raise BuildError(f"unknown camera.move.type '{move_type}'")
    data_path, index = channel
    configured = move.get("amount")
    amount = float(configured) if configured is not None else _configured_default_amount(ctx, move_type)
    origin = getattr(camera, data_path)[index]
    _key(camera, data_path, index, start_frame, origin, easing)
    _key(camera, data_path, index, start_frame + duration, origin + amount, easing)
    ctx.assert_that("camera move", True, f"{move_type} {amount} over {duration} frames")


def _configured_default_amount(ctx: BuildContext, move_type: str) -> float:
    path = {
        "dolly": "camera.move_defaults.dolly",
        "truck": "camera.move_defaults.truck",
        "pedestal": "camera.move_defaults.pedestal",
        "pan": "camera.move_defaults.pan_deg",
        "tilt": "camera.move_defaults.tilt_deg",
    }[move_type]
    value = float(req(ctx.cfg, path))
    return math.radians(value) if move_type in {"pan", "tilt"} else value


def _build_orbit(camera: Any, start_frame: int, duration: int, easing: str, orbit_deg: float) -> None:
    empty = bpy.data.objects.new("CAM_orbit_pivot", None)
    bpy.context.scene.collection.objects.link(empty)
    empty.empty_display_type = "PLAIN_AXES"
    camera.parent = empty
    _key(empty, "rotation_euler", 2, start_frame, 0.0, easing)
    _key(empty, "rotation_euler", 2, start_frame + duration, math.radians(orbit_deg), easing)


def _build_follow_path(
    ctx: BuildContext,
    camera: Any,
    move: dict[str, Any],
    start_frame: int,
    duration: int,
    easing: str,
) -> None:
    from .assets import link_path_asset

    asset_id = move.get("path_asset_id")
    if not asset_id:
        raise BuildError("camera.move.path_asset_id is required for follow_path")
    path_obj = link_path_asset(ctx, str(asset_id))
    constraint = camera.constraints.new("FOLLOW_PATH")
    constraint.target = path_obj
    constraint.use_fixed_location = True
    constraint.use_curve_follow = not any(c.type == "TRACK_TO" for c in camera.constraints)
    constraint.forward_axis = str(move.get("forward_axis", "FORWARD_Y"))
    constraint.up_axis = str(move.get("up_axis", "UP_Z"))
    constraint.offset_factor = float(move.get("start_factor", 0.0))
    constraint.keyframe_insert(data_path="offset_factor", frame=start_frame)
    constraint.offset_factor = float(move.get("end_factor", 1.0))
    constraint.keyframe_insert(data_path="offset_factor", frame=start_frame + duration)
    interpolation, ease = parse_easing(easing)
    anim = camera.animation_data
    if anim and anim.action:
        for fcurve in _all_fcurves(anim.action):
            if not fcurve.data_path.endswith("offset_factor"):
                continue
            for point in fcurve.keyframe_points:
                if int(point.co[0]) in {start_frame, start_frame + duration}:
                    point.interpolation = interpolation
                    point.easing = ease
    ctx.assert_that(
        "camera move",
        True,
        f"follow_path {asset_id} {move.get('start_factor', 0.0)}→{move.get('end_factor', 1.0)}",
    )
