from __future__ import annotations

import re
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class StyleGeometry(StrictModel):
    silhouette: str = "rounded"
    detail_level: Literal["low", "medium", "high"] = "low"
    bevel_profile: str = "soft"
    subdivision: Literal["none", "minimal", "moderate"] = "minimal"


class StyleShading(StrictModel):
    family: str = "principled_clay"
    texture_policy: Literal["none", "limited", "allowed"] = "none"
    metallic: float = Field(default=0.0, ge=0.0, le=1.0)
    roughness: float = Field(default=0.72, ge=0.0, le=1.0)


class StyleRestrictions(StrictModel):
    hair_simulation: bool = False
    cloth_simulation: bool = False
    particle_fx: bool = False
    displacement: bool = False
    phototextures: bool = False


class StyleConfig(StrictModel):
    id: str = "neutral_v1"
    geometry: StyleGeometry = Field(default_factory=StyleGeometry)
    shading: StyleShading = Field(default_factory=StyleShading)
    palette: dict[str, tuple[float, float, float, float]] = Field(default_factory=dict)
    lighting_default: str = "high_key_neutral"
    restrictions: StyleRestrictions = Field(default_factory=StyleRestrictions)


class Resolution(StrictModel):
    width: int = Field(default=1920, ge=1)
    height: int = Field(default=1080, ge=1)
    percentage: int = Field(default=100, ge=1, le=100)


class RenderConfig(StrictModel):
    engine: Literal["CYCLES", "BLENDER_EEVEE", "BLENDER_WORKBENCH"] = "CYCLES"
    device: Literal["GPU", "CPU"] = "GPU"
    samples: int = Field(default=128, ge=1)
    adaptive_threshold: float = Field(default=0.01, ge=0)
    denoiser: str = "OPTIX"
    resolution: Resolution = Field(default_factory=Resolution)
    fps: int = Field(default=24, ge=1)
    frame_start: int = Field(default=1, ge=0)
    frame_end: int = Field(default=240, ge=0)
    view_transform: str = "AgX"
    look: str = "Medium High Contrast"
    persistent_data: bool = True
    simplify: bool = False
    texture_limit: int = Field(default=0, ge=0)
    seed: int = 0

    @model_validator(mode="after")
    def validate_frames(self) -> RenderConfig:
        if self.frame_end < self.frame_start:
            raise ValueError("render.frame_end must be >= render.frame_start")
        return self


class CameraDOF(StrictModel):
    enabled: bool = False
    f_stop: float = Field(default=5.6, gt=0)
    focus_target: str | None = None


class CameraMoveDefaults(StrictModel):
    dolly: float = 1.5
    truck: float = 1.0
    pedestal: float = 0.5
    pan_deg: float = 8.0
    tilt_deg: float = 5.0
    orbit_deg: float = 20.0


class CameraMove(StrictModel):
    type: Literal["static", "dolly", "truck", "pedestal", "pan", "tilt", "orbit", "follow_path"] = "static"
    easing: str = "BEZIER"
    duration_frames: int = Field(default=0, ge=0)
    amount: float | None = None
    path_asset_id: str | None = None
    start_factor: float = Field(default=0.0, ge=0.0, le=1.0)
    end_factor: float = Field(default=1.0, ge=0.0, le=1.0)
    forward_axis: Literal[
        "FORWARD_X", "FORWARD_Y", "FORWARD_Z",
        "TRACK_NEGATIVE_X", "TRACK_NEGATIVE_Y", "TRACK_NEGATIVE_Z",
    ] = "FORWARD_Y"
    up_axis: Literal["UP_X", "UP_Y", "UP_Z"] = "UP_Z"

    @model_validator(mode="after")
    def validate_path(self) -> CameraMove:
        if self.type == "follow_path" and not self.path_asset_id:
            raise ValueError("camera.move.path_asset_id is required for follow_path")
        if self.type == "follow_path":
            forward_dim = self.forward_axis.rsplit("_", 1)[-1]
            up_dim = self.up_axis.rsplit("_", 1)[-1]
            if forward_dim == up_dim:
                raise ValueError("camera.move forward_axis and up_axis must use different axes")
        return self


class CameraTemplateSpec(StrictModel):
    lens_mm: float = Field(gt=0)
    sensor_width_mm: float = Field(default=36.0, gt=0)
    offset: tuple[float, float, float]
    target_offset: tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation_deg: tuple[float, float, float] = (90.0, 0.0, 0.0)
    shift_x: float = 0.0
    shift_y: float = 0.0
    track_subject: bool = True
    dof_enabled: bool = False
    f_stop: float = Field(default=5.6, gt=0)


class CameraConfig(StrictModel):
    template: str | None = None
    templates: dict[str, CameraTemplateSpec] = Field(default_factory=dict)
    lens_mm: float = Field(default=50.0, gt=0)
    sensor_width_mm: float = Field(default=36.0, gt=0)
    shift_x: float = 0.0
    shift_y: float = 0.0
    initial_location: tuple[float, float, float] = (0.0, -6.0, 1.6)
    initial_rotation_deg: tuple[float, float, float] = (90.0, 0.0, 0.0)
    dof: CameraDOF = Field(default_factory=CameraDOF)
    move: CameraMove = Field(default_factory=CameraMove)
    move_defaults: CameraMoveDefaults = Field(default_factory=CameraMoveDefaults)
    shake_profile: str = "none"
    framing_target: str | None = None


class LightSpec(StrictModel):
    energy: float = Field(default=1000.0, ge=0)
    color_temperature_k: float = Field(default=5600.0, gt=0)
    location: tuple[float, float, float] = (3.0, -4.0, 3.5)
    rotation_deg: tuple[float, float, float] = (55.0, 0.0, 35.0)
    area_size: float = Field(default=2.0, gt=0)


class LightRigPreset(StrictModel):
    key: LightSpec | None = None
    fill: LightSpec | None = None
    rim: LightSpec | None = None


class LightingConfig(StrictModel):
    presets: dict[str, LightRigPreset] = Field(default_factory=dict)
    rig_preset: str = "three_point"
    key: LightSpec = Field(default_factory=lambda: LightSpec(
        energy=1000.0,
        location=(3.0, -4.0, 3.5),
        rotation_deg=(55.0, 0.0, 35.0),
    ))
    fill: LightSpec = Field(default_factory=lambda: LightSpec(
        energy=300.0,
        location=(-3.5, -3.0, 2.0),
        rotation_deg=(70.0, 0.0, -50.0),
    ))
    rim: LightSpec = Field(default_factory=lambda: LightSpec(
        energy=600.0,
        color_temperature_k=6500.0,
        location=(-1.5, 4.0, 3.0),
        rotation_deg=(110.0, 0.0, -160.0),
    ))
    hdri_asset_id: str | None = None
    hdri_rotation_deg: float = 0.0
    hdri_strength: float = Field(default=1.0, ge=0)


class SetConfig(StrictModel):
    environment_asset_id: str | None = None
    dressing_overrides: dict[str, Any] = Field(default_factory=dict)
    atmosphere: dict[str, Any] = Field(default_factory=dict)


class Transform(StrictModel):
    location: tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation_deg: tuple[float, float, float] = (0.0, 0.0, 0.0)
    scale: tuple[float, float, float] = (1.0, 1.0, 1.0)


class NlaStrip(StrictModel):
    action: str
    start_frame: int = Field(ge=0)
    end_frame: int = Field(ge=0)
    track: str = "performance"
    blend_in: int = Field(default=0, ge=0)
    blend_out: int = Field(default=0, ge=0)
    influence: float = Field(default=1.0, ge=0.0, le=1.0)
    blend_type: str = "REPLACE"

    @model_validator(mode="after")
    def validate_range(self) -> NlaStrip:
        if self.end_frame < self.start_frame:
            raise ValueError("NLA strip end_frame must be >= start_frame")
        return self


class FacialCue(StrictModel):
    shape_key: str
    start_frame: int = Field(ge=0)
    end_frame: int = Field(ge=0)
    strength: float = Field(default=1.0, ge=0.0, le=1.0)

    @model_validator(mode="after")
    def validate_range(self) -> FacialCue:
        if self.end_frame < self.start_frame:
            raise ValueError("facial cue end_frame must be >= start_frame")
        return self


class CastMember(StrictModel):
    id: str
    spawn: Transform = Field(default_factory=Transform)
    retarget_profile: str | None = None
    actions: list[NlaStrip] = Field(default_factory=list)
    facial_cues: list[FacialCue] = Field(default_factory=list)
    look_overrides: dict[str, Any] = Field(default_factory=dict)


class PropAttachment(StrictModel):
    target_character_id: str
    bone: str
    start_frame: int = Field(ge=0)
    end_frame: int | None = Field(default=None, ge=0)
    offset: Transform = Field(default_factory=Transform)
    release_transform: Transform | None = None

    @model_validator(mode="after")
    def validate_range(self) -> PropAttachment:
        if self.end_frame is not None and self.end_frame < self.start_frame:
            raise ValueError("prop attachment end_frame must be >= start_frame")
        return self


class PropInstance(StrictModel):
    id: str
    asset_id: str
    spawn: Transform = Field(default_factory=Transform)
    attachments: list[PropAttachment] = Field(default_factory=list)


class BlockingKey(StrictModel):
    frame: int = Field(ge=0)
    transform: Transform
    easing: str = "BEZIER"


class BlockingTrack(StrictModel):
    character_id: str
    keys: list[BlockingKey] = Field(default_factory=list)


class DialogueLine(StrictModel):
    speaker: str
    text: str
    voice_id: str
    start_frame: int = Field(ge=0)
    end_frame: int | None = Field(default=None, ge=0)
    viseme_artifact: str | None = None
    emphasis: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_range(self) -> DialogueLine:
        if self.end_frame is not None and self.end_frame < self.start_frame:
            raise ValueError("dialogue.end_frame must be >= start_frame")
        return self


_SAFE_OVERLAY_EXPR = re.compile(r"^[0-9A-Za-z_+\-*/(). ]+$")


class CaptionStyle(StrictModel):
    burn_in: bool = False
    font_name: str = "Sans"
    font_size: int = Field(default=42, ge=8, le=200)
    margin_v: int = Field(default=48, ge=0)


class OverlaySlot(StrictModel):
    asset_id: str
    start_frame: int = Field(ge=0)
    end_frame: int = Field(ge=0)
    x: str = "(main_w-overlay_w)/2"
    y: str = "(main_h-overlay_h)/2"
    width: int | None = Field(default=None, gt=0)
    opacity: float = Field(default=1.0, ge=0.0, le=1.0)

    @model_validator(mode="after")
    def validate_overlay(self) -> OverlaySlot:
        if self.end_frame < self.start_frame:
            raise ValueError("overlay end_frame must be >= start_frame")
        for label, value in (("x", self.x), ("y", self.y)):
            if not _SAFE_OVERLAY_EXPR.fullmatch(value) or any(c in value for c in "[];:'\"\\"):
                raise ValueError(f"overlay {label} contains unsupported FFmpeg expression syntax")
        return self


class CompConfig(StrictModel):
    grade_lut_asset_id: str | None = None
    glow: float = Field(default=0.0, ge=0)
    glow_quality: Literal["LOW", "MEDIUM", "HIGH"] = "MEDIUM"
    vignette: float = Field(default=0.0, ge=0)
    vignette_width: float = Field(default=0.8, gt=0, le=2.0)
    vignette_height: float = Field(default=0.9, gt=0, le=2.0)
    vignette_blur_px: int = Field(default=200, ge=0)
    caption_style: CaptionStyle = Field(default_factory=CaptionStyle)
    overlay_slots: list[OverlaySlot] = Field(default_factory=list)


class OutputConfig(StrictModel):
    image_format: Literal["OPEN_EXR", "PNG"] = "PNG"
    container: str = "mp4"
    video_codec: str = "h264_nvenc"
    cq: int = Field(default=20, ge=0, le=51)
    audio_codec: str = "aac"
    filename_template: str = "{scene_id}_{shot_id}"
    metadata: dict[str, str] = Field(default_factory=dict)


class PreviewConfig(StrictModel):
    resolution_percentage: int = Field(default=25, ge=1, le=100)
    samples: int = Field(default=16, ge=1)
    engine_override: Literal["CYCLES", "BLENDER_EEVEE", "BLENDER_WORKBENCH"] | None = None
    contact_sheet_frames: list[int] = Field(default_factory=list)


class GpuWorkload(StrictModel):
    estimated_peak_mib: int = Field(ge=0)


class GpuPolicy(StrictModel):
    reserve_mib: int = Field(default=2048, ge=0)
    lock_timeout_seconds: int = Field(default=3600, ge=1)
    workloads: dict[str, GpuWorkload] = Field(
        default_factory=lambda: {
            "cycles_preview": GpuWorkload(estimated_peak_mib=6000),
            "cycles_final": GpuWorkload(estimated_peak_mib=12000),
            "vision_qa": GpuWorkload(estimated_peak_mib=6000),
            "nvenc": GpuWorkload(estimated_peak_mib=512),
        }
    )


class ResourcePolicy(StrictModel):
    gpu: GpuPolicy = Field(default_factory=GpuPolicy)


class QaConfig(StrictModel):
    vision_model: str = "qwen3-vl:4b-instruct"
    max_revisions: int = Field(default=3, ge=0, le=10)
    min_score_improvement: float = Field(default=0.05, ge=0)
    phash_max_distance: int = Field(default=6, ge=0)
    ssim_min: float = Field(default=0.97, ge=-1.0, le=1.0)
    allowed_patch_prefixes: list[str] = Field(
        default_factory=lambda: ["camera.", "lighting.", "comp.", "preview."]
    )


class MetadataConfig(StrictModel):
    project_id: str = "training"
    scene_id: str = "scene"
    shot_id: str = "shot"
    contract_version: str = "1.0.0"


class InstructionIntent(StrictModel):
    learning_objective: str
    audience: str
    prerequisite: str | None = None


class DramaticIntent(StrictModel):
    purpose: str
    desired_attention: str
    tone: str = "neutral"


class SceneSetting(StrictModel):
    asset_id: str
    type: Literal["interior", "exterior", "mixed"]
    time_of_day: str = "unspecified"
    atmosphere: str | None = None


class SceneCastMember(StrictModel):
    character_id: str
    role: str
    scene_goal: str
    emotional_state: str = "neutral"


class SceneEvent(StrictModel):
    id: str
    intent: str
    actors: list[str] = Field(default_factory=list)
    action: str
    emphasis: str | None = None


class Continuity(StrictModel):
    entering_state: str = ""
    exiting_state: str = ""


class DirectorScene(StrictModel):
    id: str
    instruction: InstructionIntent
    dramatic_intent: DramaticIntent
    setting: SceneSetting
    cast: list[SceneCastMember]
    events: list[SceneEvent]
    continuity: Continuity = Field(default_factory=Continuity)
    shots: list[str]


class DirectorScriptDocument(StrictModel):
    scene: DirectorScene


class PipelineConfig(StrictModel):
    style: StyleConfig = Field(default_factory=StyleConfig)
    scene: DirectorScene | None = None
    render: RenderConfig = Field(default_factory=RenderConfig)
    camera: CameraConfig = Field(default_factory=CameraConfig)
    lighting: LightingConfig = Field(default_factory=LightingConfig)
    set_spec: SetConfig = Field(default_factory=SetConfig, alias="set")
    cast: list[CastMember] = Field(default_factory=list)
    props: list[PropInstance] = Field(default_factory=list)
    blocking: list[BlockingTrack] = Field(default_factory=list)
    dialogue: list[DialogueLine] = Field(default_factory=list)
    comp: CompConfig = Field(default_factory=CompConfig)
    output: OutputConfig = Field(default_factory=OutputConfig)
    preview: PreviewConfig = Field(default_factory=PreviewConfig)
    resource_policy: ResourcePolicy = Field(default_factory=ResourcePolicy)
    qa: QaConfig = Field(default_factory=QaConfig)
    metadata: MetadataConfig = Field(default_factory=MetadataConfig)
