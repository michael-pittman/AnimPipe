from __future__ import annotations

import argparse
import fcntl
import json
import os
import subprocess
import time
from contextlib import contextmanager
from pathlib import Path

from .hardware import snapshot_dict, verify_live_identity

DEFAULT_MANIFEST = Path("reports/environment/hardware-verified.json")
DEFAULT_LOCK = Path("scratch/locks/gpu.compute.lock")
DEFAULT_STATE = Path("scratch/locks/gpu.compute.json")


@contextmanager
def gpu_lock(
    workload: str,
    estimated_peak_mib: int,
    reserve_mib: int,
    timeout_seconds: int,
    manifest_path: Path = DEFAULT_MANIFEST,
    lock_path: Path = DEFAULT_LOCK,
    state_path: Path | None = None,
):
    gpu = verify_live_identity(manifest_path)
    required = estimated_peak_mib + reserve_mib
    if required > gpu.memory_total_mib:
        raise RuntimeError(
            f"VRAM admission failed: estimate {estimated_peak_mib} + reserve {reserve_mib} "
            f"> total {gpu.memory_total_mib} MiB"
        )
    # State lives beside whichever lock we actually took, so a custom lock
    # path cannot leave a stale state file pointing at the default.
    state = state_path or lock_path.with_suffix(".json")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    fd = lock_path.open("a+")
    deadline = time.monotonic() + timeout_seconds
    while True:
        try:
            fcntl.flock(fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            if time.monotonic() >= deadline:
                fd.close()
                raise TimeoutError(f"timed out waiting for GPU lock: {workload}")
            time.sleep(1.0)
    try:
        gpu = verify_live_identity(manifest_path)
        if gpu.memory_free_mib < required:
            raise RuntimeError(
                f"VRAM admission failed after lock: free {gpu.memory_free_mib} MiB < "
                f"required {required} MiB"
            )
        payload = {
            "pid": os.getpid(), "workload": workload,
            "estimated_peak_mib": estimated_peak_mib, "reserve_mib": reserve_mib,
            "gpu": snapshot_dict(gpu), "acquired_epoch": time.time(),
        }
        state.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        yield gpu
    finally:
        state.unlink(missing_ok=True)
        fcntl.flock(fd.fileno(), fcntl.LOCK_UN)
        fd.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)
    run = sub.add_parser("run")
    run.add_argument("--workload", required=True)
    run.add_argument("--estimated-peak-mib", type=int, required=True)
    run.add_argument("--reserve-mib", type=int, required=True)
    run.add_argument("--timeout-seconds", type=int, default=3600)
    run.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.cmd == "run":
        command = args.command
        if command and command[0] == "--":
            command = command[1:]
        if not command:
            raise SystemExit("command required after --")
        with gpu_lock(args.workload, args.estimated_peak_mib, args.reserve_mib, args.timeout_seconds):
            raise SystemExit(subprocess.call(command))


if __name__ == "__main__":
    main()
