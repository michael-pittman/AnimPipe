from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Any

import yaml

from .config_compile import compile_pipeline
from .delivery import build_shot, encode, render_frames
from .gpu_lock import gpu_lock
from .models import PipelineConfig
from .qa_loop import run_loop
from .tts import KokoroClient
from .visemes import rhubarb_cues


class ProxyAcceptanceError(RuntimeError):
    pass


def _write_config(model: PipelineConfig, output: Path) -> Path:
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(model.model_dump(mode="json", by_alias=True), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return output


def _concat(segments: list[Path], output: Path) -> Path:
    if shutil.which("ffmpeg") is None:
        raise ProxyAcceptanceError("ffmpeg not found")
    concat_file = output.with_suffix(".concat.txt")
    concat_file.parent.mkdir(parents=True, exist_ok=True)
    concat_file.write_text(
        "\n".join(f"file '{p.resolve().as_posix()}'" for p in segments) + "\n",
        encoding="utf-8",
    )
    cmd = ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file), "-c", "copy", str(output)]
    proc = subprocess.run(cmd, check=False, capture_output=True, text=True)
    if proc.returncode != 0 or not output.exists():
        tail = "\n".join(proc.stderr.splitlines()[-10:])
        raise ProxyAcceptanceError(f"acceptance concat failed:\n{tail}")
    return output


def _shot_specs(plan_path: Path) -> list[dict[str, Any]]:
    raw = yaml.safe_load(plan_path.read_text(encoding="utf-8"))
    shots = raw.get("shots") if isinstance(raw, dict) else None
    if not isinstance(shots, list) or not shots:
        raise ProxyAcceptanceError("acceptance plan must contain a non-empty shots list")
    return shots


def run_proxy_acceptance(
    *,
    plan_path: Path = Path("proxy_kit/acceptance.yaml"),
    manifest: Path = Path("build/assets.proxy.resolved.json"),
    assets_root: Path = Path("assets"),
    work_dir: Path = Path("build/proxy_acceptance"),
    hardware_manifest: Path = Path("reports/environment/hardware-verified.json"),
    preview: bool = True,
    audio: bool = True,
    qa: bool = True,
) -> dict[str, Any]:
    if not manifest.exists():
        raise ProxyAcceptanceError("proxy manifest missing; run `pipe proxy generate` first")
    shots = _shot_specs(plan_path)
    segments: list[Path] = []
    reports: list[dict[str, Any]] = []
    common_layers = [
        Path("config/base.yaml"), Path("config/proxy/style.yaml"),
        Path("config/proxy/vocabulary.yaml"), Path("config/proxy/acceptance/base.yaml"),
        Path("config/proxy/acceptance/scene.yaml"),
    ]

    for item in shots:
        shot_id = str(item["id"])
        shot_layer = Path(str(item["config"]))
        shot_dir = work_dir / shot_id
        shot_dir.mkdir(parents=True, exist_ok=True)
        overrides: list[str] = []
        if not audio:
            overrides.extend(["dialogue=[]", "comp.caption_style.burn_in=false"])
        initial, _, _ = compile_pipeline(common_layers + [shot_layer], overrides)
        wav: Path | None = None
        if audio and initial.dialogue:
            if len(initial.dialogue) != 1:
                raise ProxyAcceptanceError(
                    f"proxy acceptance shot {shot_id} must use exactly one dialogue line"
                )
            line = initial.dialogue[0]
            wav = shot_dir / "audio" / "speech.wav"
            wav.parent.mkdir(parents=True, exist_ok=True)
            KokoroClient().synthesize(line.text, wav, voice=line.voice_id, speed=1.0)
            transcript = shot_dir / "audio" / "transcript.txt"
            transcript.write_text(line.text + "\n", encoding="utf-8")
            cues = shot_dir / "audio" / "visemes.json"
            rhubarb_cues(wav, cues, transcript)
            overrides.append(f"dialogue.0.viseme_artifact={cues.as_posix()}")

        cfg, _, _ = compile_pipeline(common_layers + [shot_layer], overrides)
        resolved = _write_config(cfg, shot_dir / "resolved_config.json")
        qa_report: dict[str, Any] | None = None
        if qa:
            qa_report = run_loop(
                resolved_config=resolved,
                intent=Path("config/proxy/acceptance/scene.yaml"),
                asset_manifest=manifest,
                assets_root=assets_root,
                work_dir=shot_dir / "qa",
                hardware_manifest=hardware_manifest,
            )
            if qa_report.get("status") != "pass":
                raise ProxyAcceptanceError(
                    f"shot {shot_id} visual QA did not pass: {qa_report.get('status')} "
                    f"({qa_report.get('reason')})"
                )
            final_config = qa_report.get("final_config")
            if not final_config:
                raise ProxyAcceptanceError(f"shot {shot_id} QA passed without a final config")
            resolved = Path(str(final_config))
            cfg = PipelineConfig.model_validate(json.loads(resolved.read_text(encoding="utf-8")))

        blend = shot_dir / "scene.blend"
        build_report = build_shot(
            config=resolved, manifest=manifest, output=blend, assets_root=assets_root,
            preview=preview, report=shot_dir / "build_manifest.json",
        )
        if build_report.get("status") != "ok":
            raise ProxyAcceptanceError(f"shot {shot_id} build blocked: {build_report}")

        policy = cfg.resource_policy.gpu
        workload_name = "cycles_preview" if preview else "cycles_final"
        workload = policy.workloads[workload_name]
        frames_dir = shot_dir / "frames"
        with gpu_lock(
            workload_name, workload.estimated_peak_mib, policy.reserve_mib,
            policy.lock_timeout_seconds, manifest_path=hardware_manifest,
        ):
            rendered = render_frames(blend=blend, output_dir=frames_dir)

        segment = shot_dir / f"{shot_id}.mp4"
        kwargs = dict(
            frames_dir=frames_dir, output=segment, fps=cfg.render.fps,
            frame_start=cfg.render.frame_start, codec=cfg.output.video_codec, cq=cfg.output.cq,
            audio=wav, audio_codec=cfg.output.audio_codec, metadata=cfg.output.metadata,
            comp=cfg.comp.model_dump(mode="json"),
            dialogue=[d.model_dump(mode="json") for d in cfg.dialogue],
            asset_manifest=manifest, assets_root=assets_root,
        )
        if cfg.output.video_codec.endswith("_nvenc"):
            nv = policy.workloads["nvenc"]
            with gpu_lock(
                "nvenc", nv.estimated_peak_mib, policy.reserve_mib,
                policy.lock_timeout_seconds, manifest_path=hardware_manifest,
            ):
                encode(**kwargs)
        else:
            encode(**kwargs)
        segments.append(segment)
        reports.append({
            "shot_id": shot_id,
            "frames": len(rendered),
            "segment": str(segment),
            "audio": str(wav) if wav else None,
            "qa": qa_report,
            "build": build_report,
        })

    final = _concat(segments, work_dir / "proxy_acceptance_film.mp4")
    report = {
        "status": "ok", "preview": preview, "audio": audio, "qa": qa,
        "shots": reports, "film": str(final), "segments": [str(p) for p in segments],
    }
    (work_dir / "acceptance_report.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return report
