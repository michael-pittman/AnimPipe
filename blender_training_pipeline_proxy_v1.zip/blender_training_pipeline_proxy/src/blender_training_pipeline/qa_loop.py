from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

from .config_patch import apply_review_candidate
from .delivery import build_shot, contact_sheet, render_frames
from .gpu_lock import gpu_lock
from .models import PipelineConfig
from .qa_models import VisualReview
from .vision_review import review_preview


def mean_review_score(review: VisualReview) -> float:
    dimensions = [
        review.framing,
        review.legibility,
        review.staging,
        review.lighting,
        review.continuity,
        review.instructional_intent,
    ]
    return sum(item.score for item in dimensions) / len(dimensions)


def revision_decision(
    review: VisualReview,
    config: PipelineConfig,
    *,
    iteration: int,
    prior_score: float | None,
) -> tuple[str, str]:
    if review.verdict == "pass":
        return "pass", "vision critic passed the preview"
    if review.verdict == "escalate":
        return "escalate", "vision critic requested human escalation"
    if iteration >= config.qa.max_revisions:
        return "escalate", f"maximum revision count reached ({config.qa.max_revisions})"
    if not review.changes:
        return "escalate", "revision requested without any config changes"
    score = mean_review_score(review)
    if prior_score is not None:
        improvement = score - prior_score
        if improvement < config.qa.min_score_improvement:
            return (
                "escalate",
                f"score improvement {improvement:.4f} is below required "
                f"{config.qa.min_score_improvement:.4f}",
            )
    return "revise", "validated config-only revision may proceed"


def _prior_score(path: Path | None) -> float | None:
    if path is None:
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    value = data.get("score")
    return float(value) if value is not None else None


def review_iteration(
    *,
    preview: Path,
    intent: Path,
    resolved_config: Path,
    report: Path,
    candidate_config: Path | None = None,
    iteration: int = 0,
    prior_report: Path | None = None,
    hardware_manifest: Path = Path("reports/environment/hardware-verified.json"),
) -> dict[str, Any]:
    if iteration < 0:
        raise ValueError("iteration must be >= 0")
    raw = json.loads(resolved_config.read_text(encoding="utf-8"))
    config = PipelineConfig.model_validate(raw)
    policy = config.resource_policy.gpu
    workload = policy.workloads["vision_qa"]
    with gpu_lock(
        workload="vision_qa",
        estimated_peak_mib=workload.estimated_peak_mib,
        reserve_mib=policy.reserve_mib,
        timeout_seconds=policy.lock_timeout_seconds,
        manifest_path=hardware_manifest,
    ):
        review = review_preview(
            preview,
            intent.read_text(encoding="utf-8"),
            resolved_config.read_text(encoding="utf-8"),
            model=config.qa.vision_model,
        )
    score = mean_review_score(review)
    prior_score = _prior_score(prior_report)
    action, reason = revision_decision(review, config, iteration=iteration, prior_score=prior_score)
    result: dict[str, Any] = {
        "iteration": iteration,
        "critic_verdict": review.verdict,
        "action": action,
        "reason": reason,
        "score": score,
        "prior_score": prior_score,
        "max_revisions": config.qa.max_revisions,
        "min_score_improvement": config.qa.min_score_improvement,
        "review": review.model_dump(mode="json"),
    }
    if action == "revise" and candidate_config is not None:
        candidate = apply_review_candidate(raw, review)
        candidate_config.parent.mkdir(parents=True, exist_ok=True)
        candidate_config.write_text(
            json.dumps(candidate, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        result["candidate_config"] = str(candidate_config)
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result


def run_loop(
    *,
    resolved_config: Path,
    intent: Path,
    asset_manifest: Path,
    assets_root: Path,
    work_dir: Path,
    hardware_manifest: Path = Path("reports/environment/hardware-verified.json"),
) -> dict[str, Any]:
    """Own the bounded preview→inspect→revise loop.

    Each iteration is a clean deterministic rebuild. The critic can only propose
    allow-listed config patches, and every candidate is revalidated before the next build.
    """
    work_dir.mkdir(parents=True, exist_ok=True)
    current = work_dir / "resolved-r0.json"
    if resolved_config.resolve() != current.resolve():
        shutil.copy2(resolved_config, current)
    else:
        current = resolved_config

    prior_report: Path | None = None
    history: list[dict[str, Any]] = []
    iteration = 0

    while True:
        raw = json.loads(current.read_text(encoding="utf-8"))
        cfg = PipelineConfig.model_validate(raw)
        blend = work_dir / f"preview-r{iteration}.blend"
        build_report = work_dir / f"build-r{iteration}.json"
        report = build_shot(
            config=current,
            manifest=asset_manifest,
            output=blend,
            assets_root=assets_root,
            preview=True,
            report=build_report,
        )
        if report.get("status") != "ok":
            final = {"status": "escalate", "reason": "preview build failed", "history": history, "build": report}
            (work_dir / "qa-loop.json").write_text(json.dumps(final, indent=2) + "\n")
            return final

        frames_dir = work_dir / f"frames-r{iteration}"
        frames = cfg.preview.contact_sheet_frames or None
        policy = cfg.resource_policy.gpu
        workload = policy.workloads["cycles_preview"]
        with gpu_lock(
            workload="cycles_preview",
            estimated_peak_mib=workload.estimated_peak_mib,
            reserve_mib=policy.reserve_mib,
            timeout_seconds=policy.lock_timeout_seconds,
            manifest_path=hardware_manifest,
        ):
            rendered = render_frames(blend=blend, output_dir=frames_dir, frames=frames)

        sheet = work_dir / f"contact-r{iteration}.png"
        pngs = [p for p in rendered if p.suffix.lower() == ".png"]
        if not pngs:
            raise RuntimeError("QA loop requires PNG preview frames for contact-sheet/VLM review")
        contact_sheet(frames=pngs, output=sheet)

        review_report = work_dir / f"review-r{iteration}.json"
        candidate = work_dir / f"resolved-r{iteration + 1}.json"
        result = review_iteration(
            preview=sheet,
            intent=intent,
            resolved_config=current,
            report=review_report,
            candidate_config=candidate,
            iteration=iteration,
            prior_report=prior_report,
            hardware_manifest=hardware_manifest,
        )
        history.append(result)
        if result["action"] != "revise":
            final = {
                "status": result["action"],
                "reason": result["reason"],
                "iterations": iteration + 1,
                "final_config": str(current),
                "history": history,
            }
            (work_dir / "qa-loop.json").write_text(json.dumps(final, indent=2) + "\n")
            return final
        prior_report = review_report
        current = candidate
        iteration += 1
