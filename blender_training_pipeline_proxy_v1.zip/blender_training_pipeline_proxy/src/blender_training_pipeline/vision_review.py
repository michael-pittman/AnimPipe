from __future__ import annotations

import base64
from pathlib import Path

import httpx

from .qa_models import VisualReview


def review_preview(
    image: Path,
    intent_text: str,
    resolved_config_text: str,
    model: str = "qwen3-vl:4b-instruct",
    base_url: str = "http://127.0.0.1:11434",
) -> VisualReview:
    encoded = base64.b64encode(image.read_bytes()).decode("ascii")
    prompt = (
        "You are the visual QA critic for an instructional Blender animation. "
        "Judge framing, legibility, staging, lighting, continuity and instructional intent. "
        "Honor the resolved style contract; for proxy_clay_v1 do not reward realism, texture detail, or decorative complexity. "
        "Judge semantic value separation and motion readability instead. Never propose changes to style.*. "
        "Propose only configuration changes, never code.\n\n"
        f"DIRECTOR INTENT:\n{intent_text}\n\nRESOLVED CONFIG:\n{resolved_config_text}"
    )
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt, "images": [encoded]}],
        "format": VisualReview.model_json_schema(),
        "stream": False,
        "keep_alive": 0,
        "options": {"temperature": 0},
    }
    with httpx.Client(timeout=300.0) as client:
        response = client.post(f"{base_url}/api/chat", json=payload)
        response.raise_for_status()
        content = response.json()["message"]["content"]
    return VisualReview.model_validate_json(content)
