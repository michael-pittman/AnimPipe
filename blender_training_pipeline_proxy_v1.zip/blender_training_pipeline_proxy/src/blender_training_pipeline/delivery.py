"""Host-side build/render/delivery helpers.

Blender renders image sequences only. FFmpeg owns mux, LUT, caption burn-in and
static overlay composition so those delivery revisions never require a Cycles rerender.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Any

import yaml

from asset_system.models import AssetManifest
from asset_system.doctor import safe_asset_path

BLENDER = "blender"


class DeliveryError(RuntimeError):
    pass


def build_shot(
    *,
    config: Path,
    manifest: Path,
    output: Path,
    assets_root: Path = Path("assets"),
    preview: bool = False,
    report: Path | None = None,
    blender: str = BLENDER,
) -> dict[str, Any]:
    report_path = report or output.with_name("build_manifest.json")
    cmd = [
        blender, "--background", "--factory-startup",
        "--python", "blend_build/entrypoint.py", "--",
        "--config", str(config), "--manifest", str(manifest),
        "--assets-root", str(assets_root), "--output", str(output),
        "--report", str(report_path),
    ]
    if preview:
        cmd.append("--preview")
    proc = subprocess.run(cmd, check=False)
    if not report_path.exists():
        raise DeliveryError(
            f"builder produced no report (exit {proc.returncode}); Blender failed before reporting"
        )
    return json.loads(report_path.read_text(encoding="utf-8"))


def render_frames(
    *, blend: Path, output_dir: Path, frames: list[int] | None = None, blender: str = BLENDER
) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    pattern = str(output_dir / "####")
    cmd = [blender, "--background", str(blend), "--render-output", pattern]
    if frames:
        cmd += ["-f", ",".join(str(f) for f in frames)]
    else:
        cmd.append("-a")
    proc = subprocess.run(cmd, check=False)
    rendered = sorted(output_dir.glob("*.png")) + sorted(output_dir.glob("*.exr"))
    if not rendered:
        raise DeliveryError(f"render produced no frames (exit {proc.returncode})")
    return rendered


def _load_manifest(path: Path) -> AssetManifest:
    text = path.read_text(encoding="utf-8")
    raw = json.loads(text) if path.suffix.lower() == ".json" else yaml.safe_load(text)
    return AssetManifest.model_validate(raw)


def resolve_delivery_asset(
    asset_id: str, *, manifest_path: Path, assets_root: Path, expected_kind: str
) -> Path:
    manifest = _load_manifest(manifest_path)
    try:
        entry = manifest.assets[asset_id]
    except KeyError as exc:
        raise DeliveryError(f"delivery asset '{asset_id}' is not in the manifest") from exc
    if entry.kind != expected_kind:
        raise DeliveryError(
            f"delivery asset '{asset_id}' must be kind={expected_kind}, found {entry.kind}"
        )
    path = safe_asset_path(assets_root, entry.file)
    if not path.exists():
        raise DeliveryError(f"delivery asset '{asset_id}' file not found: {path}")
    return path


def _srt_time(frame: int, fps: int) -> str:
    total_ms = round((frame / fps) * 1000)
    hours, rem = divmod(total_ms, 3_600_000)
    minutes, rem = divmod(rem, 60_000)
    seconds, millis = divmod(rem, 1000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d},{millis:03d}"


def write_dialogue_srt(dialogue: list[dict[str, Any]], *, fps: int, output: Path) -> Path:
    blocks: list[str] = []
    for index, line in enumerate(dialogue, start=1):
        end = line.get("end_frame")
        if end is None:
            raise DeliveryError(
                f"caption burn-in requires dialogue[{index - 1}].end_frame; timing is never guessed"
            )
        blocks.append(
            f"{index}\n{_srt_time(int(line['start_frame']), fps)} --> {_srt_time(int(end), fps)}\n"
            f"{line['text']}\n"
        )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(blocks), encoding="utf-8")
    return output


def _ffmpeg_filter_path(path: Path) -> str:
    # libavfilter paths use ':' and quote as syntax; asset manifests already prohibit traversal.
    return str(path.resolve()).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")


def encode(
    *,
    frames_dir: Path,
    output: Path,
    fps: int,
    frame_start: int = 0,
    codec: str = "h264_nvenc",
    cq: int = 20,
    audio: Path | None = None,
    audio_codec: str = "aac",
    metadata: dict[str, str] | None = None,
    pattern: str = "%04d.png",
    comp: dict[str, Any] | None = None,
    dialogue: list[dict[str, Any]] | None = None,
    asset_manifest: Path | None = None,
    assets_root: Path = Path("assets"),
) -> Path:
    if shutil.which("ffmpeg") is None:
        raise DeliveryError("ffmpeg not found on PATH")

    output.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "ffmpeg", "-y", "-framerate", str(fps), "-start_number", str(frame_start),
        "-i", str(frames_dir / pattern),
    ]
    audio_index: int | None = None
    if audio is not None:
        audio_index = 1
        cmd += ["-i", str(audio)]

    comp = comp or {}
    overlay_specs = list(comp.get("overlay_slots") or [])
    overlay_inputs: list[tuple[int, dict[str, Any], Path]] = []
    next_input = 2 if audio is not None else 1
    for spec in overlay_specs:
        if asset_manifest is None:
            raise DeliveryError("overlay slots require --manifest so logical asset IDs can resolve")
        path = resolve_delivery_asset(
            str(spec["asset_id"]), manifest_path=asset_manifest,
            assets_root=assets_root, expected_kind="overlay",
        )
        cmd += ["-loop", "1", "-i", str(path)]
        overlay_inputs.append((next_input, spec, path))
        next_input += 1

    filters: list[str] = []
    head = "[0:v]"
    seq = 0
    lut_id = comp.get("grade_lut_asset_id")
    if lut_id:
        if asset_manifest is None:
            raise DeliveryError("grade_lut_asset_id requires --manifest")
        lut = resolve_delivery_asset(
            str(lut_id), manifest_path=asset_manifest, assets_root=assets_root, expected_kind="lut"
        )
        out = f"[v{seq}]"
        seq += 1
        filters.append(f"{head}lut3d=file='{_ffmpeg_filter_path(lut)}'{out}")
        head = out

    caption_style = comp.get("caption_style") or {}
    if caption_style.get("burn_in"):
        srt = write_dialogue_srt(
            dialogue or [], fps=fps, output=output.with_suffix(output.suffix + ".captions.srt")
        )
        out = f"[v{seq}]"
        seq += 1
        style = (
            f"FontName={caption_style.get('font_name', 'Sans')},"
            f"FontSize={int(caption_style.get('font_size', 42))},"
            f"MarginV={int(caption_style.get('margin_v', 48))}"
        )
        filters.append(
            f"{head}subtitles='{_ffmpeg_filter_path(srt)}':force_style='{style}'{out}"
        )
        head = out

    for input_index, spec, _path in overlay_inputs:
        overlay_label = f"[ov{seq}]"
        width = spec.get("width")
        pre = f"[{input_index}:v]format=rgba"
        if width:
            pre += f",scale={int(width)}:-1"
        opacity = float(spec.get("opacity", 1.0))
        if opacity < 1.0:
            pre += f",colorchannelmixer=aa={opacity:.6f}"
        filters.append(pre + overlay_label)
        start_s = int(spec["start_frame"]) / fps
        end_s = int(spec["end_frame"]) / fps
        out = f"[v{seq + 1}]"
        filters.append(
            f"{head}{overlay_label}overlay=x={spec['x']}:y={spec['y']}:"
            f"enable='between(t,{start_s:.6f},{end_s:.6f})'{out}"
        )
        head = out
        seq += 2

    if filters:
        cmd += ["-filter_complex", ";".join(filters), "-map", head]
    else:
        cmd += ["-map", "0:v:0"]
    if audio_index is not None:
        cmd += ["-map", f"{audio_index}:a:0"]

    cmd += ["-c:v", codec]
    if codec.endswith("_nvenc"):
        cmd += ["-preset", "p5", "-cq", str(cq), "-rc", "vbr"]
    else:
        cmd += ["-crf", str(cq)]
    cmd += ["-pix_fmt", "yuv420p"]
    if audio_index is not None:
        # Pad short dialogue with silence so a training shot keeps its configured frame duration.
        # `-shortest` then terminates at the video stream rather than truncating video to speech.
        cmd += ["-c:a", audio_codec, "-af", "apad", "-shortest"]
    for key, value in (metadata or {}).items():
        cmd += ["-metadata", f"{key}={value}"]
    cmd.append(str(output))

    proc = subprocess.run(cmd, check=False, capture_output=True, text=True)
    if proc.returncode != 0 or not output.exists():
        tail = "\n".join(proc.stderr.strip().splitlines()[-10:])
        raise DeliveryError(f"ffmpeg failed (exit {proc.returncode}):\n{tail}")
    return output


def nvenc_available() -> bool:
    if shutil.which("ffmpeg") is None:
        return False
    proc = subprocess.run(
        ["ffmpeg", "-hide_banner", "-encoders"], check=False, capture_output=True, text=True
    )
    return "h264_nvenc" in proc.stdout


def contact_sheet(
    *, frames: list[Path], output: Path, columns: int = 3,
    thumb_width: int = 640, labels: list[str] | None = None,
) -> Path:
    from PIL import Image, ImageDraw

    if not frames:
        raise DeliveryError("contact sheet requires at least one frame")
    thumbs: list[Image.Image] = []
    for path in frames:
        image = Image.open(path).convert("RGB")
        ratio = thumb_width / image.width
        thumbs.append(image.resize((thumb_width, max(1, int(image.height * ratio)))))
    cell_w = thumb_width
    cell_h = max(t.height for t in thumbs)
    label_h = 22
    rows = (len(thumbs) + columns - 1) // columns
    sheet = Image.new("RGB", (cell_w * columns, (cell_h + label_h) * rows), (18, 18, 18))
    draw = ImageDraw.Draw(sheet)
    for index, thumb in enumerate(thumbs):
        col, row = index % columns, index // columns
        x, y = col * cell_w, row * (cell_h + label_h)
        sheet.paste(thumb, (x, y))
        text = labels[index] if labels and index < len(labels) else frames[index].stem
        draw.text((x + 6, y + cell_h + 4), text, fill=(220, 220, 220))
    output.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output)
    return output
