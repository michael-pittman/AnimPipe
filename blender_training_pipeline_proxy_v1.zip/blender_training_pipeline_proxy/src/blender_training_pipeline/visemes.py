from __future__ import annotations

import json
import subprocess
from pathlib import Path


def rhubarb_cues(wav: Path, output_json: Path, transcript: Path | None = None) -> dict:
    command = ["rhubarb", "-f", "json", "-o", str(output_json)]
    if transcript is not None:
        command += ["--dialogFile", str(transcript)]
    command.append(str(wav))
    output_json.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(command, check=True)
    return json.loads(output_json.read_text(encoding="utf-8"))
