# Local AI Services: Ollama Vision + Kokoro TTS

## Ollama
Ollama is included because it gives the pipeline a local multimodal critic, not because Blender requires it.

Default model: `qwen3-vl:4b-instruct`.
The 4B package is small enough for the 16 GB T4 while leaving operational headroom; 8B is a measured opt-in. VLM calls use structured JSON output, temperature 0, and `keep_alive=0` so the model unloads immediately after review.

Ollama binds only to `127.0.0.1:11434`. The pipeline acquires the GPU compute lock before a VLM review.

## Kokoro
Default TTS is Kokoro in a CPU Docker service bound to `127.0.0.1:8880`. This preserves the T4 for Blender and visual QA. The API is OpenAI-compatible, so the provider can be swapped without changing shot schemas.

An optional compose override enables the Kokoro CUDA image. If used, TTS synthesis must acquire the same GPU compute lock.

## Why not make Ollama the primary TTS runtime?
Ollama can run speech-token models such as Orpheus variants, but the speech-token-to-audio API path requires additional frontend/decoder plumbing. Keep an `OrpheusOllamaProvider` as experimental; use Kokoro for the deterministic baseline.
