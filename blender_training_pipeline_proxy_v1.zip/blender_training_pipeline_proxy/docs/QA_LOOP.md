# Preview QA / Render-Inspect-Revise Loop

The loop combines deterministic image checks with a local vision-model critic.

## Inputs
- director-script intent
- resolved shot config
- selected preview/contact-sheet frame(s)
- prior approved baseline when available

## Stage 1: deterministic
- frame existence/dimensions
- exact SHA-256
- perceptual hash distance
- SSIM against baseline preview
- build/config hash consistency

## Stage 2: perceptual rubric
Use the `perceptual-frame-review` skill: framing, legibility, staging/screen direction, lighting/readability, continuity, and instructional intent.

## Stage 3: VLM critic
`qwen3-vl:4b-instruct` receives images + intent and must answer against `VisualReview` JSON Schema. It proposes only allow-listed config-path modifications.

## Stage 4: candidate revision
The revision layer applies a proposal to a candidate OmegaConf object, validates with Pydantic, and writes a candidate config. It cannot modify code or assets.

## Termination
- pass: all blocking dimensions pass and regression thresholds pass
- revise: valid candidate and iteration count remains
- escalate: invalid patch, no score improvement, repeated finding, or max revisions reached

The maximum revision count, threshold values and required minimum improvement are config values.
