# Dependencies and Version Policy

## Host OS
Ubuntu 24.04 LTS is the target baseline.

## GPU driver
Use the Microsoft-documented Azure GRID procedure for `NCasT4_v3`. The installer script currently targets `NVIDIA-Linux-x86_64-595.58.03-grid-azure.run` from Microsoft's documented download location. Secure Boot and vTPM must be disabled for that documented procedure.

## CUDA policy
**Do not install a host CUDA Toolkit.** The build does not require `nvcc`, `cuda-toolkit-*`, or `nvidia-cuda-toolkit`.

This does not prohibit workload-local NVIDIA user-space libraries. GPU-enabled Python packages/containers may ship cuBLAS/cuDNN/runtime components internally. NVIDIA Container Toolkit is required for Docker GPU passthrough; it is not the CUDA development toolkit.

## System packages
- build-essential, ca-certificates, curl, wget, gnupg
- git, git-lfs
- ffmpeg
- libegl1, libgl1, libgles2, libxi6, libxxf86vm1, libxfixes3, libxrender1, mesa-utils, xvfb
- libsndfile1, espeak-ng, unzip
- pciutils (diagnostics)
- Docker Engine + Compose plugin
- NVIDIA Container Toolkit

## Blender
Pin Blender 5.2.1 LTS. The installer downloads the official Linux x64 tarball and verifies it against Blender's published 5.2.1 SHA-256 file.

## Python environments

### Host `.venv` — Python 3.11
- pydantic >= 2
- omegaconf
- typer, rich
- PyYAML
- httpx
- numpy, soundfile
- faster-whisper
- Pillow, scikit-image
- pytest, ruff, mypy
- `fake-bpy-module-5.2==20260730` for VS Code/Pylance against the pinned Blender 5.2 API

### `.venv-bpy` — Python 3.13
- `bpy==5.2.1`
- test/type dependencies only

The host development environment pins `fake-bpy-module-5.2==20260730`; do not use `fake-bpy-module-latest` as the authoritative type surface.

## Local services
- Ollama Docker image; first validated pull records its immutable RepoDigest in `infra/.env.locked`
- `qwen3-vl:4b-instruct` initial VLM model
- Kokoro Docker CPU image by default; first validated pull records its immutable RepoDigest in `infra/.env.locked`

## Standalone
- Rhubarb Lip Sync `1.14.0`, installed from the exact release asset. The installer records the downloaded SHA-256 and verifies it automatically if GitHub exposes a release-asset digest.
- Claude Code native **stable** channel; project settings pin `claude-sonnet-4-6`.
- `pyright-langserver` installed as a `uv tool` for Claude/VS Code code intelligence.

## Deferred
- Flamenco
- n8n integration details
- DVC/MLflow/Natron
These are intentionally not prerequisites for the first working module.


## CUDA wording

There is no host CUDA development toolkit or CUDA Python runtime dependency in the supported build. NVIDIA-driver interfaces plus the NVIDIA Container Toolkit are sufficient for Blender OptiX, NVENC, and Ollama. Faster-whisper is intentionally CPU/int8. GPU Whisper is outside the supported baseline and should be designed as a separate future profile rather than changing the host environment in place.
