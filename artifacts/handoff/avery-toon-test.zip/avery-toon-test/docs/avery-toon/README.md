# Avery Chen — Toon / Cel Humanoid

Illustrated **2D-in-3D** Avery on the coherent V3 skinned body. Cel flat fills + Freestyle ink outlines.

## Outputs

| Artifact | Path |
|---|---|
| Blend | `docs/avery-toon/AveryToon.blend` |
| Renders | `media/avery-toon/` |

## Rebuild

Requires **Blender 5.2.1 LTS** (same as V3).

```bash
blender --background --factory-startup \
  --python docs/avery-toon/build_avery_toon.py
```

Optional flags after `--`: `--source`, `--output`, `--render-dir`, `--skip-build`, `--skip-renders`.

## Pipeline contract (preserved)

| Field | Value |
|---|---|
| Collection | `COL_AVERY_CHEN` |
| Armature | `RIG_AVERY_CHEN` |
| Retarget | `proxy_rig_v1` |
| Actions | 20 canonical slotted actions |
| Visemes | `VISEME_A` … `VISEME_X` |
| Expressions | `BLINK`, `BROW_UP`, `BROW_DOWN`, `EXP_smile`, `EXP_frown`, `EXP_surprise`, `LOOK_LEFT`, `LOOK_RIGHT` |

`style_id` in the blend is `avery_chen_toon`.

## Look (toon pass)

- **Wardrobe** — painted on **`GEO_AVERY_BODY`** face material slots (no `GEO_AVERY_JKT_*` / `GEO_AVERY_SHIRT_*` meshes): navy `#0E274A` on torso and arms to the wrist, skin on hands, white upper-chest band with horizontal teal `#088D94` stripe on body faces. **`GEO_AVERY_TROUSERS`** stay olive and meet navy at the waist.
- **Hair** — **`GEO_AVERY_HAIR`** plum **`#6B2D5B`** ellipsoid **measured off the head**, not fixed radii: width **1.55 ×** head width, depth **1.35 ×**, top **5.5 cm above the measured scalp**. No shrinkwrap, solidify, or face culling. The clip removes only the **face window** (forward of `y = −0.036`, below the brow, within `|x| < 0.062` m) so temple volume still frames the face. **100% `head` weights**. Preview PNGs: **Freestyle off**.
- **Chest bands** — curved shell following the **measured torso front** (`CHEST_BAND_ARC_SEGMENTS` columns), spanning the design loops **`1.122 → 1.288` m** in white with the teal stripe at **`1.188 → 1.206` m** riding 1 mm proud. Not an axis-aligned slab — the flat slab read as a pasted-on sticker.
- **Ankles** — sock/piping/cuff clutter removed; olive trousers run into sneakers (no white ankle patches).

Visual lock: `media/avery-flat/` full-body plates.

## Renders shipped

- `full-body-front.png`, `full-body-three-quarter.png`, `full-body-side.png`
- `expression-sheet.png`
- `action-wave.png` (wave action, frame 15)

## License

Same as V3 hero: **CC0-1.0** on authored toon materials and docs; coherent base remains CC0 per `vendor/avery-chen/SOURCE_MANIFEST.json`.
