# Avery toon — crown + chest band fix, test package

Self-contained: unzip anywhere, `cd` into it, run the command below. No other
files from the repo are needed. Requires **Blender 5.2.1 LTS** (pinned — the
coherent-base source is checksum-locked to that version's output).

## Run

```bash
cd avery-toon-test-pkg
blender --background --factory-startup \
  --python docs/avery-toon/build_avery_toon.py
```

Output lands at `docs/avery-toon/AveryToon.blend`; renders at
`media/avery-toon/*.png` (`full-body-front.png` is the one to look at first).

## What this is testing

Last run (in the Cursor cloud agent) died mid-rebuild on a usage limit. The
render it left behind (`media/avery-toon/full-body-front.png` in the main
repo) showed:

- **Bald crown** — the plum hair mass sat *behind* the head as a halo ring;
  forehead and crown were bare skin.
- **Chest band as a sticker** — a flat rectangle floating off the torso
  instead of following the chest surface.

Both were caused by real bugs, not just bad geometry — see
`avery-toon-crown-band-fix.md` in this zip for the full root-cause writeup
(the crown QA gate compared the hair mesh to itself and could never fail; two
other gate floors were set so loose the bald render passed them anyway). The
code changes are **unrendered** — this is the first real test of them.

## What to watch for

- **If the script raises an exception and stops**, read the message — the new
  code raises on purpose if the hair still doesn't clear the scalp (vs.
  silently shipping a bad render like last time). Send me the full error.
- **If it completes**, open `media/avery-toon/full-body-front.png`:
  - Crown should read as solid plum hair over the forehead/crown, not a ring
    behind the head.
  - Chest band should hug the torso curve, not float as a flat slab.
- Compare against `media/avery-flat/front.png` in the main repo (not included
  here) — that's the illustrated target this is chasing.
- The crown-pass threshold (`plum_center < 0.55` in
  `verify_hair_plate`) is calibrated off the *bad* render (which scored 0.17)
  and a guess at a good one — nobody has rendered a correct afro yet. If the
  render looks right but the gate still fails (or looks wrong but passes),
  that's useful signal on its own — tell me the numbers it prints.

No git commit from this package — same as the standing instruction on this
work in the main repo.
