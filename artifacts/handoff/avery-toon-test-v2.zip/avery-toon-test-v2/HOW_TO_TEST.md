# Avery toon — style sheet pass, round 2 test package

Self-contained: unzip anywhere, `cd` into it, run the command below. Requires
**Blender 5.2.1 LTS** (pinned — the coherent-base source is checksum-locked
to that version's output).

## Run

```bash
cd avery-toon-test-v2
blender --background --factory-startup \
  --python docs/avery-toon/build_avery_toon.py
```

Output: `docs/avery-toon/AveryToon.blend`. Renders: `media/avery-toon/*.png`
(`full-body-front.png` first).

## What changed since the last render you sent back

That render confirmed the crown fix worked (hair covered the scalp) but
showed three real gaps against the actual target — the "Patty Patties" style
sheet, not the olive-cargo-pants reference this pipeline was built against
before: **blank face** (no eyes/brows/mouth), **flat-dome hair** (smooth,
single color, hard bowl-cut fringe), and a **plain-sweater wardrobe** (closed,
no lapels/badge/accessories, olive pants). Three parallel diagnoses + fixes
went into this round — full writeups in `avery-toon-style-sheet-pass.md`
(the summary) and the three `fix-*-proposal.md` files (the detailed
evidence/reasoning each fix is based on).

**Still not render-verified.** Blender isn't available where this was built —
every change below is reasoned from code, not confirmed against a live scene.

## What to check, in priority order

1. **Does the build complete at all.** The hair rewrite is the biggest
   structural change (new geometry-merging logic); a failure here should give
   a specific error (face-index mismatch, cluster-overlap, crown-clearance),
   not a generic crash. Send me the exact error if it stops.
2. **Console output — `face-diag` lines** (printed 3x during the run). These
   log the eye/iris/pupil/brow objects' world-space position each time
   they're touched. If the face is *still* blank in the render, paste these
   lines back to me — they're designed to make the real cause legible
   without another round of guessing, since the face bug couldn't be fully
   diagnosed without a live Blender session.
3. **If the build raises `chest band QA failed`**: this is expected-possible,
   not necessarily a real problem. The chest band was resized smaller/higher
   and the QA gate's pixel-sample window was tuned against the old size.
   Check `full-body-front.png` first — if the band itself looks right (narrow
   white/teal strip at the collar, not a banner), it's the QA window that's
   stale, not the geometry. Tell me and I'll recalibrate it.
4. **Open `full-body-front.png`** and compare against the style sheet:
   - Face: visible eyes with iris/pupil, brows, a small mouth mark.
   - Hair: textured curl volume with visible magenta/pink streak clumps, not
     a flat solid dome; fringe edge should look irregular, not a ruler-
     straight line.
   - Wardrobe: lapels framing an open-collar look, narrow white/teal strip
     (not a wide rectangle), navy trousers (not olive), badge/lanyard visible
     at chest height.

Send back whatever renders (even if some QA gates failed and you had to use
`--skip-renders`/inspect the `.blend` directly) plus the console output — that
and the `face-diag` lines are the most useful things for the next round.

No git commit from this package — same standing instruction as before.
