# src/blender_training_pipeline/frame_regression.py

- sha256_file · function · L12-L17 — def sha256_file(path: Path) -> str
- _dct_matrix · function · L20-L28 — def _dct_matrix(n: int) -> np.ndarray
- perceptual_hash · function · L31-L45 — def perceptual_hash(image: Image.Image, hash_size: int = 8, highfreq_factor: int = 4) -> int
- _hamming · function · L48-L49 — def _hamming(a: int, b: int) -> int
- compare_images · function · L52-L66 — def compare_images(current: Path, baseline: Path) -> dict[str, float | int | str]
