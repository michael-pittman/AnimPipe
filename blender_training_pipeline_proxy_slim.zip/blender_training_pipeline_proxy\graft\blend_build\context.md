# blend_build/context.py

- BuildError · class · L23-L24 — class BuildError(RuntimeError)
- req · function · L27-L44 — def req(cfg: dict[str, Any], path: str) -> Any
- opt · function · L47-L51 — def opt(cfg: dict[str, Any], path: str, default: Any = None) -> Any
- set_config · function · L54-L58 — def set_config(cfg: dict[str, Any]) -> dict[str, Any]
- parse_easing · function · L61-L82 — def parse_easing(name: str) -> tuple[str, str]
- srgb_to_linear · function · L85-L88 — def srgb_to_linear(value: float) -> float
- kelvin_to_linear_rgb · function · L91-L117 — def kelvin_to_linear_rgb(kelvin: float) -> tuple[float, float, float]
- _ln · function · L120-L123 — def _ln(value: float) -> float
- BuildContext · class · L127-L166 — class BuildContext
- assert_that · method · L136-L138 — def assert_that(self, check: str, passed: bool, evidence: str = "") -> bool
- failures · method · L140-L141 — def failures(self) -> list[dict[str, Any]]
- asset · method · L143-L150 — def asset(self, asset_id: str) -> dict[str, Any]
- asset_path · method · L152-L162 — def asset_path(self, asset_id: str) -> Path
- fps · method · L165-L166 — def fps(self) -> int
