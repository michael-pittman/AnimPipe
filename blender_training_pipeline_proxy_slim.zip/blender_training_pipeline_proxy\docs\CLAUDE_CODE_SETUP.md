# Claude Code + VS Code Setup

VS Code is the IDE. Use Remote SSH so the repository, Claude Code, Blender, and local services
all execute on the Azure VM without exposing Blender MCP or Ollama to the public network.

## Install

Run `scripts/65_install_claude_code.sh`. It uses Anthropic's native Linux installer on the
stable channel and installs `pyright-langserver` on the user PATH. Authenticate by running
`claude` once.

Then run `scripts/66_install_claude_plugins.sh` to install project-scoped plugins:

- `pyright-lsp` — Python LSP integration; binary supplied by the setup script
- `security-guidance` — reviews code edits for common security mistakes
- `commit-commands` — controlled git workflows
- `pr-review-toolkit` — review agents
- `plugin-dev` — useful when project tooling is later packaged as a plugin
- `skill-creator` — useful for maintaining/evaluating concise project skills

The project itself owns the Blender-specific agents and skills under `.claude/`; those are
more important than generic plugins and are available without marketplace installation.

## Model pin

`.claude/settings.json` pins `claude-sonnet-4-6` rather than using a floating `sonnet` alias.

## Blender MCP

`.mcp.json` defines the official Blender MCP endpoint on localhost. Only the
`blender-debugger` subagent is authorized to use it. The production builder never uses MCP.
