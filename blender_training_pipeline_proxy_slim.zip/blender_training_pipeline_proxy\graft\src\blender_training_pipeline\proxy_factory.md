# src/blender_training_pipeline/proxy_factory.py

- ProxyFactoryError · class · L19-L20 — class ProxyFactoryError(RuntimeError)
- load_proxy_kit · function · L23-L25 — def load_proxy_kit(path: Path) -> ProxyKitSpec
- _relative_asset_file · function · L28-L32 — def _relative_asset_file(path: Path, assets_root: Path) -> str
- _overlay · function · L35-L84 — def _overlay(path: Path, kind: str, width: int, height: int) -> None
- generate_overlays · function · L87-L93 — def generate_overlays(kit: ProxyKitSpec, output_root: Path) -> dict[str, Path]
- build_manifest · function · L96-L158 — def build_manifest(kit: ProxyKitSpec, *, assets_root: Path, output_root: Path) -> AssetManifest
- generate_proxy_kit · function · L161-L251 — def generate_proxy_kit( *, spec_path: Path = Path("proxy_kit/kit.yaml"), assets_root: Path = Path("assets"), output_subdir: str = "proxy", manifest_path: Path = Path("assets/assets.proxy.yaml"), resolved_manifest: Path = Path("build/assets.proxy.resolved.json"), report_path: Path = Path("reports/proxy/generation.json"), blender: str = "blender", ) -> dict[str, Any]
