---
name: director-script
description: Semantic scene-planning contract inspired by Anim-Director. Use when turning instructional intent into a scene, defining cast roles, setting, ordered beats/events, continuity, or deciding where a scene should split into shots. This describes what the scene must communicate; camera and Blender implementation belong in shot config.
---

# Director Script

The scene file is a director's script, not Blender instructions.

## Required semantic layers

```yaml
scene:
  id: module_01_scene_03
  instruction:
    learning_objective: "..."
    audience: "..."
    prerequisite: "..."
  dramatic_intent:
    purpose: "..."
    desired_attention: "..."
    tone: calm
  setting:
    asset_id: set.training_lab
    type: interior
    time_of_day: day
  cast:
    - character_id: char.instructor_a
      role: instructor
      scene_goal: "..."
      emotional_state: confident
  events:
    - id: beat_intro
      intent: establish the concept
      actors: [char.instructor_a]
      action: "introduces the control panel"
      emphasis: control_panel
  continuity:
    entering_state: "..."
    exiting_state: "..."
  shots: [m01_s030, m01_s040]
```

## Rules
- Use asset IDs, never filesystem paths.
- Events describe observable instructional/dramatic beats, not keyframes.
- A shot exists because attention, camera grammar, time/location, or performance emphasis changes.
- Do not duplicate camera/lens/light/sample settings here.
- Every shot must trace to at least one event/beat.
- Continuity state captures what the next scene needs, not every object in Blender.

The Animation Director translates this semantic layer into shot config using named action vocabulary admitted by the asset system.
