# blend_build/props.py

- _roots · function · L14-L15 — def _roots(collection: Any) -> list[Any]
- _apply_transform · function · L18-L24 — def _apply_transform(obj: Any, spec: dict[str, Any]) -> None
- _key_transform · function · L27-L29 — def _key_transform(obj: Any, frame: int) -> None
- _set_constant · function · L32-L39 — def _set_constant(obj: Any) -> None
- _schedule_attachment · function · L42-L94 — def _schedule_attachment( ctx: BuildContext, root: Any, spec: dict[str, Any], cast: dict[str, dict[str, Any]], label: str, ) -> None
- build_props · function · L97-L126 — def build_props(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]
