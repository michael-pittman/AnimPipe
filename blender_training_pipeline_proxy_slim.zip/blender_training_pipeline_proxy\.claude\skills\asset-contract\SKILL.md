---
name: asset-contract
description: Admission contract for characters, sets, props, materials and environments. Use when adding or validating an asset ID, rig, named action, viseme key, linked collection, coordinate convention, complexity estimate or provenance entry. Reject bad assets rather than compensating for them in shot code.
---

# Asset Contract

Each `assets/assets.yaml` entry includes logical ID, kind, version, checksum, Blender compatibility, file/collection, coordinate convention, complexity estimate and provenance.

Character entries additionally define armature, retarget profile, named action vocabulary and viseme mapping.

`pipe asset doctor <id>` performs two layers:
1. host/static manifest/path/hash validation;
2. Blender headless inspection of datablocks, armature, actions, shape keys, missing dependencies and configured complexity limits.

Never silently rename/make an action to satisfy a shot. Missing vocabulary is an admission failure or explicit asset-authoring task.
