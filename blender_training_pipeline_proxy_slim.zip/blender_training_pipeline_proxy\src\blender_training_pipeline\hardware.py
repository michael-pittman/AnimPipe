from __future__ import annotations

import json
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class GpuSnapshot:
    index: int
    uuid: str
    name: str
    memory_total_mib: int
    memory_free_mib: int
    driver_version: str


def query_gpus() -> list[GpuSnapshot]:
    fmt = "index,uuid,name,memory.total,memory.free,driver_version"
    cmd = ["nvidia-smi", f"--query-gpu={fmt}", "--format=csv,noheader,nounits"]
    result = subprocess.run(cmd, check=True, capture_output=True, text=True)
    rows: list[GpuSnapshot] = []
    for line in result.stdout.splitlines():
        if not line.strip():
            continue
        parts = [p.strip() for p in line.split(",")]
        if len(parts) != 6:
            raise RuntimeError(f"unexpected nvidia-smi row: {line}")
        rows.append(GpuSnapshot(int(parts[0]), parts[1], parts[2], int(parts[3]), int(parts[4]), parts[5]))
    return rows


def load_verified(path: Path) -> dict:
    if not path.exists():
        raise RuntimeError(f"verified hardware manifest missing: {path}")
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if manifest.get("status") != "pass":
        raise RuntimeError(f"verified hardware manifest is not PASS: {path}")
    return manifest


def verify_live_identity(manifest_path: Path) -> GpuSnapshot:
    manifest = load_verified(manifest_path)
    gpus = query_gpus()
    if len(gpus) != 1:
        raise RuntimeError(f"expected exactly one live GPU; found {len(gpus)}")
    gpu = gpus[0]
    expected = manifest["gpu"]
    if gpu.uuid != expected["uuid"] or gpu.name != expected["name"]:
        raise RuntimeError(
            f"GPU identity changed: expected {expected['uuid']} {expected['name']}, "
            f"found {gpu.uuid} {gpu.name}"
        )
    if gpu.memory_total_mib != int(expected["memory_total_mib"]):
        raise RuntimeError(
            f"GPU memory identity changed: expected {expected['memory_total_mib']} MiB, "
            f"found {gpu.memory_total_mib} MiB"
        )
    return gpu


def snapshot_dict(gpu: GpuSnapshot) -> dict:
    return asdict(gpu)


def refresh_gpu_uuid(manifest_path: Path) -> tuple[str, str]:
    """Update the GPU UUID in the manifest after a VM restart.

    Azure reassigns the UUID on every restart while keeping the same physical
    GPU model and VRAM. This function verifies name and memory still match
    before accepting the new UUID, then writes the manifest in-place.

    Returns (old_uuid, new_uuid).
    """
    manifest = load_verified(manifest_path)
    gpus = query_gpus()
    if len(gpus) != 1:
        raise RuntimeError(f"expected exactly one live GPU; found {len(gpus)}")
    gpu = gpus[0]
    expected = manifest["gpu"]
    if gpu.name != expected["name"]:
        raise RuntimeError(
            f"GPU model mismatch: manifest has '{expected['name']}', live is '{gpu.name}'. "
            "This is a different GPU; update the full manifest instead."
        )
    if gpu.memory_total_mib != int(expected["memory_total_mib"]):
        raise RuntimeError(
            f"GPU VRAM mismatch: manifest has {expected['memory_total_mib']} MiB, "
            f"live is {gpu.memory_total_mib} MiB."
        )
    old_uuid = expected["uuid"]
    manifest["gpu"]["uuid"] = gpu.uuid
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return old_uuid, gpu.uuid
