"""Assemble character performance from named actions on the NLA stack.

This is the primitive the animation-director composes with. Rather than
authoring raw keyframes, a shot sequences and blends actions that already exist
in the rig's action library — which is what makes the performance layer
generatable from config at all.

Blender 4.4 introduced slotted actions: an Action holds a separate channel bag
per slot, and assigning an Action to a strip without also picking a slot leaves
the strip evaluating nothing. That failure is silent in the viewport and in a
render, so slot assignment is handled explicitly here and asserted.
"""

from __future__ import annotations

from typing import Any

from .context import BuildContext, BuildError

_VALID_BLEND_TYPES = {"REPLACE", "COMBINE", "ADD", "SUBTRACT", "MULTIPLY"}


def _ensure_anim_data(obj: Any) -> Any:
    if obj.animation_data is None:
        obj.animation_data_create()
    return obj.animation_data


def _get_track(anim_data: Any, name: str) -> Any:
    for track in anim_data.nla_tracks:
        if track.name == name:
            return track
    track = anim_data.nla_tracks.new()
    track.name = name
    return track


def assign_slot(strip: Any, target: Any) -> str | None:
    """Pick the action slot this strip should evaluate.

    Preference order: a slot whose name matches the target object, then the first
    slot suitable for this strip. Returns the chosen slot identifier, or None on
    a pre-4.4 Blender where slots do not exist.
    """
    if not hasattr(strip, "action_suitable_slots"):
        return None

    suitable = list(strip.action_suitable_slots)
    if not suitable:
        raise BuildError(
            f"action '{strip.action.name}' has no slot suitable for '{target.name}'. "
            "The action was probably authored against a different ID type — "
            "an object-level action cannot drive an armature slot."
        )

    chosen = None
    for slot in suitable:
        name = getattr(slot, "name_display", getattr(slot, "name", ""))
        if name and (name == target.name or target.name.startswith(name)):
            chosen = slot
            break
    if chosen is None:
        chosen = suitable[0]

    strip.action_slot = chosen
    return getattr(chosen, "identifier", getattr(chosen, "name", None))


def build_strip(anim_data: Any, target: Any, spec: dict[str, Any], actions: dict[str, Any]) -> Any:
    action_name = spec["action"]
    action = actions.get(action_name)
    if action is None:
        raise BuildError(
            f"action '{action_name}' was not linked for '{target.name}'. "
            "Every action a shot references must be declared in the rig contract."
        )

    blend_type = str(spec.get("blend_type", "REPLACE")).upper()
    if blend_type not in _VALID_BLEND_TYPES:
        raise BuildError(f"unknown NLA blend_type '{blend_type}' for action '{action_name}'")

    start = int(spec["start_frame"])
    end = int(spec["end_frame"])
    track = _get_track(anim_data, str(spec.get("track", "performance")))
    strip = track.strips.new(f"{action_name}@{start}", start, action)

    slot_id = assign_slot(strip, target)

    # Set the source range before the strip range: changing frame_end after
    # action_frame_* has been set is what produces accidental time scaling.
    strip.action_frame_start = action.frame_range[0]
    strip.action_frame_end = action.frame_range[1]

    requested = end - start
    source = max(1.0, strip.action_frame_end - strip.action_frame_start)
    if requested > 0:
        # Repeat rather than scale: time-stretching a performance changes how it
        # reads, whereas a loop is what "hold this idle for 148 frames" means.
        strip.repeat = max(1.0, requested / source)
    strip.frame_end_ui = max(start + 1, end)

    strip.blend_type = blend_type
    strip.blend_in = float(spec.get("blend_in", 0))
    strip.blend_out = float(spec.get("blend_out", 0))
    strip.influence = float(spec.get("influence", 1.0))
    if strip.influence != 1.0:
        strip.use_animated_influence = True
    strip.extrapolation = "HOLD_FORWARD" if blend_type == "REPLACE" else "NOTHING"

    return strip, slot_id


def build_performances(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> None:
    for member in ctx.cfg.get("cast", []):
        asset_id = member["id"]
        handles = cast[asset_id]
        armature = handles["armature"]
        actions = handles["actions"]
        specs = member.get("actions", [])
        if not specs:
            continue

        anim_data = _ensure_anim_data(armature)
        # An action left on animation_data overrides the whole NLA stack, which
        # makes a correctly-built stack render as if it were empty.
        anim_data.action = None

        slots_assigned = 0
        for spec in specs:
            _, slot_id = build_strip(anim_data, armature, spec, actions)
            if slot_id is not None:
                slots_assigned += 1

        ctx.assert_that(
            f"NLA stack built for '{asset_id}'",
            len(anim_data.nla_tracks) > 0,
            f"{len(specs)} strips across {len(anim_data.nla_tracks)} tracks",
        )
        if hasattr(bpy_strip_probe(), "action_suitable_slots"):
            ctx.assert_that(
                f"action slots assigned for '{asset_id}'",
                slots_assigned == len(specs),
                f"{slots_assigned}/{len(specs)} strips have a slot",
            )


def bpy_strip_probe() -> Any:
    """Return the NlaStrip RNA type so slot support can be probed once."""
    import bpy

    return bpy.types.NlaStrip
