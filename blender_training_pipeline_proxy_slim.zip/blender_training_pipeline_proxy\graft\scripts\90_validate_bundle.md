# scripts/90_validate_bundle.py

- error · function · L21-L22 — def error(message: str) -> None
- sha256 · function · L25-L30 — def sha256(path: Path) -> str
- frontmatter · function · L33-L46 — def frontmatter(path: Path) -> dict
