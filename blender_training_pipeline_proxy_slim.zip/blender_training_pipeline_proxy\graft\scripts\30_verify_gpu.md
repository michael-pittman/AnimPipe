# scripts/30_verify_gpu.py

- version_tuple · function · L11-L12 — def version_tuple(s: str) -> tuple[int, ...]
- main · function · L15-L45 — def main() -> None
