# asset_system/models.py

- StrictModel · class · L9-L10 — class StrictModel(BaseModel)
- Coordinates · class · L13-L17 — class Coordinates(StrictModel)
- RigContract · class · L20-L25 — class RigContract(StrictModel)
- Complexity · class · L28-L30 — class Complexity(StrictModel)
- AssetEntry · class · L33-L70 — class AssetEntry(StrictModel)
- validate_contract · method · L55-L70 — def validate_contract(self) -> AssetEntry
- AssetManifest · class · L73-L74 — class AssetManifest(StrictModel)
