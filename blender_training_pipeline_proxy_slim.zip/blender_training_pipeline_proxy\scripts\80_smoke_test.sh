#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PY=.venv/bin/python
[[ -x "$PY" ]] || { echo 'Missing .venv; run scripts/50_install_python_envs.sh first.' >&2; exit 2; }
"$PY" - <<'PY'
from pathlib import Path
import json
p=Path('reports/environment/hardware-verified.json')
assert p.exists() and json.loads(p.read_text())['status']=='pass'
PY
nvidia-smi
docker run --rm --gpus all ubuntu:24.04 nvidia-smi >/dev/null
blender --version | head -n 2
blender -b --factory-startup --python scripts/blender_gpu_probe.py
blender -b --factory-startup --python scripts/45_blender_api_contract_probe.py
ffmpeg -hide_banner -encoders 2>/dev/null | grep -q 'h264_nvenc'
for filter in lut3d subtitles overlay; do ffmpeg -hide_banner -filters 2>/dev/null | grep -q " $filter "; done
rhubarb --version >/dev/null
"$PY" -m compileall -q src asset_system blend_build scripts tests
PYTHONPATH=src:. "$PY" -m pytest -q
.venv/bin/pipe proxy validate
.venv/bin/ruff check src asset_system tests scripts
"$PY" scripts/95_generate_schemas.py >/dev/null
"$PY" scripts/96_package_skills.py >/dev/null
"$PY" scripts/90_validate_bundle.py >/dev/null
.venv/bin/pipe config compile config/base.yaml config/project.yaml config/scene/module_01.yaml config/shot/m01_s030.yaml -o build/m01_s030/resolved_config.json
.venv/bin/pipe config validate-scene config/scene/module_01.yaml
.venv/bin/pipe asset export-manifest assets/assets.yaml.example -o build/assets.example.resolved.json
curl -fsS http://127.0.0.1:11434/api/tags >/dev/null
key=$(grep '^KOKORO_API_KEY=' infra/kokoro.env | cut -d= -f2-)
curl -fsS -H "Authorization: Bearer $key" http://127.0.0.1:8880/v1/models >/dev/null
mkdir -p reports/environment
date -Is > reports/environment/smoke-test-passed.txt
echo 'All configured Phase 0 smoke tests passed.'
