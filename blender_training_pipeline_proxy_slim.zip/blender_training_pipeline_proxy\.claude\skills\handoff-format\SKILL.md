---
name: handoff-format
description: The structured envelope every pipeline agent emits when finishing a task or handing work to another agent. Use this at the end of any pipeline task, whenever you are blocked, whenever you are passing artifacts downstream, and whenever you would otherwise write a prose summary of what you did. Prose handoffs cannot be validated, routed, or replayed by the orchestrator, so consult this skill before writing your final output rather than after.
---

# Handoff Format

Agents in this pipeline talk to an orchestrator, not to a human reader. A prose summary
cannot be routed, retried, or diffed. Every agent's terminal output is a single JSON
envelope written to `reports/<agent>/<task_id>.json` and echoed to stdout.

## The envelope

```json
{
  "agent": "blender-builder",
  "task_id": "m01_s030-build",
  "contract_version": "1.4.0",
  "status": "ok",
  "summary": "Built m01_s030: 2 characters linked, 148 frames, NLA stack resolved.",
  "inputs": ["config/shot/m01_s030.yaml", "cache/audio/m01_s030.visemes.json"],
  "artifacts": [
    {"path": "build/m01_s030.blend", "kind": "blend", "sha256": "…"}
  ],
  "assertions": [
    {"check": "all cast IDs resolved", "passed": true},
    {"check": "no unkeyed override transforms", "passed": true}
  ],
  "blockers": [],
  "handoff_to": ["pipeline-runner"],
  "notes": []
}
```

## Field rules

**`status`** — exactly one of:
- `ok` — the task completed and downstream agents may proceed
- `ok_with_warnings` — completed, but something downstream should look at. Warnings go in
  `notes`, not `blockers`
- `blocked` — could not complete. `blockers` must be non-empty and `artifacts` may be
  partial
- `rejected` — the input was invalid and the task should not be retried as-is. Used mainly
  by `asset-validator` and `pipe validate`

Never report `ok` with an empty `artifacts` array on a task that was supposed to produce
something. That combination is how a broken step gets mistaken for a no-op and passes
silently down the chain.

**`summary`** — one sentence, factual, no hedging. It is what a human sees in the n8n run
log. Say what was produced and the two or three numbers that matter.

**`inputs`** — every file you read that affected the output. This is what makes a run
replayable and what lets QA bisect a regression to a changed input.

**`artifacts`** — everything you produced that another agent or a human needs. Include a
hash so downstream steps can detect staleness without re-reading.

**`assertions`** — the self-checks you ran. Each is a short human-readable claim plus a
boolean. Report failed assertions honestly with `status: ok_with_warnings` or `blocked`;
a passing assertion list that doesn't reflect what actually happened is worse than no list.

**`blockers`** — see below.

**`handoff_to`** — which agents should run next. Empty if this terminates the chain.

**`notes`** — free-form observations for a human. This is the only field where prose
belongs, and it should be short.

## Blockers

```json
{
  "type": "contract_gap",
  "detail": "camera shake amplitude is not expressible in the schema",
  "needs_agent": "pipeline-architect",
  "blocking_artifact": "config/shot/m01_s030.yaml",
  "workaround": "none"
}
```

Types: `contract_gap`, `asset_missing`, `asset_invalid`, `boundary_violation`,
`env_missing`, `resource_limit`, `ambiguous_intent`, `upstream_failed`.

`needs_agent` is required — an unrouted blocker stalls the pipeline until a human notices.
If you genuinely don't know who owns it, say `pipeline-architect` and explain in `detail`.

## Report failure plainly

The strong pull when a task half-works is to describe it as success with caveats. Resist
it. A `blocked` status with a clear blocker costs one routing hop. A false `ok` costs a
render, a QA cycle, and someone's afternoon tracing why the video looks wrong.

Similarly: if you worked around something rather than solving it, that goes in `notes`
with enough detail to find it later. Undocumented workarounds accumulate into a pipeline
nobody can reason about.

## Prose is a supplement, never the artifact

You may narrate what you did in conversation. The envelope is still required, still
complete, and still the thing the orchestrator reads. Do not assume a human is reading
your output at all.
