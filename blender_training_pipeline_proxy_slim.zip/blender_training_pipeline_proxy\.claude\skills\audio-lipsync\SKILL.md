---
name: audio-lipsync
description: Speech, alignment and viseme artifact rules. Use when synthesizing narration/dialogue, selecting TTS providers, verifying speech timing, generating Rhubarb cues or mapping cues to character shape keys. Audio artifacts are content-addressed and provider details do not leak into shot semantics.
---

# Audio and Lip Sync

Default TTS provider: local Kokoro HTTP service, CPU profile. Experimental providers implement the same interface.

Pipeline: text + voice config -> WAV -> faster-whisper verification/word timings -> Rhubarb viseme JSON -> Blender shape-key cues.

Acquire the GPU lock only when using a GPU speech/alignment provider. Kokoro CPU needs no GPU lock.

Cache keys include normalized text, provider/model/voice/settings and contract version. Do not regenerate unchanged cues.
