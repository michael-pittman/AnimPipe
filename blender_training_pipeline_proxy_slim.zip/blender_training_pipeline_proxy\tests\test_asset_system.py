import hashlib
from pathlib import Path

import yaml

from asset_system.doctor import static_doctor


def test_static_asset_doctor(tmp_path: Path) -> None:
    assets = tmp_path / "assets"
    assets.mkdir()
    blend = assets / "character.blend"
    blend.write_bytes(b"synthetic-test-asset")
    digest = hashlib.sha256(blend.read_bytes()).hexdigest()
    manifest = tmp_path / "assets.yaml"
    manifest.write_text(
        yaml.safe_dump(
            {
                "assets": {
                    "char.test": {
                        "kind": "character",
                        "version": "1.0.0",
                        "sha256": digest,
                        "file": "character.blend",
                        "collection": "CHAR_test",
                        "rig": {
                            "armature": "RIG_test",
                            "retarget_profile": "humanoid_v1",
                            "required_actions": ["idle_neutral"],
                            "visemes": {"A": "viseme_A"},
                        },
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    report = static_doctor(manifest, "char.test", assets)
    assert report["passed"] is True
