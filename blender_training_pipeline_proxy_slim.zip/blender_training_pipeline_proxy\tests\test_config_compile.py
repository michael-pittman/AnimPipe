from pathlib import Path

from blender_training_pipeline.config_compile import compile_pipeline, validate_director_script

ROOT = Path(__file__).resolve().parents[1]
LAYERS = [
    ROOT / "config/base.yaml",
    ROOT / "config/project.yaml",
    ROOT / "config/scene/module_01.yaml",
    ROOT / "config/shot/m01_s030.yaml",
]


def test_compile_is_deterministic() -> None:
    model_a, raw_a, hash_a = compile_pipeline(LAYERS)
    model_b, raw_b, hash_b = compile_pipeline(LAYERS)
    assert model_a.metadata.shot_id == "m01_s030"
    assert model_a.scene is not None and model_a.scene.id == "module_01_scene_01"
    assert raw_a == raw_b
    assert hash_a == hash_b


def test_director_script_validates() -> None:
    doc = validate_director_script(ROOT / "config/scene/module_01.yaml")
    assert doc.scene.shots == ["m01_s030"]
