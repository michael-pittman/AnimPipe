#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
import json
from pathlib import Path
p=Path('reports/environment/hardware-preflight.json')
if not p.exists() or json.loads(p.read_text()).get('status') != 'pass':
    raise SystemExit('PASS hardware-preflight.json required')
PY
if command -v mokutil >/dev/null 2>&1 && mokutil --sb-state 2>/dev/null | grep -qi 'enabled'; then
  echo 'Secure Boot is enabled. Microsoft GRID procedure requires it disabled.' >&2; exit 3
fi
if [[ -e /dev/tpmrm0 || -e /dev/tpm0 ]]; then
  echo 'A TPM device is visible. Confirm Azure vTPM is disabled before using the documented GRID procedure.' >&2; exit 4
fi
sudo apt-get update
sudo apt-get install -y build-essential "linux-headers-$(uname -r)"

DRIVER='NVIDIA-Linux-x86_64-595.58.03-grid-azure.run'
URL='https://download.microsoft.com/download/51239696-ec04-4c02-a6b3-1d9c608fb57c/NVIDIA-Linux-x86_64-595.58.03-grid-azure.run'
mkdir -p scratch/install
cd scratch/install
curl -fL "$URL" -o "$DRIVER"
chmod 700 "$DRIVER"
echo 'Launching the Microsoft-documented NVIDIA GRID installer.'
sudo sh "./$DRIVER"
echo 'GRID installer finished. Reboot the VM before running scripts/30_verify_gpu.py.'
