# src/blender_training_pipeline/proxy_acceptance.py

- ProxyAcceptanceError · class · L23-L24 — class ProxyAcceptanceError(RuntimeError)
- _write_config · function · L27-L33 — def _write_config(model: PipelineConfig, output: Path) -> Path
- _concat · function · L36-L49 — def _concat(segments: list[Path], output: Path) -> Path
- _shot_specs · function · L52-L57 — def _shot_specs(plan_path: Path) -> list[dict[str, Any]]
- purge_failed_dirs · function · L60-L89 — def purge_failed_dirs( root: Path, keep_successful: bool = True, dry_run: bool = False, ) -> tuple[list[tuple[Path, str]], int]
- _rotate_work_dir · function · L92-L102 — def _rotate_work_dir(work_dir: Path, keep: int = 3) -> None
- run_proxy_acceptance · function · L105-L245 — def run_proxy_acceptance( *, plan_path: Path = Path("proxy_kit/acceptance.yaml"), manifest: Path = Path("build/assets.proxy.resolved.json"), assets_root: Path = Path("assets"), work_dir: Path = Path("build/proxy_acceptance"), hardware_manifest: Path = Path("reports/environment/hardware-verified.json"), preview: bool = True, audio: bool = True, qa: bool = True, keep_runs: int = 3, auto_purge: bool = True, skip_existing_audio: bool = False, ) -> dict[str, Any]
