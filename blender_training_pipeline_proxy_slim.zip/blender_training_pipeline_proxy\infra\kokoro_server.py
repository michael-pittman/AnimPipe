"""Minimal OpenAI-compatible TTS server backed by the kokoro Python package.

Exposes POST /v1/audio/speech — the same contract KokoroClient uses.
Run with: python infra/kokoro_server.py
"""
from __future__ import annotations

import io
import os
import struct
import wave
from pathlib import Path
from typing import Literal

import uvicorn
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

app = FastAPI(title="kokoro-native-server", version="1.0.0")

# Lazy-load the kokoro pipeline so the process starts fast and
# downloads model weights on first request.
_pipeline = None
_pipeline_lang: str | None = None


def _get_pipeline(lang_code: str = "a"):
    global _pipeline, _pipeline_lang
    if _pipeline is None or _pipeline_lang != lang_code:
        from kokoro import KPipeline  # type: ignore[import]
        _pipeline = KPipeline(lang_code=lang_code)
        _pipeline_lang = lang_code
    return _pipeline


def _pcm_to_wav(samples, sample_rate: int = 24000) -> bytes:
    import numpy as np
    # Accept PyTorch tensors or NumPy arrays
    if hasattr(samples, "numpy"):
        arr = samples.detach().cpu().numpy()
    elif hasattr(samples, "cpu"):
        arr = samples.cpu().numpy()
    else:
        arr = np.asarray(samples)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)  # 16-bit
        wf.setframerate(sample_rate)
        pcm = (np.clip(arr, -1.0, 1.0) * 32767).astype("<i2")
        wf.writeframes(pcm.tobytes())
    return buf.getvalue()


# Voice → lang_code mapping for kokoro
_VOICE_LANG: dict[str, str] = {
    "af_heart": "a", "af_alloy": "a", "af_aoede": "a",
    "am_adam": "a", "am_echo": "a",
    "bf_emma": "b", "bm_george": "b",
}


class TTSRequest(BaseModel):
    model: str = "tts-1"
    input: str
    voice: str = "af_heart"
    speed: float = 1.0
    response_format: Literal["wav", "mp3", "opus", "aac", "flac", "pcm"] = "wav"


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/v1/audio/speech")
async def synthesize(req: TTSRequest, request: Request):
    # Optional API-key check — load from infra/kokoro.env if present
    env_key = _load_api_key()
    if env_key:
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer ") or auth[7:] != env_key:
            raise HTTPException(status_code=401, detail="Unauthorized")

    lang_code = _VOICE_LANG.get(req.voice, "a")
    pipeline = _get_pipeline(lang_code)

    import numpy as np
    import torch

    chunks = []
    for _, _, audio in pipeline(req.input, voice=req.voice, speed=req.speed):
        if audio is not None:
            chunks.append(audio)

    if not chunks:
        raise HTTPException(status_code=500, detail="kokoro produced no audio")

    if len(chunks) == 1:
        samples = chunks[0]
    elif hasattr(chunks[0], "numpy"):
        samples = torch.cat(chunks)
    else:
        samples = np.concatenate([np.asarray(c) for c in chunks])
    wav_bytes = _pcm_to_wav(samples)

    return Response(content=wav_bytes, media_type="audio/wav")


def _load_api_key() -> str | None:
    env_path = Path(__file__).parent / "kokoro.env"
    if not env_path.exists():
        return None
    for line in env_path.read_text(encoding="utf-8").splitlines():
        if line.startswith("KOKORO_API_KEY="):
            val = line.split("=", 1)[1].strip()
            return val if val and val != "replace-with-random-local-key" else None
    return None


if __name__ == "__main__":
    port = int(os.getenv("KOKORO_PORT", "8880"))
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="info")
