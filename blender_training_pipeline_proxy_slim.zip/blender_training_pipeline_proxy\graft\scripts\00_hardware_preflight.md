# scripts/00_hardware_preflight.py

- imds · function · L11-L17 — def imds() -> dict
- mem_gib · function · L20-L36 — def mem_gib() -> float
- MEMSTATUS · class · L23-L28 — class MEMSTATUS(ctypes.Structure)
- nvidia_pci · function · L39-L76 — def nvidia_pci() -> list[dict]
- main · function · L79-L103 — def main() -> None
