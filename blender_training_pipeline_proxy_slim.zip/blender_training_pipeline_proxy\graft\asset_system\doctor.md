# asset_system/doctor.py

- file_sha256 · function · L12-L17 — def file_sha256(path: Path) -> str
- safe_asset_path · function · L20-L27 — def safe_asset_path(assets_root: Path, relative: str) -> Path
- static_doctor · function · L30-L48 — def static_doctor(manifest_path: Path, asset_id: str, assets_root: Path) -> dict
- export_manifest_json · function · L51-L60 — def export_manifest_json(manifest: Path, output: Path) -> Path
