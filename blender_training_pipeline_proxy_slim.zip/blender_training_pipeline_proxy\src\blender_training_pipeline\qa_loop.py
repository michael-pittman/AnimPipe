from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

import httpx

from .config_patch import apply_review_candidate
from .delivery import build_shot, contact_sheet, encode, render_frames, sample_video_frames
from .gpu_lock import gpu_lock
from .models import PipelineConfig
from .qa_models import VisualReview
from .vision_review import ModelUnavailableError, review_preview


def _prewarm_vlm(model: str, base_url: str = "http://127.0.0.1:11434") -> None:
    """Load the VLM model into VRAM before the render so it stays loaded through inference.

    Avoids the CUDA re-init crash that happens when the model reloads right after
    a Cycles/OptiX session exits.  keep_alive=180 keeps it alive for 3 minutes â€”
    longer than any preview render.
    """
    try:
        with httpx.Client(timeout=60.0) as client:
            client.post(
                f"{base_url}/api/chat",
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": "warmup"}],
                    "stream": False,
                    "keep_alive": 180,
                    "options": {"num_predict": 1},
                },
            )
    except Exception:
        pass  # pre-warm is best-effort; inference retry handles real failures


def mean_review_score(review: VisualReview) -> float:
    dimensions = [
        review.framing,
        review.legibility,
        review.staging,
        review.lighting,
        review.continuity,
        review.instructional_intent,
    ]
    return sum(item.score for item in dimensions) / len(dimensions)


def revision_decision(
    review: VisualReview,
    config: PipelineConfig,
    *,
    iteration: int,
    prior_score: float | None,
) -> tuple[str, str]:
    if review.verdict == "pass":
        return "pass", "vision critic passed the preview"
    if review.verdict == "escalate":
        return "escalate", "vision critic requested human escalation"
    if iteration >= config.qa.max_revisions:
        return "escalate", f"maximum revision count reached ({config.qa.max_revisions})"
    if not review.changes:
        return "escalate", "revision requested without any config changes"
    score = mean_review_score(review)
    if prior_score is not None:
        improvement = score - prior_score
        if improvement < config.qa.min_score_improvement:
            return (
                "escalate",
                f"score improvement {improvement:.4f} is below required "
                f"{config.qa.min_score_improvement:.4f}",
            )
    return "revise", "validated config-only revision may proceed"


def _prior_score(path: Path | None) -> float | None:
    if path is None:
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    value = data.get("score")
    return float(value) if value is not None else None


def review_iteration(
    *,
    preview: Path,
    intent: Path,
    resolved_config: Path,
    report: Path,
    candidate_config: Path | None = None,
    iteration: int = 0,
    prior_report: Path | None = None,
    hardware_manifest: Path = Path("reports/environment/hardware-verified.json"),
) -> dict[str, Any]:
    if iteration < 0:
        raise ValueError("iteration must be >= 0")
    raw = json.loads(resolved_config.read_text(encoding="utf-8"))
    config = PipelineConfig.model_validate(raw)
    policy = config.resource_policy.gpu
    workload = policy.workloads["vision_qa"]
    with gpu_lock(
        workload="vision_qa",
        estimated_peak_mib=workload.estimated_peak_mib,
        reserve_mib=policy.reserve_mib,
        timeout_seconds=policy.lock_timeout_seconds,
        manifest_path=hardware_manifest,
    ):
        review = review_preview(
            preview,
            intent.read_text(encoding="utf-8"),
            resolved_config.read_text(encoding="utf-8"),
            model=config.qa.vision_model,
        )
    score = mean_review_score(review)
    prior_score = _prior_score(prior_report)
    action, reason = revision_decision(review, config, iteration=iteration, prior_score=prior_score)
    result: dict[str, Any] = {
        "iteration": iteration,
        "critic_verdict": review.verdict,
        "action": action,
        "reason": reason,
        "score": score,
        "prior_score": prior_score,
        "max_revisions": config.qa.max_revisions,
        "min_score_improvement": config.qa.min_score_improvement,
        "review": review.model_dump(mode="json"),
    }
    if action == "revise" and candidate_config is not None:
        candidate = apply_review_candidate(raw, review)
        candidate_config.parent.mkdir(parents=True, exist_ok=True)
        candidate_config.write_text(
            json.dumps(candidate, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        result["candidate_config"] = str(candidate_config)
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result


def run_loop(
    *,
    resolved_config: Path,
    intent: Path,
    asset_manifest: Path,
    assets_root: Path,
    work_dir: Path,
    hardware_manifest: Path = Path("reports/environment/hardware-verified.json"),
    keep_frames: bool = False,
) -> dict[str, Any]:
    """Own the bounded previewâ†’inspectâ†’revise loop.

    Each iteration is a clean deterministic rebuild. The critic can only propose
    allow-listed config patches, and every candidate is revalidated before the next build.
    """
    work_dir.mkdir(parents=True, exist_ok=True)
    current = work_dir / "resolved-r0.json"
    if resolved_config.resolve() != current.resolve():
        shutil.copy2(resolved_config, current)
    else:
        current = resolved_config

    # Fast-fail before building if the VLM model isn't loaded.
    raw0 = json.loads(current.read_text(encoding="utf-8"))
    cfg0 = PipelineConfig.model_validate(raw0)
    from .vision_review import _model_available
    if not _model_available("http://127.0.0.1:11434", cfg0.qa.vision_model):
        result = {
            "status": "skip",
            "reason": (
                f"VLM model '{cfg0.qa.vision_model}' is not available in Ollama â€” "
                "QA skipped. Pull the model to enable visual QA."
            ),
            "final_config": str(resolved_config),
            "history": [],
        }
        (work_dir / "qa-loop.json").write_text(json.dumps(result, indent=2) + "\n")
        return result

    prior_report: Path | None = None
    history: list[dict[str, Any]] = []
    iteration = 0

    while True:
        raw = json.loads(current.read_text(encoding="utf-8"))
        cfg = PipelineConfig.model_validate(raw)
        blend = work_dir / f"preview-r{iteration}.blend"
        build_report = work_dir / f"build-r{iteration}.json"
        report = build_shot(
            config=current,
            manifest=asset_manifest,
            output=blend,
            assets_root=assets_root,
            preview=True,
            report=build_report,
        )
        if report.get("status") != "ok":
            final = {"status": "escalate", "reason": "preview build failed", "history": history, "build": report}
            (work_dir / "qa-loop.json").write_text(json.dumps(final, indent=2) + "\n")
            return final

        frames_dir = work_dir / f"frames-r{iteration}"
        frames = cfg.preview.contact_sheet_frames or None
        policy = cfg.resource_policy.gpu
        workload = policy.workloads["cycles_preview"]
        # Pre-warm the VLM model before rendering so it's already loaded in VRAM.
        # This avoids the CUDA re-init crash loop that occurs when the model tries
        # to load immediately after Blender's Cycles/OptiX session exits.
        _prewarm_vlm(cfg.qa.vision_model)
        with gpu_lock(
            workload="cycles_preview",
            estimated_peak_mib=workload.estimated_peak_mib,
            reserve_mib=policy.reserve_mib,
            timeout_seconds=policy.lock_timeout_seconds,
            manifest_path=hardware_manifest,
        ):
            rendered = render_frames(blend=blend, output_dir=frames_dir, frames=frames)

        sheet = work_dir / f"contact-r{iteration}.png"
        pngs = [p for p in rendered if p.suffix.lower() == ".png"]
        if not pngs:
            raise RuntimeError("QA loop requires PNG preview frames for contact-sheet/VLM review")
        review_frames = pngs
        review_frames = pngs
        sampled_frames = sorted(cfg.preview.contact_sheet_frames or [int(p.stem) for p in pngs])
        dense_frames_dir = work_dir / f"delivery-input-r{iteration}"
        dense_frames_dir.mkdir(parents=True, exist_ok=True)
        dense_map = {frame: index for index, frame in enumerate(sampled_frames, start=1)}
        for source in pngs:
            original_frame = int(source.stem)
            dense_index = dense_map.get(original_frame)
            if dense_index is None:
                continue
            shutil.copy2(source, dense_frames_dir / f"{dense_index:04d}.png")

        review_dialogue: list[dict[str, Any]] = []
        for line in cfg.dialogue:
            active = [dense_map[frame] for frame in sampled_frames if line.start_frame <= frame <= line.end_frame]
            if not active:
                continue
            payload = line.model_dump(mode="json")
            payload["start_frame"] = min(active)
            payload["end_frame"] = max(active)
            review_dialogue.append(payload)

        review_comp = cfg.comp.model_dump(mode="json")
        review_overlays: list[dict[str, Any]] = []
        for spec in review_comp.get("overlay_slots") or []:
            active = [
                dense_map[frame]
                for frame in sampled_frames
                if int(spec["start_frame"]) <= frame <= int(spec["end_frame"])]
            if not active:
                continue
            payload = dict(spec)
            payload["start_frame"] = min(active)
            payload["end_frame"] = max(active)
            review_overlays.append(payload)
        review_comp["overlay_slots"] = review_overlays

        delivery_preview = work_dir / f"delivery-r{iteration}.mp4"
        delivery_frames_dir = work_dir / f"delivery-frames-r{iteration}"
        review_frame_numbers = list(range(1, len(sampled_frames) + 1))
        encode(
            frames_dir=dense_frames_dir,
            output=delivery_preview,
            fps=cfg.render.fps,
            frame_start=1,
            codec="libx264",
            cq=cfg.output.cq,
            audio=None,
            audio_codec=cfg.output.audio_codec,
            metadata=cfg.output.metadata,
            comp=review_comp,
            dialogue=review_dialogue,
            asset_manifest=asset_manifest,
            assets_root=assets_root,
        )
        review_frames = sample_video_frames(
            video=delivery_preview, frames=review_frame_numbers, output_dir=delivery_frames_dir
        )
        contact_sheet(frames=review_frames, output=sheet)
        if not keep_frames:
            shutil.rmtree(frames_dir, ignore_errors=True)
            shutil.rmtree(dense_frames_dir, ignore_errors=True)
            shutil.rmtree(delivery_frames_dir, ignore_errors=True)
            delivery_preview.unlink(missing_ok=True)
        review_report = work_dir / f"review-r{iteration}.json"
        candidate = work_dir / f"resolved-r{iteration + 1}.json"
        try:
            result = review_iteration(
                preview=sheet,
                intent=intent,
                resolved_config=current,
                report=review_report,
                candidate_config=candidate,
                iteration=iteration,
                prior_report=prior_report,
                hardware_manifest=hardware_manifest,
            )
        except Exception as exc:
            final = {
                "status": "escalate",
                "reason": f"VLM review raised an exception: {exc}",
                "iterations": iteration + 1,
                "final_config": str(current),
                "history": history,
            }
            (work_dir / "qa-loop.json").write_text(json.dumps(final, indent=2) + "\n")
            return final
        history.append(result)
        if result["action"] != "revise":
            if not keep_frames:
                for _d in work_dir.glob("frames-r*"):
                    shutil.rmtree(_d, ignore_errors=True)
            final = {
                "status": result["action"],
                "reason": result["reason"],
                "iterations": iteration + 1,
                "final_config": str(current),
                "history": history,
            }
            (work_dir / "qa-loop.json").write_text(json.dumps(final, indent=2) + "\n")
            return final
        prior_report = review_report
        current = candidate
        iteration += 1
