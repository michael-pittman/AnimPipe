from pathlib import Path

from PIL import Image

from blender_training_pipeline.frame_regression import compare_images


def test_identical_image_metrics(tmp_path: Path) -> None:
    a = tmp_path / "a.png"
    b = tmp_path / "b.png"
    Image.new("RGB", (64, 64), (100, 120, 140)).save(a)
    Image.new("RGB", (64, 64), (100, 120, 140)).save(b)
    result = compare_images(a, b)
    assert result["phash_distance"] == 0
    assert result["ssim"] == 1.0
    assert result["current_sha256"] == result["baseline_sha256"]
