# src/blender_training_pipeline/qa_models.py

- StrictModel · class · L8-L9 — class StrictModel(BaseModel)
- DimensionReview · class · L12-L15 — class DimensionReview(StrictModel)
- ConfigChange · class · L18-L22 — class ConfigChange(StrictModel)
- VisualReview · class · L25-L34 — class VisualReview(StrictModel)
