# src/blender_training_pipeline/proxy_models.py

- StrictModel · class · L10-L11 — class StrictModel(BaseModel)
- ProxyActionSpec · class · L14-L20 — class ProxyActionSpec(StrictModel)
- ProxyPropSpec · class · L23-L29 — class ProxyPropSpec(StrictModel)
- ProxyPathSpec · class · L32-L41 — class ProxyPathSpec(StrictModel)
- enough_points · method · L38-L41 — def enough_points(self) -> "ProxyPathSpec"
- ProxyCharacterGeometry · class · L44-L52 — class ProxyCharacterGeometry(StrictModel)
- ProxyCharacterSpec · class · L55-L64 — class ProxyCharacterSpec(StrictModel)
- ProxySetElement · class · L67-L72 — class ProxySetElement(StrictModel)
- ProxySetSpec · class · L75-L81 — class ProxySetSpec(StrictModel)
- ProxyOverlaySpec · class · L84-L90 — class ProxyOverlaySpec(StrictModel)
- ProxyKitSpec · class · L93-L115 — class ProxyKitSpec(StrictModel)
- unique_ids · method · L105-L115 — def unique_ids(self) -> "ProxyKitSpec"
