from blender_training_pipeline.models import PipelineConfig
from blender_training_pipeline.qa_loop import revision_decision
from blender_training_pipeline.qa_models import ConfigChange, DimensionReview, VisualReview


def _review(verdict: str = "revise", score: float = 0.8, changes: bool = True) -> VisualReview:
    dim = DimensionReview(grade="warn" if verdict == "revise" else "pass", note="test", score=score)
    return VisualReview(
        verdict=verdict,
        summary="test",
        framing=dim,
        legibility=dim,
        staging=dim,
        lighting=dim,
        continuity=dim,
        instructional_intent=dim,
        changes=[ConfigChange(path="camera.lens_mm", proposed_value=60.0, rationale="test", confidence=0.9)] if changes else [],
    )


def test_revision_allowed_before_cap() -> None:
    cfg = PipelineConfig()
    action, _ = revision_decision(_review(), cfg, iteration=0, prior_score=None)
    assert action == "revise"


def test_revision_escalates_at_cap() -> None:
    cfg = PipelineConfig()
    action, _ = revision_decision(_review(), cfg, iteration=cfg.qa.max_revisions, prior_score=None)
    assert action == "escalate"


def test_revision_escalates_without_minimum_improvement() -> None:
    cfg = PipelineConfig()
    action, _ = revision_decision(_review(score=0.80), cfg, iteration=1, prior_score=0.79)
    assert action == "escalate"
