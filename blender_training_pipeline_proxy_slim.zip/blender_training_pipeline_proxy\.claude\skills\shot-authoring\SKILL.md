---
name: shot-authoring
description: Converts director-script beats into concise shot configuration using admitted asset/action vocabulary. Use for camera, blocking, NLA performance, lighting intent, dialogue timing and preview choices. Do not invent filesystem paths, unavailable actions, builder code, or values outside the schema.
---

# Shot Authoring

Read the relevant director-script scene, the current Pydantic schema and admitted asset reports first.

A shot config should contain only meaningful overrides from lower layers. Express performance with named NLA actions and blends; express blocking with config transforms/easing; express camera/lighting through schema fields.

After authoring, compile with OmegaConf and validate with Pydantic. Never hand off YAML that has not produced a valid resolved JSON artifact.
