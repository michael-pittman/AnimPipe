# Third-Party Notices

## Blender-agent supplied archive
Source supplied by the user as `blender-agent-main.zip`.
Archive SHA-256: see `vendor/blender-agent-upstream/ARCHIVE_SHA256.txt`.
Upstream revision embedded in archive comment: `2ad26913037ed0e1af4ae719efd37d4116a29b3a`.

The upstream README states that Blender Agent is a fork of Blender Lab's Blender MCP work and is licensed **GPL-3.0-or-later**, matching upstream. This bundle preserves the supplied source archive and exact selected upstream skill files under `vendor/blender-agent-upstream/` for provenance.

Active adapted skills derived from the supplied repo:
- `animating-basics`
- `lighting-setups`

Exact unmodified source copies for both are preserved under `vendor/blender-agent-upstream/skills/`.

The upstream `animating-at-scale`, `posing`, and several rigging skills rely on custom MCP extension tools not present in the official Blender Lab MCP configuration used by this project. They are therefore not installed as active Claude project skills. See `BLENDER_AGENT_INTEGRATION.md`.

## User-provided skills
The six `.skill` archives supplied by the user are preserved verbatim under `vendor/user-supplied-skills/` and at the root of `skill_packages/`. Active project copies live under `.claude/skills/`; generated distributable copies of all active skills live under `skill_packages/generated/`.

## Blender / Blender Python
Blender and `bpy` are GPL-licensed Blender Foundation software. They are installed separately and are not redistributed by this bundle.

## Kokoro/Ollama/model licenses
Container images and model weights are downloaded separately. Review and comply with their current upstream licenses before production distribution.
