"""Lighting rigs, blocking, lip sync, and compositing.

These three stages share a property: they are all pure functions of config plus
the linked cast, so they can be rebuilt from scratch on every build without any
saved state.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

import bpy

from .camera import _key
from .context import BuildContext, BuildError, kelvin_to_linear_rgb, opt, req

# ---------------------------------------------------------------- lighting


def _make_light(name: str, kind: str, spec: dict[str, Any]) -> Any:
    data = bpy.data.lights.new(name, type=kind)
    data.energy = float(spec["energy"])
    data.color = kelvin_to_linear_rgb(spec["color_temperature_k"])
    if kind == "AREA":
        data.size = float(spec["area_size"])
    obj = bpy.data.objects.new(name, data)
    obj.location = tuple(float(v) for v in spec["location"])
    obj.rotation_euler = tuple(math.radians(float(v)) for v in spec["rotation_deg"])
    bpy.context.scene.collection.objects.link(obj)
    return obj


def build_lighting(ctx: BuildContext) -> list[Any]:
    cfg = ctx.cfg
    preset = str(opt(cfg, "lighting.rig_preset", "three_point"))
    lights: list[Any] = []
    preset_library = opt(cfg, "lighting.presets", {}) or {}

    if preset in preset_library:
        rig = preset_library[preset]
        for role in ("key", "fill", "rim"):
            spec = rig.get(role)
            if spec is not None:
                lights.append(_make_light(f"LGT_{role}", "AREA", spec))
    elif preset == "three_point":
        lights.append(_make_light("LGT_key", "AREA", req(cfg, "lighting.key")))
        lights.append(_make_light("LGT_fill", "AREA", req(cfg, "lighting.fill")))
        lights.append(_make_light("LGT_rim", "AREA", req(cfg, "lighting.rim")))
    elif preset == "key_only":
        lights.append(_make_light("LGT_key", "AREA", req(cfg, "lighting.key")))
    elif preset == "hdri_only":
        pass
    else:
        raise BuildError(f"unknown lighting.rig_preset '{preset}'")

    hdri_id = opt(cfg, "lighting.hdri_asset_id")
    if hdri_id:
        _build_world(ctx, hdri_id)

    ctx.assert_that(
        "lighting rig built",
        bool(lights) or bool(hdri_id),
        f"preset={preset}, lights={len(lights)}, hdri={bool(hdri_id)}",
    )
    return lights


def _build_world(ctx: BuildContext, hdri_id: str) -> None:
    path = ctx.asset_path(hdri_id)
    world = bpy.data.worlds.new("WORLD_shot")
    bpy.context.scene.world = world
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    nodes.clear()

    output = nodes.new("ShaderNodeOutputWorld")
    background = nodes.new("ShaderNodeBackground")
    env = nodes.new("ShaderNodeTexEnvironment")
    mapping = nodes.new("ShaderNodeMapping")
    coords = nodes.new("ShaderNodeTexCoord")

    env.image = bpy.data.images.load(str(path), check_existing=True)
    background.inputs["Strength"].default_value = float(
        opt(ctx.cfg, "lighting.hdri_strength", 1.0)
    )
    mapping.inputs["Rotation"].default_value[2] = math.radians(
        float(opt(ctx.cfg, "lighting.hdri_rotation_deg", 0.0))
    )

    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], env.inputs["Vector"])
    links.new(env.outputs["Color"], background.inputs["Color"])
    links.new(background.outputs["Background"], output.inputs["Surface"])


# ---------------------------------------------------------------- blocking


def build_blocking(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> None:
    tracks = ctx.cfg.get("blocking", [])
    if not tracks:
        ctx.assert_that("blocking applied", True, "no blocking configured")
        return

    keyed = 0
    for track in tracks:
        character_id = track["character_id"]
        handles = cast.get(character_id)
        if handles is None:
            raise BuildError(f"blocking references '{character_id}', not in this shot's cast")
        obj = handles["root"]

        for entry in track.get("keys", []):
            frame = int(entry["frame"])
            transform = entry["transform"]
            easing = str(entry.get("easing", "BEZIER"))
            for index, value in enumerate(transform.get("location", [0.0, 0.0, 0.0])):
                _key(obj, "location", index, frame, float(value), easing)
            for index, value in enumerate(transform.get("rotation_deg", [0.0, 0.0, 0.0])):
                _key(obj, "rotation_euler", index, frame, math.radians(float(value)), easing)
            for index, value in enumerate(transform.get("scale", [1.0, 1.0, 1.0])):
                _key(obj, "scale", index, frame, float(value), easing)
            keyed += 1

    ctx.assert_that("blocking applied", keyed > 0, f"{keyed} blocking keys")


# ---------------------------------------------------------------- facial cues


_EXPR_HEAD_SCALE: dict[str, tuple[float, float, float]] = {
    # (sx, sy, sz) applied to BODY_head local scale for each expression
    "EXP_smile":    (1.10, 0.92, 1.00),
    "EXP_frown":    (0.92, 1.08, 1.00),
    "EXP_surprise": (1.00, 1.00, 1.18),
    "BROW_UP":      (1.00, 1.00, 1.10),
    "BROW_DOWN":    (1.00, 1.06, 0.94),
    "BLINK":        (1.00, 0.88, 1.00),
    "LOOK_LEFT":    (1.00, 1.00, 1.00),
    "LOOK_RIGHT":   (1.00, 1.00, 1.00),
}


def _key_head_scale(head_obj: Any, sx: float, sy: float, sz: float, frame: int) -> None:
    head_obj.scale = (sx, sy, sz)
    head_obj.keyframe_insert(data_path="scale", frame=frame)


def build_facial_cues(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> None:
    applied = 0
    for member in ctx.cfg.get("cast", []):
        cues = member.get("facial_cues", [])
        if not cues:
            continue
        handles = cast.get(member["id"])
        if handles is None:
            raise BuildError(f"facial cues reference missing cast member '{member['id']}'")
        collection = handles["collection"]
        declared = set((handles.get("entry", {}).get("rig") or {}).get("facial_controls", []))
        requested = {str(cue["shape_key"]) for cue in cues}
        if declared and not requested <= declared:
            unknown = sorted(requested - declared)
            raise BuildError(
                f"character '{member['id']}' facial cues are outside the admitted contract: {unknown}"
            )
        meshes = [
            obj for obj in collection.all_objects
            if obj.type == "MESH" and obj.data.shape_keys is not None
        ]
        # Find the visible head mesh for scale-based expression proxy.
        # FACE_controls is hidden (hide_render=True); BODY_head is the visible sphere.
        head_obj = next(
            (obj for obj in collection.all_objects if obj.name == "BODY_head"),
            None,
        )
        for cue in cues:
            key_name = str(cue["shape_key"])
            target = None
            for obj in meshes:
                if key_name in obj.data.shape_keys.key_blocks:
                    target = obj.data.shape_keys.key_blocks[key_name]
                    break
            if target is None:
                raise BuildError(
                    f"character '{member['id']}' facial cue references missing shape key '{key_name}'"
                )
            start = int(cue["start_frame"])
            end = int(cue["end_frame"])
            strength = float(cue.get("strength", 1.0))
            for frame, value in (
                (max(0, start - 1), 0.0), (start, strength), (end, strength), (end + 1, 0.0),
            ):
                target.value = value
                target.keyframe_insert(data_path="value", frame=frame)
                applied += 1
            # Also animate BODY_head scale as a visible proxy for the expression.
            # FACE_controls (hide_render=True) carries the shape keys but is never rendered;
            # scaling the visible head sphere gives a legible proxy deformation.
            if head_obj is not None:
                base_scale = _EXPR_HEAD_SCALE.get(key_name)
                if base_scale is not None:
                    sx = 1.0 + (base_scale[0] - 1.0) * strength
                    sy = 1.0 + (base_scale[1] - 1.0) * strength
                    sz = 1.0 + (base_scale[2] - 1.0) * strength
                    _key_head_scale(head_obj, 1.0, 1.0, 1.0, max(0, start - 1))
                    _key_head_scale(head_obj, sx, sy, sz, start)
                    _key_head_scale(head_obj, sx, sy, sz, end)
                    _key_head_scale(head_obj, 1.0, 1.0, 1.0, end + 1)
    ctx.assert_that("facial cues applied", True, f"{applied} shape-key values")


# ---------------------------------------------------------------- lip sync


def _find_viseme_keys(collection: Any, viseme_names: dict[str, str]) -> Any:
    """Locate the shape-key block carrying the viseme set."""
    wanted = set(viseme_names.values())
    for obj in collection.all_objects:
        if obj.type != "MESH" or obj.data.shape_keys is None:
            continue
        present = {kb.name for kb in obj.data.shape_keys.key_blocks}
        if wanted & present:
            missing = wanted - present
            if missing:
                raise BuildError(
                    f"'{obj.name}' has a partial viseme set; missing: "
                    f"{', '.join(sorted(missing))}"
                )
            return obj.data.shape_keys
    raise BuildError(
        f"no mesh carrying visemes {sorted(wanted)} found — "
        "the rig contract declares them but the asset does not provide them"
    )


def build_lipsync(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> None:
    lines = ctx.cfg.get("dialogue", [])
    if not lines:
        ctx.assert_that("lip sync applied", True, "no dialogue configured")
        return

    fps = ctx.fps
    applied = 0

    for line in lines:
        artifact = line.get("viseme_artifact")
        if not artifact:
            raise BuildError(
                f"dialogue line for '{line['speaker']}' has no viseme_artifact; "
                "run the audio pipeline before building"
            )
        cue_path = Path(artifact)
        if not cue_path.is_absolute():
            cue_path = (ctx.assets_root.parent / artifact).resolve()
        if not cue_path.exists():
            raise BuildError(f"viseme artifact not found: {cue_path}")

        speaker = line["speaker"]
        handles = cast.get(speaker)
        if handles is None:
            raise BuildError(f"dialogue speaker '{speaker}' is not in this shot's cast")
        viseme_names = handles["visemes"]
        if not viseme_names:
            raise BuildError(f"'{speaker}' has dialogue but the rig declares no visemes")

        shape_keys = _find_viseme_keys(handles["collection"], viseme_names)
        cues = json.loads(cue_path.read_text(encoding="utf-8")).get("mouthCues", [])
        offset = int(line["start_frame"])
        applied += _key_visemes(shape_keys, cues, viseme_names, offset, fps)

        # Also drive BODY_head Y-scale as a visible mouth-open proxy.
        # FACE_controls (hide_render=True) holds the viseme shape keys but is never
        # rendered; squishing the visible head sphere on open-mouth phonemes gives
        # legible lip-sync proof on close-face shots.
        head_obj = next(
            (obj for obj in handles["collection"].all_objects if obj.name == "BODY_head"),
            None,
        )
        if head_obj is not None:
            _key_mouth_proxy(head_obj, cues, offset, fps)

    ctx.assert_that("lip sync applied", applied > 0, f"{applied} viseme keys")


# Rhubarb viseme letters that represent open-mouth phonemes.
_OPEN_MOUTH_VISEMES = {"A", "C", "D", "E", "G", "H"}


def _key_mouth_proxy(head_obj: Any, cues: list[dict[str, Any]], offset: int, fps: int) -> None:
    """Animate BODY_head scale to proxy mouth open/close for lip-sync readability."""
    from .camera import _all_fcurves

    _key_head_scale(head_obj, 1.0, 1.0, 1.0, max(0, offset - 1))
    for cue in cues:
        letter = str(cue.get("value", "X"))
        frame = offset + round(float(cue["start"]) * fps)
        if letter in _OPEN_MOUTH_VISEMES:
            _key_head_scale(head_obj, 1.05, 0.72, 0.90, frame)
        else:
            _key_head_scale(head_obj, 1.0, 1.0, 1.0, frame)

    # Use CONSTANT interpolation so phoneme shapes snap rather than lerp.
    anim = head_obj.animation_data
    if anim and anim.action:
        for fcurve in _all_fcurves(anim.action):
            if fcurve.data_path == "scale":
                for point in fcurve.keyframe_points:
                    point.interpolation = "CONSTANT"


def _key_visemes(
    shape_keys: Any,
    cues: list[dict[str, Any]],
    viseme_names: dict[str, str],
    offset: int,
    fps: int,
) -> int:
    blocks = shape_keys.key_blocks
    keyed = 0

    for cue in cues:
        letter = cue.get("value")
        key_name = viseme_names.get(letter)
        if key_name is None or key_name not in blocks:
            continue
        block = blocks[key_name]
        start = offset + round(float(cue["start"]) * fps)
        end = offset + round(float(cue["end"]) * fps)

        # Mouth shapes are swaps, not blends: CONSTANT interpolation is what
        # makes a phoneme read as a distinct shape rather than a smear.
        for frame, value in ((start, 1.0), (max(start + 1, end), 0.0)):
            block.value = value
            block.keyframe_insert(data_path="value", frame=frame)
            keyed += 1

    _set_constant_interpolation(shape_keys)
    return keyed


def _set_constant_interpolation(shape_keys: Any) -> None:
    from .camera import _all_fcurves

    anim = shape_keys.animation_data
    if anim is None or anim.action is None:
        return
    for fcurve in _all_fcurves(anim.action):
        for point in fcurve.keyframe_points:
            point.interpolation = "CONSTANT"


# ---------------------------------------------------------------- compositor


def build_comp(ctx: BuildContext) -> None:
    comp = opt(ctx.cfg, "comp", {}) or {}
    glow = float(comp.get("glow", 0.0))
    vignette = float(comp.get("vignette", 0.0))

    if glow <= 0.0 and vignette <= 0.0:
        ctx.assert_that("compositor built", True, "pass-through (no glow or vignette)")
        return

    scene = bpy.context.scene
    scene.use_nodes = True
    tree = scene.node_tree
    tree.nodes.clear()

    render_layers = tree.nodes.new("CompositorNodeRLayers")
    composite = tree.nodes.new("CompositorNodeComposite")
    head = render_layers.outputs["Image"]

    if glow > 0.0:
        glare = tree.nodes.new("CompositorNodeGlare")
        glare.glare_type = "FOG_GLOW"
        glare.quality = str(comp["glow_quality"])
        glare.mix = min(1.0, glow) * 2.0 - 1.0
        tree.links.new(head, glare.inputs["Image"])
        head = glare.outputs["Image"]

    if vignette > 0.0:
        mask = tree.nodes.new("CompositorNodeEllipseMask")
        mask.width = float(comp["vignette_width"])
        mask.height = float(comp["vignette_height"])
        blur = tree.nodes.new("CompositorNodeBlur")
        blur.size_x = int(comp["vignette_blur_px"])
        blur.size_y = int(comp["vignette_blur_px"])
        blur.use_relative = False
        mix = tree.nodes.new("CompositorNodeMixRGB")
        mix.blend_type = "MULTIPLY"
        mix.inputs["Fac"].default_value = min(1.0, vignette)

        tree.links.new(mask.outputs["Mask"], blur.inputs["Image"])
        tree.links.new(head, mix.inputs[1])
        tree.links.new(blur.outputs["Image"], mix.inputs[2])
        head = mix.outputs["Image"]

    tree.links.new(head, composite.inputs["Image"])
    ctx.assert_that("compositor built", True, f"glow={glow}, vignette={vignette}")
