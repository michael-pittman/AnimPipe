from pathlib import Path

import pytest

from blender_training_pipeline.config_compile import compile_pipeline
from blender_training_pipeline.config_patch import apply_review_candidate
from blender_training_pipeline.qa_models import ConfigChange, DimensionReview, VisualReview

ROOT = Path(__file__).resolve().parents[1]
LAYERS = [ROOT / "config/base.yaml", ROOT / "config/project.yaml", ROOT / "config/scene/module_01.yaml", ROOT / "config/shot/m01_s030.yaml"]


def review(path: str) -> VisualReview:
    dim = DimensionReview(grade="warn", note="test", score=0.5)
    return VisualReview(
        verdict="revise", summary="test", framing=dim, legibility=dim, staging=dim,
        lighting=dim, continuity=dim, instructional_intent=dim,
        changes=[ConfigChange(path=path, proposed_value=55.0, rationale="test", confidence=1.0)],
    )


def test_allowlisted_patch_validates() -> None:
    _, raw, _ = compile_pipeline(LAYERS)
    candidate = apply_review_candidate(raw, review("camera.lens_mm"))
    assert candidate["camera"]["lens_mm"] == 55.0


def test_code_or_render_patch_is_blocked() -> None:
    _, raw, _ = compile_pipeline(LAYERS)
    with pytest.raises(ValueError):
        apply_review_candidate(raw, review("render.samples"))


def test_style_patch_is_blocked() -> None:
    _, raw, _ = compile_pipeline(LAYERS)
    with pytest.raises(ValueError):
        apply_review_candidate(raw, review("style.shading.roughness"))
