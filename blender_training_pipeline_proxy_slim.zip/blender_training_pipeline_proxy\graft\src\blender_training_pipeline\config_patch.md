# src/blender_training_pipeline/config_patch.py

- _allowed · function · L12-L13 — def _allowed(path: str, prefixes: list[str]) -> bool
- apply_review_candidate · function · L16-L26 — def apply_review_candidate(resolved: dict[str, Any], review: VisualReview) -> dict[str, Any]
