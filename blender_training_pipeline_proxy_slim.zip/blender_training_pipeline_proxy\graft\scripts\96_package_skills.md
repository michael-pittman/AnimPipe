# scripts/96_package_skills.py

- sha256 · function · L15-L20 — def sha256(path: Path) -> str
- main · function · L23-L37 — def main() -> None
