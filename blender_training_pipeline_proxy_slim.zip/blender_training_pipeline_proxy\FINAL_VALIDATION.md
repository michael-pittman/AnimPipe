# Final Proxy Animation Kit Bundle Validation — 2026-09-14

This release integrates the Proxy Animation Kit into the reviewed Blender training-video pipeline as a first-class, replaceable asset/style package. The proxy kit uses the same production config compiler, Asset Doctor, deterministic Blender builder, GPU scheduler, Qwen3-VL QA loop, audio/lip-sync path, and FFmpeg delivery path that later art packages will use.

> Status note: this file is the packaging-validation snapshot from 2026-09-14, not the live portrait acceptance status. For the current operational state, open blockers, and QA limitations, see `docs/PIPELINE_STATUS.md`.

## Passed locally

- **46/46 pytest tests pass**.
- Python compile/syntax validation passes for `src/`, `asset_system/`, `blend_build/`, `scripts/`, and tests.
- Shell syntax passes for all `scripts/*.sh`.
- Bundle structural validator status: **pass**.
- Proxy Kit schema validates `proxy_clay_v1` with 20 Actions/poses, 9 visemes, 8 facial controls, 6 props, 2 camera paths, 5 overlays, 7 camera templates and 4 lighting presets.
- All 10 acceptance shots compile through OmegaConf → Pydantic and reference only admitted proxy vocabulary.
- `asset-factory` is a dedicated tenth agent; the Animation Director composes the admitted vocabulary rather than authoring arbitrary shot-time armature keyframes.
- Style configuration is carried into resolved shot contracts but is outside the VLM patch allow-list.
- **10** project agents validate; only `blender-debugger` receives the Blender MCP server.
- **21** active project skills validate and remain below the 300-line project cap.
- **21** generated distributable `.skill` packages regenerate successfully; the six user-supplied source `.skill` archives remain separately preserved byte-for-byte.
- The supplied Blender-agent archive remains byte-for-byte preserved with recorded upstream provenance; compatible Blender 5.x knowledge is adapted separately.
- Pipeline, director-script, asset-manifest, visual-review, and Proxy Kit JSON schemas regenerate successfully.
- All ten Proxy acceptance shot configs compile through OmegaConf → Pydantic and reference only declared action/prop/path/camera/light vocabulary.
- `pipe proxy validate` reports the expected `proxy_clay_v1` contract: 20 Actions, 6 props, 2 paths, 5 overlays, 7 camera templates, and 4 lighting presets.
- The Proxy manifest builder is covered for all 15 logical generated asset entries (character + set + six props + two paths + five overlays).
- The acceptance controller runs bounded visual QA by default; `--no-qa` is an explicit infrastructure-isolation switch.
- Generated proxy `.blend`/PNG files remain Git-ignored build artifacts; YAML contracts, generators, schemas, tests, and agent skills are the committed source of truth.
- No supported host dependency introduces a CUDA Toolkit, `nvidia-cublas`, `nvidia-cudnn`, or GPU Whisper runtime.

## Proxy Animation Kit acceptance target

On the qualified Azure VM, the milestone is:

```bash
.venv/bin/pipe proxy validate
.venv/bin/pipe proxy generate
.venv/bin/pipe proxy acceptance --preview --audio --qa
```

A passing run must generate/admit the proxy assets and produce `build/proxy_acceptance/proxy_acceptance_film.mp4` without interactive Blender edits. The ten-shot film exercises locomotion/NLA, body gestures, face controls, nine Rhubarb visemes, foreground/midground/background staging, prop attach/release, semantic camera templates, Follow Path camera motion, lighting presets, graphics/captions, TTS, VLM QA/revision, rendering, NVENC, and final concatenation.

## External API assumptions rechecked

Current Blender 5.2 documentation supports the API model used by the generated proxy assets:

- Actions use slots, and explicit object slots plus `action_suitable_slots` / `action_slot` are supported.
- Bone parenting is a supported object-parent relationship.
- Relative shape keys are a standard mechanism for facial animation, mouth positions, expressions, and phonemes.

See `docs/VERIFICATION_SOURCES.md` for the verification snapshot.

## Not claimed locally

This packaging environment does **not** contain Blender/`bpy` or the target Azure T4/GRID runtime. Therefore the deterministic Proxy Blender generator is syntax/contract tested here but its live `bpy` execution is intentionally not claimed. The following must be proven on the target `Standard_NC4as_T4_v3`:

1. Azure IMDS SKU/host-shape and raw T4 PCI identity.
2. Microsoft GRID installation and reboot persistence.
3. Exact live GPU UUID/name/VRAM identity.
4. Blender 5.2.1 OptiX discovery and Blender API-contract probe.
5. Live execution of `scripts/100_generate_proxy_kit_blender.py`, including Action slots, rigid bone parenting, saved shape keys, and Asset Doctor reopening the generated character.
6. FFmpeg NVENC plus `lut3d`, `subtitles`, and `overlay` filters.
7. NVIDIA Container Toolkit → Ollama T4 passthrough.
8. Qwen3-VL structured visual review and bounded revision behavior.
9. Kokoro authenticated local TTS and Rhubarb cue generation.
10. Full Proxy Kit generate → admit → QA → render → encode acceptance film.
11. VM-side Ruff gate included in `scripts/80_smoke_test.sh`.

The release is therefore **source-ready, Proxy-Kit-integrated, VM-acceptance-pending** rather than claiming GPU/Blender runtime validation from a non-Blender packaging environment.
