---
name: animating-basics
description: Blender 5.x animation API guidance adapted from the supplied Blender-agent repo. Use when implementing or diagnosing keyed pose-bone animation, layered/slotted Actions, NLA assembly, loop verification, or headless animation checks with standard bpy only.
---

# Blender 5.x Animation Basics

This skill carries the useful Blender 5.x Action knowledge from the supplied Blender-agent
repo into the deterministic builder. It uses **standard `bpy` only**. Do not assume custom animation, posing, rigging, media, or thumbnail MCP extension functions exist.

## Write keys normally

`keyframe_insert()` remains the preferred writer. For pose bones, verify `rotation_mode`
before choosing Euler versus quaternion channels. Animate only controls admitted by the
asset contract; never infer control/deformation conventions from bone names alone.

```python
bone = armature.pose.bones[control_name]
bone.rotation_mode = rotation_mode
setattr(bone, data_path, value)
bone.keyframe_insert(data_path=data_path, frame=frame)
```

All names, frames, values and rotation modes come from resolved config or admitted asset
metadata. Example literals are not production defaults.

## Read Blender 5.x layered/slotted Actions

Legacy `action.fcurves` is not the authoritative read path in Blender 5.x. Traverse the
Action's layers/strips and query the channelbag for the active slot:

```python
action = armature.animation_data.action
slot = action.slots[0]
fcurves = []
for layer in action.layers:
    for strip in layer.strips:
        bag = strip.channelbag(slot)
        if bag:
            fcurves.extend(bag.fcurves)
```

Use this path for validation, modifiers and regression diagnostics.

## NLA is the performance vocabulary

Shot authoring selects **named admitted Actions**; builder code creates NLA tracks/strips and
uses config for frame ranges, blend mode, influence and blend windows. Do not replace a
missing Action with ad-hoc raw keyframes. Reject the asset/shot contract instead.

## Loop verification

A loop must have equivalent boundary poses and the intended extrapolation/modifiers. Verify
headlessly by sampling evaluated transforms or evaluated mesh vertices at configured frames.
Do not depend on viewport state.

## Debugging boundary

A scratch MCP session may inspect Action/slot/NLA state. The fix is always a config, asset,
or builder change followed by a clean rebuild from `--factory-startup`; never save the MCP
scratch state as the deliverable.

Exact upstream source is preserved under `vendor/blender-agent-upstream/skills/`.
