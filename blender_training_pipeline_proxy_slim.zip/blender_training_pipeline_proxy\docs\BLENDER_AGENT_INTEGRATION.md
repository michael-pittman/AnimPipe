# Blender-Agent Integration Decision

The user-supplied `blender-agent-main.zip` is treated as a third-party reference source, not as a second production agent runtime.

## Imported as active Claude skills

- `animating-basics`: Blender 5.x layered/slotted Action API guidance.
- `lighting-setups`: concise Blender lighting setup patterns.

The active copies are deliberately adapted to remove custom MCP-extension assumptions and hard-coded creative example values. The unmodified source archive, archive SHA-256, upstream revision marker, and exact source skill copies are retained under `vendor/blender-agent-upstream/`.

## Not activated

The supplied repo also includes valuable rigging/posing/animation-at-scale skills. Some of those rely on custom MCP extensions such as `anim(...)`, `pose(...)`, or rigging extension tools. This project intentionally configures the **official Blender Lab MCP** only, so those skill files are not preloaded as project skills. Their conceptual lessons may be translated into deterministic `bpy` builder code, but Claude must not assume those custom tools exist.

## Production boundary

The supplied repo's interactive agent harness is not installed into the production build path. Production remains:

`authored YAML -> OmegaConf -> Pydantic -> resolved JSON -> Blender builder`.

The official MCP is available only to the `blender-debugger` agent on a disposable scratch copy of a generated `.blend`.
