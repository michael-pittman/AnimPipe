# src/blender_training_pipeline/alignment.py

- align_words_cpu · function · L7-L22 — def align_words_cpu(wav: Path, output_json: Path, *, model_size: str = "small") -> dict
