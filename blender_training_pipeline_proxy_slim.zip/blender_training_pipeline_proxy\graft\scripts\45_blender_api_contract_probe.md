# scripts/45_blender_api_contract_probe.py

- require · function · L12-L14 — def require(condition: bool, message: str) -> None
- main · function · L17-L62 — def main() -> None
