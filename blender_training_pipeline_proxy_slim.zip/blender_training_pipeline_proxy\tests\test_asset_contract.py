from pathlib import Path

import yaml

from asset_system.models import AssetManifest


def test_example_asset_manifest_schema() -> None:
    path = Path(__file__).resolve().parents[1] / "assets/assets.yaml.example"
    AssetManifest.model_validate(yaml.safe_load(path.read_text(encoding="utf-8")))
