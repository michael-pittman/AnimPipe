# blend_build/stages.py

- _make_light · function · L23-L33 — def _make_light(name: str, kind: str, spec: dict[str, Any]) -> Any
- build_lighting · function · L36-L68 — def build_lighting(ctx: BuildContext) -> list[Any]
- _build_world · function · L71-L97 — def _build_world(ctx: BuildContext, hdri_id: str) -> None
- build_blocking · function · L103-L129 — def build_blocking(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> None
- _key_head_scale · function · L148-L150 — def _key_head_scale(head_obj: Any, sx: float, sy: float, sz: float, frame: int) -> None
- build_facial_cues · function · L153-L213 — def build_facial_cues(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> None
- _find_viseme_keys · function · L219-L237 — def _find_viseme_keys(collection: Any, viseme_names: dict[str, str]) -> Any
- build_lipsync · function · L240-L286 — def build_lipsync(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> None
- _key_mouth_proxy · function · L293-L312 — def _key_mouth_proxy(head_obj: Any, cues: list[dict[str, Any]], offset: int, fps: int) -> None
- _key_visemes · function · L315-L342 — def _key_visemes( shape_keys: Any, cues: list[dict[str, Any]], viseme_names: dict[str, str], offset: int, fps: int, ) -> int
- _set_constant_interpolation · function · L345-L353 — def _set_constant_interpolation(shape_keys: Any) -> None
- build_comp · function · L359-L403 — def build_comp(ctx: BuildContext) -> None
