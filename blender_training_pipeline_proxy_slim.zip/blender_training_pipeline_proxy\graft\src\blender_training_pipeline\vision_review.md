# src/blender_training_pipeline/vision_review.py

- ModelUnavailableError · class · L14-L15 — class ModelUnavailableError(RuntimeError)
- _model_available · function · L18-L26 — def _model_available(base_url: str, model: str) -> bool
- _wait_ollama_healthy · function · L29-L55 — def _wait_ollama_healthy(base_url: str, model: str, timeout_s: float = 120.0) -> bool
- review_preview · function · L58-L175 — def review_preview( image: Path, intent_text: str, resolved_config_text: str, model: str = "qwen2.5vl:3b", base_url: str = "http://127.0.0.1:11434", ) -> VisualReview: # After a Blender GPU render, Ollama's llama-server may be in a crash/restart # loop while re-acquiring the CUDA context. Wait up to 120 s before failing.
- _wait_for_ollama · function · L132-L143 — def _wait_for_ollama(deadline: float) -> bool
