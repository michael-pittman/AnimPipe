# src/blender_training_pipeline/hardware.py

- GpuSnapshot · class · L10-L16 — class GpuSnapshot
- query_gpus · function · L19-L31 — def query_gpus() -> list[GpuSnapshot]
- load_verified · function · L34-L40 — def load_verified(path: Path) -> dict
- verify_live_identity · function · L43-L60 — def verify_live_identity(manifest_path: Path) -> GpuSnapshot
- snapshot_dict · function · L63-L64 — def snapshot_dict(gpu: GpuSnapshot) -> dict
- refresh_gpu_uuid · function · L67-L95 — def refresh_gpu_uuid(manifest_path: Path) -> tuple[str, str]
