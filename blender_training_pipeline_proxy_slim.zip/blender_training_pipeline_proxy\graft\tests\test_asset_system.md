# tests/test_asset_system.py

- test_static_asset_doctor · function · L9-L39 — def test_static_asset_doctor(tmp_path: Path) -> None
