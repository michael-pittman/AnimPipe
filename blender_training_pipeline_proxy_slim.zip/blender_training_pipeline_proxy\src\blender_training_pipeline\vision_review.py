from __future__ import annotations

import base64
import io
import json
from pathlib import Path

import httpx
from PIL import Image

from .qa_models import VisualReview


class ModelUnavailableError(RuntimeError):
    """Raised when the VLM model is not loaded in Ollama."""


def _model_available(base_url: str, model: str) -> bool:
    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.get(f"{base_url}/api/tags")
            resp.raise_for_status()
            names = {m["name"] for m in resp.json().get("models", [])}
            return model in names
    except Exception:
        return False


def _wait_ollama_healthy(base_url: str, model: str, timeout_s: float = 120.0) -> bool:
    """Wait until a test inference succeeds, return False on timeout.

    /api/tags is always responsive even when llama-server is in a crash loop.
    Only a real inference call proves the model is loaded and ready.
    """
    import time
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        try:
            with httpx.Client(timeout=15.0) as c:
                r = c.post(
                    f"{base_url}/api/chat",
                    json={
                        "model": model,
                        "messages": [{"role": "user", "content": "ready?"}],
                        "stream": False,
                        "keep_alive": 180,
                        "options": {"num_predict": 1},
                    },
                )
                if r.status_code == 200:
                    return True
        except Exception:
            pass
        time.sleep(5)
    return False


def review_preview(
    image: Path,
    intent_text: str,
    resolved_config_text: str,
    model: str = "qwen2.5vl:3b",
    base_url: str = "http://127.0.0.1:11434",
) -> VisualReview:
    # After a Blender GPU render, Ollama's llama-server may be in a crash/restart
    # loop while re-acquiring the CUDA context. Wait up to 120 s before failing.
    if not _wait_ollama_healthy(base_url, model, timeout_s=120.0):
        raise ModelUnavailableError(
            f"Ollama model '{model}' is not available at {base_url} after waiting. "
            "Pull the model or run with --no-qa to skip visual QA."
        )
    # qwen2.5vl:3b struggles with high-resolution contact sheets (1920px+ wide):
    # the vision encoder overflows its token budget and produces degenerate output.
    # Cap at 960px wide to keep the patch count within num_ctx limits.
    _MAX_WIDTH = 960
    img_pil = Image.open(image).convert("RGB")
    if img_pil.width > _MAX_WIDTH:
        scale = _MAX_WIDTH / img_pil.width
        img_pil = img_pil.resize(
            (int(img_pil.width * scale), int(img_pil.height * scale)),
            Image.LANCZOS,
        )
    buf = io.BytesIO()
    img_pil.save(buf, format="JPEG", quality=90)
    encoded = base64.b64encode(buf.getvalue()).decode("ascii")
    # Trim config to QA-relevant keys only to stay within context limits.
    try:
        cfg = json.loads(resolved_config_text)
        qa_keys = (
            "metadata",
            "camera",
            "lighting",
            "comp",
            "preview",
            "render",
            "style",
            "qa",
            "dialogue",
            "props",
            "blocking",
            "cast",
        )
        cfg_summary = {k: cfg[k] for k in qa_keys if k in cfg}
        config_text = json.dumps(cfg_summary, indent=2)
    except Exception:
        config_text = resolved_config_text
    prompt = (
        "You are the visual QA critic for an instructional Blender animation. "
        "The image is a contact sheet sampled from the delivered encoded video, so visible captions and overlays are part of the review. "
        "Judge framing, legibility, staging, lighting, continuity and instructional intent. "
        "Honor the resolved style contract; for proxy_clay_v1 do not reward realism, texture detail, or decorative complexity. "
        "Judge semantic value separation and motion readability instead. Never propose changes to style.*. "
        "Propose only configuration changes, never code. "
        "Check captions specifically: they must read like closed captions, stay bottom-centered, and avoid covering the face, hands, or a referenced prop. "
        "Check overlays specifically: only show them when they support the shot, never randomly, and never block what the dialogue is teaching. "
        "Check continuity specifically: if dialogue mentions facial motion, lip sync, or a prop interaction, visible evidence must appear in the sampled frames. "
        "Use the full score range honestly; do not collapse all dimensions to the same score unless the evidence truly matches. "
        "IMPORTANT: all score fields must be a float between 0.0 and 1.0 (not 0-10). "
        "IMPORTANT: keep every note field under 20 words. Keep summary under 40 words. Be terse.\n\n"
        f"DIRECTOR INTENT:\n{intent_text}\n\nRESOLVED CONFIG:\n{config_text}"
    )
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt, "images": [encoded]}],
        "format": VisualReview.model_json_schema(),
        "stream": False,
        "keep_alive": -1,
        "options": {"temperature": 0, "num_ctx": 12288, "num_predict": 2048},
    }
    import time

    def _wait_for_ollama(deadline: float) -> bool:
        """Poll until Ollama responds to /api/tags or deadline passes."""
        while time.monotonic() < deadline:
            try:
                with httpx.Client(timeout=5.0) as c:
                    r = c.get(f"{base_url}/api/tags")
                    if r.status_code == 200:
                        return True
            except Exception:
                pass
            time.sleep(3)
        return False

    for attempt in range(3):
        with httpx.Client(timeout=300.0) as client:
            response = client.post(f"{base_url}/api/chat", json=payload)
            if response.status_code == 500 and attempt < 2:
                # llama-server crash loop after Blender GPU render — wait for recovery
                wait_s = 60 if attempt == 0 else 90
                deadline = time.monotonic() + wait_s
                _wait_for_ollama(deadline)
                continue
            response.raise_for_status()
            content = response.json()["message"]["content"]
            break
    # Normalize scores if the model returned a 0-10 scale instead of 0-1.
    try:
        raw = json.loads(content)
        score_keys = ("framing", "legibility", "staging", "lighting", "continuity", "instructional_intent")
        needs_norm = any(
            isinstance(raw.get(k, {}).get("score"), (int, float)) and raw[k]["score"] > 1.0
            for k in score_keys if k in raw
        )
        if needs_norm:
            for k in score_keys:
                if k in raw and "score" in raw[k]:
                    raw[k]["score"] = min(raw[k]["score"] / 10.0, 1.0)
            for ch in raw.get("changes", []):
                if "confidence" in ch and ch["confidence"] > 1.0:
                    ch["confidence"] = min(ch["confidence"] / 10.0, 1.0)
            content = json.dumps(raw)
    except Exception:
        pass
    return VisualReview.model_validate_json(content)
