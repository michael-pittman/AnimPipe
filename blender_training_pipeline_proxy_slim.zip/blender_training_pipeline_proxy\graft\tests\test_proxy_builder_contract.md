# tests/test_proxy_builder_contract.py

- test_prop_attachment_and_camera_template_validate · function · L6-L31 — def test_prop_attachment_and_camera_template_validate() -> None
- test_style_contract_is_part_of_resolved_pipeline · function · L34-L43 — def test_style_contract_is_part_of_resolved_pipeline() -> None
