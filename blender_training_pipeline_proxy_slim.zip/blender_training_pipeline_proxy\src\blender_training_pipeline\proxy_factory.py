from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from pathlib import Path
from typing import Any

import yaml
from PIL import Image, ImageDraw

from asset_system.doctor import export_manifest_json, file_sha256, static_doctor
from asset_system.models import AssetManifest

from .proxy_models import ProxyKitSpec


class ProxyFactoryError(RuntimeError):
    pass


def load_proxy_kit(path: Path) -> ProxyKitSpec:
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    return ProxyKitSpec.model_validate(raw)


def _relative_asset_file(path: Path, assets_root: Path) -> str:
    try:
        return path.resolve().relative_to(assets_root.resolve()).as_posix()
    except ValueError as exc:
        raise ProxyFactoryError(f"generated asset escaped assets root: {path}") from exc


def _overlay(path: Path, kind: str, width: int, height: int) -> None:
    image = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    stroke = max(4, round(min(width, height) * 0.018))
    white = (245, 245, 245, 225)
    soft = (245, 245, 245, 165)
    if kind == "panel":
        margin = stroke * 2
        draw.rounded_rectangle(
            (margin, margin, width - margin, height - margin),
            radius=stroke * 2,
            fill=(245, 245, 245, 210),
            outline=white,
            width=stroke,
        )
    elif kind == "ring":
        margin = stroke * 3
        draw.ellipse((margin, margin, width - margin, height - margin), outline=white, width=stroke * 2)
    elif kind == "arrow":
        y = height // 2
        draw.line((stroke * 2, y, width - stroke * 6, y), fill=white, width=stroke * 2)
        draw.polygon(
            [
                (width - stroke * 7, y - stroke * 5),
                (width - stroke * 2, y),
                (width - stroke * 7, y + stroke * 5),
            ],
            fill=white,
        )
    elif kind == "frame":
        margin = stroke * 2
        draw.rounded_rectangle(
            (margin, margin, width - margin, height - margin),
            radius=stroke * 2,
            outline=white,
            width=stroke,
        )
    elif kind == "end_card":
        draw.rectangle((0, 0, width, height), fill=(35, 35, 35, 205))
        margin = stroke * 5
        draw.rounded_rectangle(
            (margin, margin, width - margin, height - margin),
            radius=stroke * 3,
            outline=soft,
            width=stroke,
        )
    else:
        raise ProxyFactoryError(f"unknown overlay kind: {kind}")
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path)


def generate_overlays(kit: ProxyKitSpec, output_root: Path) -> dict[str, Path]:
    written: dict[str, Path] = {}
    for item in kit.overlays:
        path = output_root / "overlays" / item.filename
        _overlay(path, item.kind, item.width, item.height)
        written[item.id] = path
    return written


def build_manifest(kit: ProxyKitSpec, *, assets_root: Path, output_root: Path) -> AssetManifest:
    character_file = output_root / "proxy_character.blend"
    environment_file = output_root / "proxy_environment.blend"
    props_file = output_root / "proxy_props.blend"
    paths_file = output_root / "proxy_paths.blend"
    for path in (character_file, environment_file, props_file, paths_file):
        if not path.exists():
            raise ProxyFactoryError(f"Blender did not generate required asset file: {path}")

    style_id = kit.style.id
    common = {"version": kit.version, "blender_min": "5.2.1", "style_id": style_id,
              "source": "generated:proxy-animation-kit", "license": "project-generated"}
    assets: dict[str, Any] = {}
    char = kit.character
    assets[char.id] = {
        **common, "kind": "character", "file": _relative_asset_file(character_file, assets_root),
        "sha256": file_sha256(character_file), "collection": char.collection,
        "material_roles": ["character", "focus"],
        "interaction_points": char.attachment_bones,
        "tags": ["proxy", "instructor", "rigged", "lip-sync"],
        "rig": {
            "armature": char.armature,
            "retarget_profile": char.retarget_profile,
            "required_actions": [action.name for action in char.actions],
            "visemes": char.visemes,
            "facial_controls": char.expressions,
        },
        "complexity": {"triangles": 0, "texture_memory_estimate_mb": 0},
    }
    assets[kit.set.id] = {
        **common, "kind": "set", "file": _relative_asset_file(environment_file, assets_root),
        "sha256": file_sha256(environment_file), "collection": kit.set.collection,
        "material_roles": kit.set.material_roles, "tags": ["proxy", "modular-room", "fg-bg"],
        "complexity": {"triangles": 0, "texture_memory_estimate_mb": 0},
    }
    props_sha = file_sha256(props_file)
    for prop in kit.props:
        assets[prop.id] = {
            **common, "kind": "prop", "file": _relative_asset_file(props_file, assets_root),
            "sha256": props_sha, "collection": prop.collection,
            "material_roles": [prop.material_role], "interaction_points": prop.interaction_points,
            "tags": ["proxy", "interaction-prop"],
            "complexity": {"triangles": 0, "texture_memory_estimate_mb": 0},
        }
    paths_sha = file_sha256(paths_file)
    for path_spec in kit.paths:
        assets[path_spec.id] = {
            **common, "kind": "path", "file": _relative_asset_file(paths_file, assets_root),
            "sha256": paths_sha, "object": path_spec.object,
            "tags": ["proxy", "camera-path"],
            "complexity": {"triangles": 0, "texture_memory_estimate_mb": 0},
        }
    for overlay_spec in kit.overlays:
        path = output_root / "overlays" / overlay_spec.filename
        if not path.exists():
            raise ProxyFactoryError(f"missing generated overlay: {path}")
        assets[overlay_spec.id] = {
            **common, "kind": "overlay", "file": _relative_asset_file(path, assets_root),
            "sha256": file_sha256(path), "material_roles": [overlay_spec.material_role],
            "tags": ["proxy", "graphics", overlay_spec.kind],
            "complexity": {"triangles": 0, "texture_memory_estimate_mb": 0},
        }
    return AssetManifest.model_validate({"assets": assets})


def generate_proxy_kit(
    *,
    spec_path: Path = Path("proxy_kit/kit.yaml"),
    assets_root: Path = Path("assets"),
    output_subdir: str = "proxy",
    manifest_path: Path = Path("assets/assets.proxy.yaml"),
    resolved_manifest: Path = Path("build/assets.proxy.resolved.json"),
    report_path: Path = Path("reports/proxy/generation.json"),
    blender: str = "blender",
) -> dict[str, Any]:
    kit = load_proxy_kit(spec_path)
    assets_root = assets_root.resolve()
    output_root = (assets_root / output_subdir).resolve()
    try:
        output_root.relative_to(assets_root)
    except ValueError as exc:
        raise ProxyFactoryError("proxy output_subdir escapes assets root") from exc
    output_root.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)

    if shutil.which(blender) is None:
        raise ProxyFactoryError(f"Blender executable not found: {blender}")

    payload_path = report_path.with_name("generation_payload.json")
    payload = kit.model_dump(mode="json")
    payload_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    blender_report = report_path.with_name("blender_generation.json")
    cmd = [
        blender, "--background", "--factory-startup",
        "--python", "scripts/100_generate_proxy_kit_blender.py", "--",
        "--spec", str(payload_path), "--output-root", str(output_root), "--report", str(blender_report),
    ]
    proc = subprocess.run(cmd, check=False)
    if not blender_report.exists():
        raise ProxyFactoryError(f"proxy Blender generator produced no report (exit {proc.returncode})")
    blender_data = json.loads(blender_report.read_text(encoding="utf-8"))
    if proc.returncode != 0 or blender_data.get("status") != "ok":
        raise ProxyFactoryError(f"proxy Blender generation failed: {blender_data.get('error', proc.returncode)}")

    overlays = generate_overlays(kit, output_root)
    manifest = build_manifest(kit, assets_root=assets_root, output_root=output_root)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        yaml.safe_dump(manifest.model_dump(mode="json"), sort_keys=True), encoding="utf-8"
    )
    export_manifest_json(manifest_path, resolved_manifest)

    char = kit.character
    deep_report_path = report_path.with_name("character_blender_doctor.json")
    deep_cmd = [
        blender, "--background", "--factory-startup",
        "--python", "blend_build/asset_doctor_blender.py", "--",
        "--blend", str(output_root / "proxy_character.blend"),
        "--report", str(deep_report_path),
        "--collection", char.collection,
        "--armature", char.armature,
        "--actions", *[a.name for a in char.actions],
        "--visemes", *char.visemes.values(),
        "--expressions", *char.expressions,
    ]
    deep_proc = subprocess.run(deep_cmd, check=False)
    if not deep_report_path.exists():
        raise ProxyFactoryError(
            f"generated-character Blender doctor produced no report (exit {deep_proc.returncode})"
        )
    deep_doctor = json.loads(deep_report_path.read_text(encoding="utf-8"))
    if deep_proc.returncode != 0 or not deep_doctor.get("passed"):
        raise ProxyFactoryError(f"generated character failed Blender admission: {deep_doctor}")

    doctor_results = {
        asset_id: static_doctor(manifest_path, asset_id, assets_root)
        for asset_id in manifest.assets
    }
    passed = all(item["passed"] for item in doctor_results.values())
    report = {
        "status": "ok" if passed else "blocked",
        "kit_version": kit.version,
        "style_id": kit.style.id,
        "spec_sha256": hashlib.sha256(spec_path.read_bytes()).hexdigest(),
        "manifest": str(manifest_path),
        "resolved_manifest": str(resolved_manifest),
        "assets": len(manifest.assets),
        "overlays": {k: str(v) for k, v in overlays.items()},
        "blender": blender_data,
        "doctor": doctor_results,
        "character_blender_doctor": deep_doctor,
    }
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if not passed:
        raise ProxyFactoryError("one or more generated proxy assets failed static admission")
    return report
