# tests/test_release_contracts.py

- test_asset_path_traversal_rejected · function · L15-L17 — def test_asset_path_traversal_rejected() -> None
- test_path_asset_requires_target · function · L20-L22 — def test_path_asset_requires_target() -> None
- test_follow_path_requires_asset · function · L25-L27 — def test_follow_path_requires_asset() -> None
- test_follow_path_axes_differ · function · L30-L35 — def test_follow_path_axes_differ() -> None
- test_overlay_expression_injection_rejected · function · L38-L40 — def test_overlay_expression_injection_rejected() -> None
- test_blender_eevee_identifier_only · function · L43-L46 — def test_blender_eevee_identifier_only() -> None
- test_gpu_policy_has_no_whisper_cuda_workload · function · L49-L55 — def test_gpu_policy_has_no_whisper_cuda_workload() -> None
- test_srt_explicit_end_required · function · L58-L62 — def test_srt_explicit_end_required(tmp_path: Path) -> None
- test_srt_uses_frame_timing · function · L65-L72 — def test_srt_uses_frame_timing(tmp_path: Path) -> None
- test_delivery_asset_resolves_logical_id_and_kind · function · L75-L95 — def test_delivery_asset_resolves_logical_id_and_kind(tmp_path: Path) -> None
