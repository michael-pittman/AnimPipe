---
name: preview-revision-loop
description: Governs the automated render-inspect-revise QA cycle. Use after a preview render and before proposing another render. Combines deterministic regression checks and a local vision-model critique, allows only config changes, enforces iteration caps, and escalates when the critic is not improving the result.
---

# Preview → Inspect → Revise

## Order
1. deterministic image/provenance checks
2. perceptual rubric review
3. local VLM structured review
4. config-only patch proposal
5. apply to candidate config
6. Pydantic validate
7. rebuild/preview if iteration budget remains

## VLM contract
The critic sees director intent, resolved shot config, and preview images. It returns only the `VisualReview` schema. Use temperature 0. The default local model is configured under `qa.vision_model`.

Allowed changes are config paths only. Never ask the critic to emit Python or Blender code.

## Loop safety
- Stop on pass.
- Stop and escalate when the patch is invalid.
- Stop when the same failure repeats without score improvement.
- Stop at `qa.max_revisions`.
- Only continue when the candidate validates and meets `qa.min_score_improvement` policy.

The VLM is a critic, not the source of truth. Asset contract failures and deterministic validation failures outrank its opinion.
