from __future__ import annotations

import json
from pathlib import Path


def align_words_cpu(wav: Path, output_json: Path, *, model_size: str = "small") -> dict:
    """Word timing with faster-whisper CPU/int8 only; no CUDA runtime is installed."""
    from faster_whisper import WhisperModel

    model = WhisperModel(model_size, device="cpu", compute_type="int8")
    segments, info = model.transcribe(str(wav), word_timestamps=True)
    words: list[dict[str, object]] = []
    text_parts: list[str] = []
    for segment in segments:
        text_parts.append(segment.text)
        for word in segment.words or []:
            words.append({"word": word.word, "start": word.start, "end": word.end, "probability": word.probability})
    payload = {"language": info.language, "text": "".join(text_parts).strip(), "words": words}
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return payload
