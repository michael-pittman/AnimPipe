#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))

from blender_training_pipeline.models import PipelineConfig, DirectorScriptDocument  # noqa: E402
from blender_training_pipeline.qa_models import VisualReview  # noqa: E402
from blender_training_pipeline.proxy_models import ProxyKitSpec  # noqa: E402
from asset_system.models import AssetManifest  # noqa: E402

SCHEMAS = {
    "pipeline.schema.json": PipelineConfig.model_json_schema(),
    "director-script.schema.json": DirectorScriptDocument.model_json_schema(),
    "asset-manifest.schema.json": AssetManifest.model_json_schema(),
    "visual-review.schema.json": VisualReview.model_json_schema(),
    "proxy-kit.schema.json": ProxyKitSpec.model_json_schema(),
}


def main() -> None:
    out = ROOT / "config" / "schema"
    out.mkdir(parents=True, exist_ok=True)
    for name, schema in SCHEMAS.items():
        (out / name).write_text(json.dumps(schema, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(out / name)


if __name__ == "__main__":
    main()
