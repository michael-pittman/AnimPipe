from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class DimensionReview(StrictModel):
    grade: Literal["pass", "warn", "fail"]
    note: str
    score: float = Field(ge=0.0, le=1.0)


class ConfigChange(StrictModel):
    path: str
    proposed_value: object
    rationale: str
    confidence: float = Field(ge=0.0, le=1.0)


class VisualReview(StrictModel):
    verdict: Literal["pass", "revise", "escalate"]
    summary: str
    framing: DimensionReview
    legibility: DimensionReview
    staging: DimensionReview
    lighting: DimensionReview
    continuity: DimensionReview
    instructional_intent: DimensionReview
    changes: list[ConfigChange] = Field(default_factory=list)
