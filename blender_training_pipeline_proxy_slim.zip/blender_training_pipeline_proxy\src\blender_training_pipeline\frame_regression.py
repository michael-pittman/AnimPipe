from __future__ import annotations

import hashlib
import math
from pathlib import Path

import numpy as np
from PIL import Image
from skimage.metrics import structural_similarity


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _dct_matrix(n: int) -> np.ndarray:
    matrix = np.empty((n, n), dtype=np.float64)
    scale0 = math.sqrt(1.0 / n)
    scale = math.sqrt(2.0 / n)
    for k in range(n):
        factor = scale0 if k == 0 else scale
        for i in range(n):
            matrix[k, i] = factor * math.cos(math.pi * (i + 0.5) * k / n)
    return matrix


def perceptual_hash(image: Image.Image, hash_size: int = 8, highfreq_factor: int = 4) -> int:
    """Small self-contained pHash implementation to keep QA deterministic and dependency-light."""
    size = hash_size * highfreq_factor
    gray = image.convert("L").resize((size, size), Image.Resampling.LANCZOS)
    pixels = np.asarray(gray, dtype=np.float64)
    dct = _dct_matrix(size)
    coeff = dct @ pixels @ dct.T
    low = coeff[:hash_size, :hash_size]
    flat = low.flatten()
    median = float(np.median(flat[1:]))
    bits = flat > median
    value = 0
    for bit in bits:
        value = (value << 1) | int(bool(bit))
    return value


def _hamming(a: int, b: int) -> int:
    return (a ^ b).bit_count()


def compare_images(current: Path, baseline: Path) -> dict[str, float | int | str]:
    a_img = Image.open(current).convert("RGB")
    b_img = Image.open(baseline).convert("RGB")
    if a_img.size != b_img.size:
        b_img = b_img.resize(a_img.size, Image.Resampling.LANCZOS)
    a = np.asarray(a_img, dtype=np.float32) / 255.0
    b = np.asarray(b_img, dtype=np.float32) / 255.0
    ssim = structural_similarity(a, b, channel_axis=2, data_range=1.0)
    phash_distance = _hamming(perceptual_hash(a_img), perceptual_hash(b_img))
    return {
        "current_sha256": sha256_file(current),
        "baseline_sha256": sha256_file(baseline),
        "phash_distance": int(phash_distance),
        "ssim": float(ssim),
    }
