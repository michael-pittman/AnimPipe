# src/blender_training_pipeline/gpu_lock.py

- _lock_ex_nb · function · L19-L24 — def _lock_ex_nb(fd: IO[Any]) -> None
- _unlock · function · L26-L31 — def _unlock(fd: IO[Any]) -> None
- _lock_ex_nb · function · L35-L36 — def _lock_ex_nb(fd: IO[Any]) -> None
- _unlock · function · L38-L39 — def _unlock(fd: IO[Any]) -> None
- gpu_lock · function · L47-L95 — def gpu_lock( workload: str, estimated_peak_mib: int, reserve_mib: int, timeout_seconds: int, manifest_path: Path = DEFAULT_MANIFEST, lock_path: Path = DEFAULT_LOCK, state_path: Path | None = None, )
- main · function · L98-L115 — def main() -> None
