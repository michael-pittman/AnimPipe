from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable
from pathlib import Path

from omegaconf import OmegaConf

from .models import DirectorScriptDocument, PipelineConfig


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def compile_pipeline(
    layers: Iterable[Path], overrides: list[str] | None = None
) -> tuple[PipelineConfig, dict, str]:
    configs = [OmegaConf.load(str(p)) for p in layers]
    if overrides:
        configs.append(OmegaConf.from_dotlist(overrides))
    merged = OmegaConf.merge(*configs)
    raw = OmegaConf.to_container(merged, resolve=True)
    assert isinstance(raw, dict)
    model = PipelineConfig.model_validate(raw)
    normalized = model.model_dump(mode="json", by_alias=True)
    payload = json.dumps(normalized, indent=2, sort_keys=True).encode("utf-8")
    return model, normalized, _sha256_bytes(payload)


def write_compiled(layers: list[Path], output: Path, overrides: list[str] | None = None) -> str:
    _, normalized, digest = compile_pipeline(layers, overrides)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(normalized, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    output.with_suffix(output.suffix + ".sha256").write_text(digest + "\n", encoding="utf-8")
    return digest


def validate_director_script(path: Path) -> DirectorScriptDocument:
    # Scene YAML files are dual-purpose: they contain a `scene` director-script block
    # and may also carry pipeline-config overrides (e.g. `set`, `metadata`).
    # DirectorScriptDocument expects only the `scene` key, so extract just that subtree.
    cfg = OmegaConf.load(str(path))
    raw = OmegaConf.to_container(cfg, resolve=True)
    assert isinstance(raw, dict)
    scene_only = {"scene": raw["scene"]} if "scene" in raw else raw
    return DirectorScriptDocument.model_validate(scene_only)
