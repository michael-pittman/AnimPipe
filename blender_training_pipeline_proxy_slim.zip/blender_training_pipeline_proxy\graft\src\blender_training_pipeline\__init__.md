# src/blender_training_pipeline/__init__.py

_No extracted symbols in this file._
