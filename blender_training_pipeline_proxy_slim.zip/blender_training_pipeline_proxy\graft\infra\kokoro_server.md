# infra/kokoro_server.py

- _get_pipeline · function · L28-L34 — def _get_pipeline(lang_code: str = "a")
- _pcm_to_wav · function · L37-L53 — def _pcm_to_wav(samples, sample_rate: int = 24000) -> bytes
- TTSRequest · class · L64-L69 — class TTSRequest(BaseModel)
- health · function · L73-L74 — def health()
- synthesize · function · L78-L108 — async def synthesize(req: TTSRequest, request: Request): # Optional API-key check — load from infra/kokoro.env if present
- _load_api_key · function · L111-L119 — def _load_api_key() -> str | None
