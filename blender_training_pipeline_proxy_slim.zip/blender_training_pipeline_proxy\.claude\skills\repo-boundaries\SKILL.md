---
name: repo-boundaries
description: Defines authored versus generated paths, agent write lanes, binary/LFS rules, MCP isolation, and credential boundaries. Use before any file-writing operation, .blend save, generated-output mutation, or cross-agent handoff.
---

# Repo Boundaries

The pipeline is deterministic only when authored inputs and generated artifacts stay separate.

## Authored vs generated

**Authored** is source of truth: `config/**`, `src/**`, `asset_system/**`, `blend_build/**`,
`audio_pipeline/**`, `assets/**`, `.claude/**`, `infra/**`, `scripts/**`, `docs/**`, and tests.

**Generated** is reproducible output: `build/**`, `renders/**`, `cache/**`, `out/**`,
`reports/**`, and generated `config/schema/*.schema.json`.

Never hand-edit a generated `.blend`. Production `.blend` files are created only by the
builder from a validated `resolved_config.json`. Supplied `.blend` files under `assets/`
are authored inputs and are the only exception.

## Write lanes

| Agent | May write |
|---|---|
| pipeline-architect | `src/blender_training_pipeline/models.py`, `config/schema/**`, `config/base.yaml`, `config/migrations/**`, `docs/ARCHITECTURE.md`, `docs/adr/**`, architecture tests |
| environment-bootstrapper | `scripts/00_*` through setup/install scripts, `infra/**`, `.vscode/**`, environment docs and reports |
| asset-validator | `asset_system/**`, `assets/assets.yaml`, `reports/assets/**`, asset tests; never supplied asset binaries |
| animation-director | `config/scene/**`, `config/shot/**`, `docs/scripts/**` |
| blender-builder | `blend_build/**`, builder-facing config models, builder tests |
| audio-lipsync-engineer | `audio_pipeline/**`, TTS/viseme provider code, audio tests, generated `cache/audio/**` |
| blender-debugger | `reports/debug/**` only; emits proposals, never production code |
| render-qa | QA/review code, `reports/qa/**`, QA tests; may propose but not directly apply creative patches |
| pipeline-runner | orchestration/locking code plus generated `build/**`, `renders/**`, `out/**`, `reports/runs/**` |

Everyone may read non-secret repository content. If a required edit falls outside an
agent's lane, emit a handoff instead of crossing the boundary.

## MCP boundary

Only `blender-debugger` uses the official Blender MCP. It attaches to a scratch copy, not a
production builder session. MCP-derived findings become a patch proposal for the owning
agent. Never save an MCP-mutated scratch `.blend` as a deliverable or source asset.

## Asset boundary

`asset-validator` admits or rejects assets. It never silently repairs a rig, material, mesh,
or texture. Asset fixes occur in the authoritative source asset, followed by a new manifest
version/hash and re-admission.

## Git and binaries

Use Git LFS for authored binary media. Do not commit `build/`, `renders/`, `cache/`, or
`out/`. Commit lockfiles and environment manifests that establish reproducibility. If the
canonical asset library grows beyond the repository's practical limits, move it through an
explicit storage migration rather than ad-hoc path substitutions.

## Credentials

No secrets enter git, prompts, render manifests, or QA reports. Local service tokens live in
ignored env files; Azure/cloud credentials must not be inherited by the MCP scratch user.
