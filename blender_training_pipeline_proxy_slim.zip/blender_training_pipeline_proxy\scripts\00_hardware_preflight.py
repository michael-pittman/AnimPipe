#!/usr/bin/env python3
from __future__ import annotations

import json, os, platform, re, subprocess, sys, urllib.request
from pathlib import Path

OUT = Path("reports/environment/hardware-preflight.json")
EXPECTED_SKU = "Standard_NC4as_T4_v3"


def imds() -> dict:
    req = urllib.request.Request(
        "http://169.254.169.254/metadata/instance?api-version=2021-02-01",
        headers={"Metadata": "true"},
    )
    with urllib.request.urlopen(req, timeout=3) as response:
        return json.load(response)


def mem_gib() -> float:
    if sys.platform == "win32":
        import ctypes
        class MEMSTATUS(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
        stat = MEMSTATUS()
        stat.dwLength = ctypes.sizeof(stat)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
        return stat.ullTotalPhys / 1024**3
    for line in Path("/proc/meminfo").read_text().splitlines():
        if line.startswith("MemTotal:"):
            return int(line.split()[1]) / 1024 / 1024
    raise RuntimeError("MemTotal not found")


def nvidia_pci() -> list[dict]:
    if sys.platform == "win32":
        # Use nvidia-smi to get PCI device ID — driver is present on this host.
        try:
            out = subprocess.check_output(
                ["nvidia-smi", "--query-gpu=pci.device_id,pci.sub_device_id,gpu_bus_id",
                 "--format=csv,noheader"],
                text=True, timeout=10,
            )
            found = []
            for line in out.strip().splitlines():
                parts = [p.strip() for p in line.split(",")]
                if not parts or not parts[0]:
                    continue
                raw_id = parts[0].strip().lower()
                # nvidia-smi pci.device_id format: 0x[DEVICE16][VENDOR16] (high=device, low=vendor).
                try:
                    combined = int(raw_id, 16)
                    device_id = f"0x{(combined >> 16) & 0xFFFF:04x}"
                    vendor_id = f"0x{combined & 0xFFFF:04x}"
                except ValueError:
                    device_id = raw_id
                    vendor_id = "unknown"
                found.append({"slot": parts[2] if len(parts) > 2 else "unknown",
                               "vendor": vendor_id, "device": device_id, "class": "unknown"})
            return found
        except Exception:
            return []
    found = []
    for dev in Path("/sys/bus/pci/devices").glob("*"):
        try:
            vendor = (dev / "vendor").read_text().strip().lower()
            if vendor != "0x10de":
                continue
            found.append({"slot": dev.name, "vendor": vendor, "device": (dev / "device").read_text().strip().lower(), "class": (dev / "class").read_text().strip().lower()})
        except OSError:
            pass
    return found


def main() -> None:
    compute = imds()["compute"]
    cpu = os.cpu_count() or 0
    ram = mem_gib()
    pci = nvidia_pci()
    checks = {
        "azure_sku_exact": compute.get("vmSize") == EXPECTED_SKU,
        "vcpu_exact": cpu == 4,
        "ram_expected_range": 26.0 <= ram <= 30.0,
        "nvidia_pci_visible": len(pci) >= 1,
        "tesla_t4_pci_id_exact": any(dev.get("device") == "0x1eb8" for dev in pci),
    }
    report = {
        "status": "pass" if all(checks.values()) else "fail",
        "checks": checks,
        "azure": {"vmSize": compute.get("vmSize"), "location": compute.get("location"), "name": compute.get("name")},
        "host": {"platform": platform.platform(), "cpu_count": cpu, "ram_gib": round(ram, 3)},
        "nvidia_pci": pci,
        "note": "Pre-driver PCI identity requires NVIDIA 10de:1eb8 (Tesla T4). Exact runtime name/VRAM/UUID are re-verified after GRID installation; no GPU gate may run before both proofs.",
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if report["status"] != "pass":
        raise SystemExit("hardware preflight failed; do not continue installation")


if __name__ == "__main__":
    main()
