#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
import json
from pathlib import Path
p=Path('reports/environment/hardware-preflight.json')
if not p.exists() or json.loads(p.read_text()).get('status') != 'pass':
    raise SystemExit('PASS hardware-preflight.json required before host installation')
PY
sudo apt-get update
sudo apt-get install -y \
  build-essential ca-certificates curl wget gnupg git git-lfs jq pciutils mokutil unzip pkg-config \
  ffmpeg libegl1 libgl1 libgles2 libxi6 libxxf86vm1 libxfixes3 libxrender1 mesa-utils xvfb \
  libx11-6 libxext6 libxkbcommon0 libsm6 libice6 libfontconfig1 libwayland-client0 \
  libsndfile1 espeak-ng xz-utils openssl

git lfs install
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor --yes -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg
. /etc/os-release
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu ${VERSION_CODENAME} stable" | sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo usermod -aG docker "$USER"

curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor --yes -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -fsSL https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
  sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
  sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list >/dev/null
sudo apt-get update
sudo apt-get install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker

if dpkg -l | grep -Eq 'nvidia-cuda-toolkit|cuda-toolkit-[0-9]'; then
  echo 'ERROR: host CUDA Toolkit detected; this project does not require it.' >&2
  exit 2
fi

echo 'Base host installation complete. Log out/in later if Docker group membership is new.'
