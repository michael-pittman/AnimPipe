---
name: perceptual-frame-review
description: Visually grades rendered preview frames against the shot config that produced them, catching framing, legibility, staging, and continuity failures that hashes and assertions cannot detect. Use this after every preview render, before any final render is queued, and whenever a shot "renders fine" but something seems off. Automated checks confirm a frame exists and matches a hash; only looking at it confirms the character is facing the right way and the text can be read — so run this before signing off on any shot.
---

# Perceptual Frame Review

Frame hashes prove a render didn't change. Assertions prove the config was honored. Neither
proves the shot works. This skill is the step where someone actually looks.

You are grading the **preview render against the shot YAML that produced it**. Read the
config first, form an expectation, then look. Looking first and rationalizing afterward
finds far less.

## Inputs

- `renders/preview/<shot_id>/` — preview frames
- `config/shot/<shot_id>.yaml` — the intent
- `reports/qa/<shot_id>.contact.png` — contact sheet, if generated
- `docs/scripts/<module>.md` — narration, for text/audio alignment checks

Review the contact sheet first for whole-shot problems, then individual frames at full
size for legibility. A problem invisible at contact-sheet scale is usually not the one that
matters; a problem invisible at full size usually isn't real.

## Which frames

At minimum: first, last, and one frame per beat marker. Add any frame where the config
implies a change — a camera move ending, a cut, a signal appearing, a character entering.
Sample more densely across camera moves, where the ends can both look correct while the
middle does not.

## The rubric

Grade each dimension `pass` / `warn` / `fail` with a one-line reason. A `fail` on any
dimension blocks the final render.

**1. Framing and composition**
Is the subject where the config says? Headroom sane, no awkward crop at joints, horizon
level unless intentional. Does the shot size match what the config declares — a config
saying `medium` that renders as a wide is a real mismatch, not a preference.

**2. Legibility**
Every piece of on-screen text readable at mobile size. Sufficient contrast against what's
behind it. Text not overlapping a busy region or the character's face. Held long enough to
read at ~2.5 words per second.

**3. Staging and screen direction**
Characters facing the direction the beat requires. Eyelines consistent across a cut. Screen
direction preserved — a character exiting frame right enters frame left in the next shot.
No unintended overlaps, intersections, or floating contact with the floor.

**4. Lighting and readability of form**
Subject separated from the background. Face lit enough to read expression. No blown
highlights or crushed blacks in areas carrying information. Nothing unintentionally black —
that usually indicates a material or normals problem, so route it to `blender-debugger`.

**5. Continuity**
Against the previous and next shots: consistent character look, set dressing, time of day,
grade. Props where they were left.

**6. Instructional intent**
Does the frame show what the narration at that timestamp is talking about? Is the signaled
element actually the one being discussed? Is anything competing for attention during a
difficult explanation?

This last dimension catches the most valuable class of failure, because a shot can pass
every technical check and still point the learner at the wrong thing.

## Output

```json
{
  "shot_id": "m01_s030",
  "frames_reviewed": [1, 24, 60, 96, 148],
  "verdict": "warn",
  "dimensions": {
    "framing": {"grade": "pass", "note": "medium as configured"},
    "legibility": {"grade": "warn", "note": "term 'escalation threshold' held 14 frames; needs ~28 to read"},
    "staging": {"grade": "pass", "note": ""},
    "lighting": {"grade": "pass", "note": ""},
    "continuity": {"grade": "fail", "note": "instructor faces frame left; exits right in s020"},
    "intent": {"grade": "pass", "note": "signal lands on the correct diagram element"}
  },
  "actions": [
    {"fix": "extend title hold to 28 frames", "owner": "animation-director", "field": "comp.overlays[0].duration"},
    {"fix": "flip instructor facing to 90deg", "owner": "animation-director", "field": "blocking[0].facing"}
  ]
}
```

**Verdict** is the worst dimension grade. Every `warn` or `fail` produces an entry in
`actions` naming the owning agent and, where possible, the config field to change. A
finding without a field is much harder to act on — spend the effort to locate it.

## Grade honestly

The pull toward `pass` is strong, because a `fail` costs a re-render and a routing hop. But
this check exists specifically to catch what nothing downstream will. A frame you weren't
sure about is a `warn`, not a `pass` — write what bothered you even if you can't name the
rule it violates. Vague unease from a careful look is real signal and often precedes
finding the actual defect.

Equally: don't invent findings to seem thorough. An all-`pass` shot with a short honest
note is a fine output. Manufactured nitpicks train the director to ignore this report.

## Stay in scope

You review the frame against the config. You do not review the creative choice the config
encodes — if the director chose a wide shot deliberately and the render is a correct wide
shot, that's a `pass`, even if you'd have framed it tighter. Preferences go in `notes`,
never in the rubric.

Anything suggesting a *technical* fault rather than a config error — black materials,
missing textures, NaN pixels, geometry exploding — is not yours to grade. Route it to
`blender-debugger` and mark the dimension `fail` with that routing noted.
