# External Verification Snapshot — 2026-09-14

These are the time-sensitive implementation assumptions rechecked during the multi-team review. The target-VM smoke test remains the final authority for installed behavior.

| Assumption | Verified source | Result used by this bundle |
|---|---|---|
| Production Blender line | https://www.blender.org/releases/ | Blender 5.2 LTS is active; 5.2.1 was published 2026-08-25. |
| Blender 5.x render API changes | https://developer.blender.org/docs/release_notes/5.0/python_api/ | Use `BLENDER_EEVEE`; set `ImageFormatSettings.media_type` before `file_format`. |
| Blender image settings API | https://docs.blender.org/api/main/bpy.types.ImageFormatSettings.html | `media_type` includes `IMAGE`, `MULTI_LAYER_IMAGE`, and `VIDEO`. |
| EEVEE sampling API | https://docs.blender.org/manual/en/5.2/render/eevee/render_settings/sampling.html | Final render samples remain an explicit EEVEE render setting; the VM API probe asserts the `taa_render_samples` property used by the builder. |
| `bpy` wheel runtime | https://pypi.org/project/bpy/5.2.1/ | Official `bpy==5.2.1` wheels require CPython 3.13. |
| Version-specific IDE stubs | https://pypi.org/project/fake-bpy-module-5.2/20260730/ | `fake-bpy-module-5.2==20260730` is the pinned 5.2 stub package. |
| Blender Action slots | https://docs.blender.org/api/dev/bpy.types.ActionSlot.html and https://docs.blender.org/manual/en/5.2/animation/actions.html | Proxy Actions create explicit object slots; production NLA resolves a compatible slot before evaluation. |
| Blender bone parenting | https://docs.blender.org/manual/en/5.2/scene_layout/object/editing/parent.html | Proxy rigid body parts may be parented directly to named armature bones for the diagnostic mannequin. |
| Blender shape keys | https://docs.blender.org/manual/en/5.2/animation/shape_keys/introduction.html | Relative shape keys are appropriate for expressions, mouth positions, and phonemes used by Proxy facial/lip controls. |
| Azure NCasT4_v3 Linux GRID | https://learn.microsoft.com/en-us/azure/virtual-machines/linux/n-series-driver-setup | Microsoft documents `595.58.03-grid-azure`; Secure Boot and vTPM must be disabled for the documented manual GRID flow. |
| T4 hardware identity | NVIDIA T4 product brief / Azure NCasT4_v3 size documentation | T4 PCI device ID is `10de:1eb8`; `Standard_NC4as_T4_v3` is 4 vCPU / 28 GiB with one 16 GB T4. |
| FFmpeg post-render effects | https://ffmpeg.org/ffmpeg-filters.html | `lut3d` and `overlay` are documented filters; target smoke additionally asserts `subtitles` exists in the installed FFmpeg build. |
| Ollama on NVIDIA Docker | https://docs.ollama.com/docker and https://docs.ollama.com/gpu | NVIDIA Container Toolkit is the documented Docker GPU path; T4 (compute capability 7.5) is supported. |
| Qwen visual critic | https://ollama.com/library/qwen2.5vl/tags | `qwen2.5vl:3b` is the production model — loaded via `ollama create` from GGUF because Cloudflare R2 blocks direct pull. About 2.1 GB. |
| Kokoro local TTS | https://github.com/hwdsl2/docker-kokoro | CPU image exposes an OpenAI-compatible `/v1/audio/speech`; GPU image is optional and requires NVIDIA Container Toolkit. |

| Claude Code install/plugin model | https://code.claude.com/docs/en/installation and https://code.claude.com/docs/en/discover-plugins | Native `install.sh ... stable` is documented; the official marketplace is available and project-scope plugin installation is supported. |
| Claude Sonnet 4.6 status | https://docs.anthropic.com/en/docs/about-claude/model-deprecations | `claude-sonnet-4-6` remains active as of this review. |

## Verification policy

Web documentation verifies the intended API/driver contract. It does **not** substitute for live hardware/runtime acceptance. `scripts/80_smoke_test.sh` must still pass on the actual `Standard_NC4as_T4_v3` before production GPU work is admitted.
