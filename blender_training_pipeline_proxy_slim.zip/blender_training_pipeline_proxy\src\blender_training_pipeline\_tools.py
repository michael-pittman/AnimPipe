"""Tool-resolution helpers for Windows environments where PATH may be incomplete.

On Windows, Git Bash / Python subprocesses do not inherit the full user PATH,
so winget-installed tools (FFmpeg, Blender, etc.) may be missing. This module
provides a fallback finder that walks known Windows installation directories.
"""
from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path


def _win_search_dirs(name: str) -> list[Path]:
    """Return candidate directories for a tool on Windows."""
    candidates: list[Path] = []
    local_appdata = os.environ.get("LOCALAPPDATA") or os.path.expandvars("%LOCALAPPDATA%")
    # WinGet packages directory
    winget = Path(local_appdata) / "Microsoft" / "WinGet" / "Packages"
    if winget.is_dir():
        exe_name = name + ".exe"
        for match in winget.glob(f"**/{exe_name}"):
            candidates.append(match.parent)
    # Program Files (e.g. Blender Foundation\Blender X.Y)
    for pf_root in ("C:/Program Files", "C:/Program Files (x86)"):
        pf = Path(pf_root)
        if pf.is_dir():
            exe_name = name + ".exe"
            for match in pf.glob(f"**/{exe_name}"):
                candidates.append(match.parent)
    # Scoop
    scoop = Path(os.environ.get("USERPROFILE", "~")).expanduser() / "scoop" / "shims"
    if scoop.is_dir():
        candidates.append(scoop)
    # Chocolatey
    choco = Path("C:/ProgramData/chocolatey/bin")
    if choco.is_dir():
        candidates.append(choco)
    return candidates


def find_tool(name: str) -> str:
    """Return the path to a tool, checking PATH first then Windows-specific locations."""
    found = shutil.which(name)
    if found:
        return found
    if sys.platform == "win32":
        for d in _win_search_dirs(name):
            candidate = d / (name + ".exe")
            if candidate.is_file():
                return str(candidate)
            candidate = d / name
            if candidate.is_file():
                return str(candidate)
    raise FileNotFoundError(
        f"'{name}' not found in PATH or known installation directories. "
        f"Ensure it is installed and on PATH."
    )


def ensure_tool_on_path(name: str) -> str:
    """Find a tool and add its directory to os.environ['PATH'] if needed.

    Returns the resolved path. Idempotent.
    """
    found = find_tool(name)
    tool_dir = str(Path(found).parent)
    path_sep = ";" if sys.platform == "win32" else ":"
    current_path = os.environ.get("PATH", "")
    if tool_dir not in current_path:
        os.environ["PATH"] = tool_dir + path_sep + current_path
    return found
