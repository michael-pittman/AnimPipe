import json
import bpy

result = {"blender_version": bpy.app.version_string, "gpu_backend_init": None, "cycles": {}}
try:
    import gpu
    gpu.init()
    result["gpu_backend_init"] = "ok"
except Exception as exc:
    result["gpu_backend_init"] = f"error: {exc}"

prefs = bpy.context.preferences.addons["cycles"].preferences
try:
    prefs.compute_device_type = "OPTIX"
except Exception as exc:
    result["cycles"]["set_optix_error"] = str(exc)
prefs.get_devices()
devices=[]
for dev in prefs.devices:
    devices.append({"name": dev.name, "type": dev.type, "use": bool(dev.use)})
result["cycles"]["devices"] = devices
result["cycles"]["optix_visible"] = any(d["type"] == "OPTIX" and "T4" in d["name"].upper() for d in devices)
print("BLENDER_GPU_PROBE=" + json.dumps(result, sort_keys=True))
if not result["cycles"]["optix_visible"]:
    raise SystemExit(2)
