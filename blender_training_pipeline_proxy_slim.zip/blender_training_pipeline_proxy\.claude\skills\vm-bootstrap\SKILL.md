---
name: vm-bootstrap
description: Safe first-time provisioning of the Azure animation VM. Use for OS packages, Azure GRID, Docker/NVIDIA Container Toolkit, Blender 5.2.1, Python environments, official Blender MCP server, or local AI services. Always run hardware-qualification first and never install a host CUDA Toolkit.
---

# VM Bootstrap

Follow scripts in numeric order. Do not collapse the preflight and driver phases.

1. read-only hardware preflight
2. base Linux/graphics/audio/Docker packages
3. Microsoft-documented Azure NCasT4_v3 GRID driver
4. reboot
5. post-driver T4/UUID verification
6. Blender 5.2.1 with published SHA-256 verification
7. Python 3.11 host env + Python 3.13 bpy test env
8. official Blender Lab MCP server; add-on enabled in Blender
9. Ollama + CPU Kokoro services
10. OptiX/NVENC/container/service smoke test

Forbidden host packages: `nvidia-cuda-toolkit`, `cuda-toolkit-*`, anything installed only to obtain `nvcc`.
