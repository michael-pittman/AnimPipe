#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
import json
from pathlib import Path
p=Path('reports/environment/hardware-verified.json')
if not p.exists() or json.loads(p.read_text()).get('status') != 'pass':
    raise SystemExit('verified T4 hardware manifest required')
PY
VER=5.2.1
BASE="https://download.blender.org/release/Blender5.2"
ARCHIVE="blender-${VER}-linux-x64.tar.xz"
mkdir -p scratch/install/blender
cd scratch/install/blender
curl -fLO "$BASE/$ARCHIVE"
curl -fLO "$BASE/blender-${VER}.sha256"
grep " $ARCHIVE$" "blender-${VER}.sha256" | sha256sum -c -
sudo rm -rf "/opt/blender-${VER}-linux-x64"
sudo tar -xJf "$ARCHIVE" -C /opt
sudo ln -sfn "/opt/blender-${VER}-linux-x64/blender" /usr/local/bin/blender
blender --version | head -n 2
