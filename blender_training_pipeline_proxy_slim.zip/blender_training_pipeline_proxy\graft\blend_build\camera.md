# blend_build/camera.py

- _key · function · L21-L31 — def _key(obj: Any, data_path: str, index: int, frame: int, value: float, easing: str) -> None
- setattr_indexed · function · L34-L35 — def setattr_indexed(obj: Any, data_path: str, index: int, value: float) -> None
- _find_fcurve · function · L38-L45 — def _find_fcurve(obj: Any, data_path: str, index: int) -> Any | None
- _all_fcurves · function · L48-L56 — def _all_fcurves(action: Any) -> list[Any]
- build_camera · function · L59-L157 — def build_camera(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> Any
- _tval · function · L80-L87 — def _tval(key: str, portrait_key: str, fallback: Any) -> Any
- _build_move · function · L160-L188 — def _build_move(ctx: BuildContext, camera: Any) -> None
- _configured_default_amount · function · L191-L200 — def _configured_default_amount(ctx: BuildContext, move_type: str) -> float
- _build_orbit · function · L203-L209 — def _build_orbit(camera: Any, start_frame: int, duration: int, easing: str, orbit_deg: float) -> None
- _build_follow_path · function · L212-L250 — def _build_follow_path( ctx: BuildContext, camera: Any, move: dict[str, Any], start_frame: int, duration: int, easing: str, ) -> None
