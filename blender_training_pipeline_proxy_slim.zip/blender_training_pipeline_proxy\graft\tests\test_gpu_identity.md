# tests/test_gpu_identity.py

- test_verified_identity · function · L9-L29 — def test_verified_identity(monkeypatch, tmp_path: Path) -> None
- test_verified_identity_rejects_nonpass_manifest · function · L32-L52 — def test_verified_identity_rejects_nonpass_manifest(monkeypatch, tmp_path: Path) -> None
