---
name: hardware-qualification
description: Hardware identity and trust rules for the Azure NCasT4_v3 host. Use before any driver install, GPU gate, render, local vision model, GPU speech/alignment job, or when hardware state may have changed. Never infer hardware from config; verify Azure IMDS first and then verify the live NVIDIA UUID after the driver is installed.
---

# Hardware Qualification

Hardware is an observed fact, never a config assumption.

## Phase A: before modifying the host
Run `python3 scripts/00_hardware_preflight.py`. Require a passing report for Azure VM size `Standard_NC4as_T4_v3`, 4 vCPU class, ~28 GiB RAM, and an NVIDIA PCI device when visible. This step is read-only.

Do not install GPU software if the SKU check fails.

## Phase B: after Azure GRID + reboot
Run `python3 scripts/30_verify_gpu.py`. Require:
- exactly one GPU
- model contains `Tesla T4` or `T4`
- total memory is in the T4 16 GB reporting range
- one stable GPU UUID
- driver is usable

The script writes `reports/environment/hardware-verified.json`.

## Every GPU job
Before VRAM admission or lock acquisition:
1. load the verified manifest;
2. run a fresh `nvidia-smi` query;
3. require the same UUID and model;
4. read current free/total VRAM;
5. only then evaluate configured workload estimate + reserve.

If identity differs, block. Never silently regenerate the manifest during a job.
