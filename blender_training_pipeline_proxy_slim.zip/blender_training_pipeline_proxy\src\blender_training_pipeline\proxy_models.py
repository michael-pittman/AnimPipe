from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .models import CameraTemplateSpec, LightRigPreset, StyleConfig


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ProxyActionSpec(StrictModel):
    name: str
    category: Literal["locomotion", "gesture", "head", "interaction", "idle", "pose"]
    duration_frames: int = Field(ge=1)
    track: str
    loop: bool = False
    description: str


class ProxyPropSpec(StrictModel):
    id: str
    collection: str
    primitive: Literal["cube", "cylinder", "card", "tablet", "pointer"]
    dimensions: tuple[float, float, float]
    material_role: str = "prop"
    interaction_points: dict[str, str] = Field(default_factory=dict)


class ProxyPathSpec(StrictModel):
    id: str
    object: str
    points: list[tuple[float, float, float]]

    @model_validator(mode="after")
    def enough_points(self) -> "ProxyPathSpec":
        if len(self.points) < 2:
            raise ValueError("proxy path requires at least two points")
        return self


class ProxyCharacterGeometry(StrictModel):
    height_m: float = Field(default=1.8, gt=0)
    head_radius_m: float = Field(default=0.18, gt=0)
    torso_width_m: float = Field(default=0.42, gt=0)
    torso_depth_m: float = Field(default=0.24, gt=0)
    torso_height_m: float = Field(default=0.62, gt=0)
    limb_radius_m: float = Field(default=0.075, gt=0)
    hand_radius_m: float = Field(default=0.09, gt=0)
    foot_dimensions_m: tuple[float, float, float] = (0.18, 0.32, 0.10)


class ProxyCharacterSpec(StrictModel):
    id: str = "char.proxy_instructor"
    collection: str = "COL_PROXY_CHARACTER"
    armature: str = "RIG_PROXY"
    retarget_profile: str = "proxy_rig_v1"
    geometry: ProxyCharacterGeometry = Field(default_factory=ProxyCharacterGeometry)
    actions: list[ProxyActionSpec]
    visemes: dict[str, str]
    expressions: list[str]
    attachment_bones: dict[str, str]


class ProxySetElement(StrictModel):
    name: str
    primitive: Literal["cube", "cylinder"]
    location: tuple[float, float, float]
    dimensions: tuple[float, float, float]
    material_role: str


class ProxySetSpec(StrictModel):
    id: str = "set.proxy_room"
    collection: str = "COL_PROXY_ROOM"
    material_roles: list[str] = Field(
        default_factory=lambda: ["background", "set", "foreground", "focus"]
    )
    elements: list[ProxySetElement] = Field(default_factory=list)


class ProxyOverlaySpec(StrictModel):
    id: str
    filename: str
    kind: Literal["panel", "ring", "arrow", "frame", "end_card"]
    material_role: str = "ui"
    width: int = Field(default=960, ge=32)
    height: int = Field(default=540, ge=32)


class ProxyKitSpec(StrictModel):
    version: str = "1.0.0"
    style: StyleConfig
    character: ProxyCharacterSpec
    set: ProxySetSpec
    props: list[ProxyPropSpec]
    paths: list[ProxyPathSpec]
    overlays: list[ProxyOverlaySpec]
    camera_templates: dict[str, CameraTemplateSpec]
    lighting_presets: dict[str, LightRigPreset]

    @model_validator(mode="after")
    def unique_ids(self) -> "ProxyKitSpec":
        ids = [self.character.id, self.set.id]
        ids.extend(p.id for p in self.props)
        ids.extend(p.id for p in self.paths)
        ids.extend(o.id for o in self.overlays)
        if len(ids) != len(set(ids)):
            raise ValueError("proxy kit asset IDs must be unique")
        action_names = [a.name for a in self.character.actions]
        if len(action_names) != len(set(action_names)):
            raise ValueError("proxy action names must be unique")
        return self
