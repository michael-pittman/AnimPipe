# tests/test_proxy_kit.py

- test_proxy_kit_contract_counts_and_neutral_style · function · L16-L30 — def test_proxy_kit_contract_counts_and_neutral_style() -> None
- test_all_acceptance_shots_compile_and_reference_vocabulary · function · L33-L57 — def test_all_acceptance_shots_compile_and_reference_vocabulary() -> None
- test_acceptance_plan_lists_all_ten_shots · function · L60-L64 — def test_acceptance_plan_lists_all_ten_shots() -> None
- test_proxy_manifest_builder_uses_logical_assets · function · L67-L84 — def test_proxy_manifest_builder_uses_logical_assets(tmp_path: Path) -> None
- test_proxy_acceptance_runs_visual_qa_by_default · function · L87-L89 — def test_proxy_acceptance_runs_visual_qa_by_default() -> None
