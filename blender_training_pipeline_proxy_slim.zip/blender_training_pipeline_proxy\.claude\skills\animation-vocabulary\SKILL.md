---
name: animation-vocabulary
description: Compose engaging proxy animation from the canonical reusable Actions, facial cues, props, camera templates, and light rigs.
---
# Animation Vocabulary

Prefer reusable vocabulary over bespoke keyframes.

## Body Actions

Base/locomotion:
- `idle_neutral_loop`
- `walk_cycle`
- `turn_left_90`
- `turn_right_90`

Gesture/head:
- `gesture_present`
- `point_left`
- `point_right`
- `wave`
- `head_nod`
- `head_shake`

Interaction:
- `reach_grab`
- `place_release`

Held poses:
- `pose_neutral`, `pose_present`, `pose_listen`, `pose_think`
- `pose_point`, `pose_hold`, `pose_ready`, `pose_end`

Layer base motion, gesture/head, and interaction Actions on separate NLA tracks. Use facial cues for short shape-key states and Rhubarb artifacts for visemes.

## Facial vocabulary

Visemes: `VISEME_A` through `VISEME_H`, plus `VISEME_X` rest.

Expression controls: `BLINK`, `BROW_UP`, `BROW_DOWN`, `EXP_smile`, `EXP_frown`, `EXP_surprise`, `LOOK_LEFT`, `LOOK_RIGHT`.

## Camera vocabulary

Use semantic templates from `camera.templates`: `wide_stage`, `medium_presenter`, `close_face`, `over_shoulder`, `insert_prop`, `path_move`, `topdown`. Templates resolve relative to the framing target; do not replace them with arbitrary coordinates unless the shot requires a measured exception.

## Lighting vocabulary

Use `high_key_neutral` for diagnostic clarity by default. Use `three_point_character`, `screen_demo`, or `dramatic_test` only when the acceptance intent needs that contrast.

## Prop interaction

Props are manifest-backed instances. Attach them to declared character bones on configured frames and release using an explicit transform. Do not silently retarget or invent bone names.

## Director rule

The vocabulary proves timing, staging, interaction, and readability. It is not a final style. Preserve the role-based proxy palette and avoid adding decorative detail to make a shot “pretty.”
