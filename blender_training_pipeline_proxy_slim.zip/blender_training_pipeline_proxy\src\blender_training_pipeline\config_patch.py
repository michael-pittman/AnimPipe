from __future__ import annotations

from copy import deepcopy
from typing import Any

from omegaconf import OmegaConf

from .models import PipelineConfig
from .qa_models import VisualReview


def _allowed(path: str, prefixes: list[str]) -> bool:
    return any(path.startswith(prefix) for prefix in prefixes)


def apply_review_candidate(resolved: dict[str, Any], review: VisualReview) -> dict[str, Any]:
    cfg = OmegaConf.create(deepcopy(resolved))
    policy = PipelineConfig.model_validate(resolved).qa
    for change in review.changes:
        if not _allowed(change.path, policy.allowed_patch_prefixes):
            raise ValueError(f"VLM patch path is not allow-listed: {change.path}")
        OmegaConf.update(cfg, change.path, change.proposed_value, merge=False)
    raw = OmegaConf.to_container(cfg, resolve=True)
    assert isinstance(raw, dict)
    candidate = PipelineConfig.model_validate(raw)
    return candidate.model_dump(mode="json", by_alias=True)
