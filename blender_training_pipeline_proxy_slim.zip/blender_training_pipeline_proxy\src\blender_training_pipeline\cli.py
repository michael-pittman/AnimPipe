from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Annotated

import typer
import yaml
from rich import print

from asset_system.doctor import export_manifest_json, safe_asset_path, static_doctor
from asset_system.models import AssetManifest

from .alignment import align_words_cpu
from .config_compile import validate_director_script, write_compiled
from .delivery import build_shot, contact_sheet, encode, render_frames
from .frame_regression import compare_images
from .gpu_lock import gpu_lock
from .hardware import refresh_gpu_uuid, verify_live_identity
from .models import PipelineConfig
from .proxy_acceptance import purge_failed_dirs, run_proxy_acceptance
from .proxy_factory import generate_proxy_kit, load_proxy_kit
from .qa_loop import review_iteration, run_loop
from .tts import KokoroClient
from .visemes import rhubarb_cues
from .vision_review import review_preview

app = typer.Typer(no_args_is_help=True)
config_app = typer.Typer(no_args_is_help=True)
qa_app = typer.Typer(no_args_is_help=True)
asset_app = typer.Typer(no_args_is_help=True)
gpu_app = typer.Typer(no_args_is_help=True)
hardware_app = typer.Typer(no_args_is_help=True)
build_app = typer.Typer(no_args_is_help=True)
render_app = typer.Typer(no_args_is_help=True)
audio_app = typer.Typer(no_args_is_help=True)
proxy_app = typer.Typer(no_args_is_help=True)
for name, sub in [
    ("config", config_app), ("qa", qa_app), ("asset", asset_app), ("gpu", gpu_app),
    ("hardware", hardware_app), ("build", build_app), ("render", render_app), ("audio", audio_app),
    ("proxy", proxy_app),
]:
    app.add_typer(sub, name=name)


def _cfg(path: Path) -> PipelineConfig:
    return PipelineConfig.model_validate(json.loads(path.read_text(encoding="utf-8")))


@config_app.command("compile")
def compile_cmd(
    layers: Annotated[list[Path], typer.Argument(help="YAML layers in precedence order")],
    output: Annotated[Path, typer.Option("--output", "-o")] = Path("build/resolved_config.json"),
    set_values: Annotated[list[str] | None, typer.Option("--set")] = None,
) -> None:
    digest = write_compiled(layers, output, set_values)
    print(f"[green]valid[/green] {output} sha256={digest}")


@config_app.command("validate-scene")
def validate_scene(path: Path) -> None:
    model = validate_director_script(path)
    print(f"[green]valid director script[/green] {model.scene.id}")


@asset_app.command("doctor")
def asset_doctor_cmd(
    asset_id: str,
    manifest: Path = Path("assets/assets.yaml"),
    assets_root: Path = Path("assets"),
    blender_check: bool = typer.Option(False, "--blender"),
    report: Path | None = typer.Option(None, "--report"),
) -> None:
    static = static_doctor(manifest, asset_id, assets_root)
    result: dict[str, object] = {"static": static, "passed": bool(static["passed"])}
    if blender_check and static["passed"]:
        raw = yaml.safe_load(manifest.read_text(encoding="utf-8"))
        entry = AssetManifest.model_validate(raw).assets[asset_id]
        blend_path = safe_asset_path(assets_root, entry.file)
        blender_report = report or Path("reports/assets") / f"{asset_id.replace('.', '_')}.blender.json"
        blender_report.parent.mkdir(parents=True, exist_ok=True)
        cmd = [
            "blender", "--background", "--factory-startup", "--python",
            "blend_build/asset_doctor_blender.py", "--", "--blend", str(blend_path),
            "--report", str(blender_report),
        ]
        if entry.collection:
            cmd += ["--collection", entry.collection]
        if entry.rig:
            cmd += ["--armature", entry.rig.armature]
            if entry.rig.required_actions:
                cmd += ["--actions", *entry.rig.required_actions]
            if entry.rig.visemes:
                cmd += ["--visemes", *entry.rig.visemes.values()]
            if entry.rig.facial_controls:
                cmd += ["--expressions", *entry.rig.facial_controls]
        proc = subprocess.run(cmd, check=False)
        if not blender_report.exists():
            raise typer.Exit(code=proc.returncode or 2)
        blender_data = json.loads(blender_report.read_text(encoding="utf-8"))
        result["blender"] = blender_data
        result["passed"] = bool(result["passed"]) and bool(blender_data.get("passed"))
    print(json.dumps(result, indent=2))
    if not result["passed"]:
        raise typer.Exit(code=2)


@asset_app.command("export-manifest")
def export_manifest_cmd(
    manifest: Path = Path("assets/assets.yaml"),
    output: Annotated[Path, typer.Option("--output", "-o")] = Path("build/assets.resolved.json"),
) -> None:
    print(f"[green]exported[/green] {export_manifest_json(manifest, output)}")


@hardware_app.command("live")
def hardware_live_cmd(manifest: Path = Path("reports/environment/hardware-verified.json")) -> None:
    print(json.dumps(verify_live_identity(manifest).__dict__, indent=2))


@hardware_app.command("refresh-uuid")
def hardware_refresh_uuid_cmd(
    manifest: Path = Path("reports/environment/hardware-verified.json"),
) -> None:
    """Update the GPU UUID in the verified manifest after a VM restart.

    Azure reassigns the GPU UUID on every restart. Run this command before any
    pipeline work after a VM restart or resume. It verifies the GPU model and
    VRAM still match before accepting the new UUID.
    """
    old, new = refresh_gpu_uuid(manifest)
    if old == new:
        print(f"[green]UUID unchanged[/green]: {new}")
    else:
        print(f"[yellow]UUID updated[/yellow]: {old} → {new}")


@gpu_app.command("run")
def gpu_run_cmd(
    workload: str,
    estimated_peak_mib: int,
    command: Annotated[list[str], typer.Argument(help="Command to run under the GPU compute lock")],
    reserve_mib: int = 2048,
    timeout_seconds: int = 3600,
    manifest: Path = Path("reports/environment/hardware-verified.json"),
) -> None:
    with gpu_lock(workload, estimated_peak_mib, reserve_mib, timeout_seconds, manifest_path=manifest):
        raise typer.Exit(code=subprocess.call(command))


@build_app.command("shot")
def build_shot_cmd(
    config: Annotated[Path, typer.Option("--config", "-c")],
    output: Annotated[Path, typer.Option("--output", "-o")],
    manifest: Path = Path("build/assets.resolved.json"),
    assets_root: Path = Path("assets"),
    preview: bool = typer.Option(False, "--preview"),
) -> None:
    report = build_shot(config=config, manifest=manifest, output=output, assets_root=assets_root, preview=preview)
    print(json.dumps(report, indent=2))
    if report.get("status") != "ok":
        raise typer.Exit(code=2)


@render_app.command("frames")
def render_frames_cmd(
    blend: Path,
    output_dir: Annotated[Path, typer.Option("--output-dir", "-o")],
    resolved_config: Annotated[Path, typer.Option("--config")],
    frames: Annotated[str | None, typer.Option("--frames")] = None,
    preview: bool = typer.Option(False, "--preview"),
    manifest: Path = Path("reports/environment/hardware-verified.json"),
) -> None:
    frame_list = [int(f) for f in frames.split(",")] if frames else None
    cfg = _cfg(resolved_config)
    policy = cfg.resource_policy.gpu
    workload_name = "cycles_preview" if preview else "cycles_final"
    workload = policy.workloads[workload_name]
    with gpu_lock(
        workload=workload_name, estimated_peak_mib=workload.estimated_peak_mib,
        reserve_mib=policy.reserve_mib, timeout_seconds=policy.lock_timeout_seconds,
        manifest_path=manifest,
    ):
        rendered = render_frames(blend=blend, output_dir=output_dir, frames=frame_list)
    print(json.dumps({"frames": len(rendered), "output_dir": str(output_dir)}, indent=2))


@render_app.command("encode")
def encode_cmd(
    frames_dir: Path,
    output: Annotated[Path, typer.Option("--output", "-o")],
    resolved_config: Annotated[Path, typer.Option("--config")],
    asset_manifest: Annotated[Path, typer.Option("--manifest")] = Path("build/assets.resolved.json"),
    assets_root: Path = Path("assets"),
    audio: Annotated[Path | None, typer.Option("--audio")] = None,
    hardware_manifest: Path = Path("reports/environment/hardware-verified.json"),
) -> None:
    cfg = _cfg(resolved_config)
    kwargs = dict(
        frames_dir=frames_dir, output=output, fps=cfg.render.fps, frame_start=cfg.render.frame_start,
        codec=cfg.output.video_codec, cq=cfg.output.cq, audio=audio,
        audio_codec=cfg.output.audio_codec, metadata=cfg.output.metadata,
        comp=cfg.comp.model_dump(mode="json"),
        dialogue=[line.model_dump(mode="json") for line in cfg.dialogue],
        asset_manifest=asset_manifest, assets_root=assets_root,
    )
    if cfg.output.video_codec.endswith("_nvenc"):
        policy = cfg.resource_policy.gpu
        workload = policy.workloads["nvenc"]
        with gpu_lock(
            "nvenc", workload.estimated_peak_mib, policy.reserve_mib,
            policy.lock_timeout_seconds, manifest_path=hardware_manifest,
        ):
            written = encode(**kwargs)
    else:
        written = encode(**kwargs)
    print(f"[green]encoded[/green] {written}")


@qa_app.command("compare")
def compare_cmd(current: Path, baseline: Path) -> None:
    print(json.dumps(compare_images(current, baseline), indent=2))


@qa_app.command("vision")
def vision_cmd(
    image: Path, intent: Path, resolved_config: Path, model: str | None = None,
    manifest: Path = Path("reports/environment/hardware-verified.json"),
) -> None:
    cfg = _cfg(resolved_config)
    policy = cfg.resource_policy.gpu
    workload = policy.workloads["vision_qa"]
    with gpu_lock(
        "vision_qa", workload.estimated_peak_mib, policy.reserve_mib,
        policy.lock_timeout_seconds, manifest_path=manifest,
    ):
        review = review_preview(
            image, intent.read_text(encoding="utf-8"), resolved_config.read_text(encoding="utf-8"),
            model=model or cfg.qa.vision_model,
        )
    print(review.model_dump_json(indent=2))


@qa_app.command("review-iteration")
def review_iteration_cmd(
    preview: Path, intent: Path, resolved_config: Path,
    report: Annotated[Path, typer.Option("--report")] = Path("reports/qa/review.json"),
    candidate: Annotated[Path | None, typer.Option("--candidate")] = None,
    iteration: Annotated[int, typer.Option("--iteration", min=0)] = 0,
    prior_report: Annotated[Path | None, typer.Option("--prior-report")] = None,
    hardware_manifest: Path = Path("reports/environment/hardware-verified.json"),
) -> None:
    result = review_iteration(
        preview=preview, intent=intent, resolved_config=resolved_config, report=report,
        candidate_config=candidate, iteration=iteration, prior_report=prior_report,
        hardware_manifest=hardware_manifest,
    )
    print(json.dumps(result, indent=2))


@qa_app.command("run-loop")
def run_loop_cmd(
    resolved_config: Annotated[Path, typer.Option("--config", "-c")],
    intent: Annotated[Path, typer.Option("--intent")],
    asset_manifest: Annotated[Path, typer.Option("--manifest")] = Path("build/assets.resolved.json"),
    assets_root: Path = Path("assets"),
    work_dir: Annotated[Path, typer.Option("--work-dir")] = Path("reports/qa/run"),
    hardware_manifest: Path = Path("reports/environment/hardware-verified.json"),
    keep_frames: bool = typer.Option(False, "--keep-frames/--no-keep-frames", help="Retain raw PNG frames after contact sheet is built"),
) -> None:
    result = run_loop(
        resolved_config=resolved_config, intent=intent, asset_manifest=asset_manifest,
        assets_root=assets_root, work_dir=work_dir, hardware_manifest=hardware_manifest,
        keep_frames=keep_frames,
    )
    print(json.dumps(result, indent=2))
    if result["status"] == "escalate":
        raise typer.Exit(code=2)


@qa_app.command("contact-sheet")
def contact_sheet_cmd(
    frames_dir: Path,
    output: Annotated[Path, typer.Option("--output", "-o")] = Path("reports/qa/contact.png"),
    resolved_config: Annotated[Path | None, typer.Option("--config")] = None,
    columns: int = 3,
) -> None:
    frames = sorted(frames_dir.glob("*.png"))
    if resolved_config is not None:
        wanted = _cfg(resolved_config).preview.contact_sheet_frames
        selected = [p for p in frames if p.stem.isdigit() and int(p.stem) in wanted]
        frames = selected or frames
    written = contact_sheet(frames=frames, output=output, columns=columns)
    print(f"[green]contact sheet[/green] {written} ({len(frames)} frames)")


@audio_app.command("synthesize")
def audio_synthesize_cmd(
    text: str,
    output: Annotated[Path, typer.Option("--output", "-o")],
    voice: str = "af_heart",
    speed: float = 1.0,
) -> None:
    written = KokoroClient().synthesize(text, output, voice=voice, speed=speed)
    print(f"[green]tts[/green] {written}")


@audio_app.command("visemes")
def audio_visemes_cmd(
    wav: Path,
    output: Annotated[Path, typer.Option("--output", "-o")],
    transcript: Annotated[Path | None, typer.Option("--transcript")] = None,
) -> None:
    print(json.dumps(rhubarb_cues(wav, output, transcript), indent=2))


@audio_app.command("align")
def audio_align_cmd(
    wav: Path,
    output: Annotated[Path, typer.Option("--output", "-o")],
    model_size: str = "small",
) -> None:
    print(json.dumps(align_words_cpu(wav, output, model_size=model_size), indent=2))


@proxy_app.command("validate")
def proxy_validate_cmd(spec: Path = Path("proxy_kit/kit.yaml")) -> None:
    kit = load_proxy_kit(spec)
    print(json.dumps({
        "status": "valid", "version": kit.version, "style": kit.style.id,
        "actions": len(kit.character.actions), "props": len(kit.props),
        "paths": len(kit.paths), "overlays": len(kit.overlays),
        "camera_templates": len(kit.camera_templates),
        "lighting_presets": len(kit.lighting_presets),
    }, indent=2))


@proxy_app.command("generate")
def proxy_generate_cmd(
    spec: Path = Path("proxy_kit/kit.yaml"),
    assets_root: Path = Path("assets"),
    output_subdir: str = "proxy",
    manifest: Path = Path("assets/assets.proxy.yaml"),
    resolved_manifest: Path = Path("build/assets.proxy.resolved.json"),
    report: Path = Path("reports/proxy/generation.json"),
) -> None:
    result = generate_proxy_kit(
        spec_path=spec, assets_root=assets_root, output_subdir=output_subdir,
        manifest_path=manifest, resolved_manifest=resolved_manifest, report_path=report,
    )
    print(json.dumps(result, indent=2))


@proxy_app.command("acceptance")
def proxy_acceptance_cmd(
    plan: Path = Path("proxy_kit/acceptance.yaml"),
    manifest: Path = Path("build/assets.proxy.resolved.json"),
    assets_root: Path = Path("assets"),
    work_dir: Path = Path("build/proxy_acceptance"),
    hardware_manifest: Path = Path("reports/environment/hardware-verified.json"),
    preview: bool = typer.Option(True, "--preview/--final"),
    audio: bool = typer.Option(True, "--audio/--no-audio"),
    qa: bool = typer.Option(True, "--qa/--no-qa"),
    keep_runs: int = typer.Option(3, "--keep-runs", help="Number of prior run dirs to keep (0 = disable rotation)"),
    auto_purge: bool = typer.Option(True, "--auto-purge/--no-auto-purge", help="Delete failed run dirs before starting"),
    skip_existing_audio: bool = typer.Option(False, "--skip-existing-audio/--no-skip-existing-audio", help="Reuse pre-synthesized audio/visemes if already present in the shot dir"),
) -> None:
    result = run_proxy_acceptance(
        plan_path=plan, manifest=manifest, assets_root=assets_root, work_dir=work_dir,
        hardware_manifest=hardware_manifest, preview=preview, audio=audio, qa=qa,
        keep_runs=keep_runs, auto_purge=auto_purge, skip_existing_audio=skip_existing_audio,
    )
    print(json.dumps(result, indent=2))


@app.command("purge-failed")
def purge_failed_cmd(
    build_dir: Path = typer.Argument(Path("build"), help="Root dir to scan for run dirs"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Print what would be deleted without deleting"),
    keep_successful: bool = typer.Option(True, "--keep-successful/--no-keep-successful", help="Never delete dirs that have a passing build_manifest.json"),
) -> None:
    failed, kept = purge_failed_dirs(build_dir, keep_successful=keep_successful, dry_run=dry_run)
    verb = "would remove" if dry_run else "removed"
    for run_dir, reason in failed:
        typer.echo(f"{verb} {run_dir}  [{reason}]")
    typer.echo(f"Removed {len(failed)} failed dirs, kept {kept}.")


if __name__ == "__main__":
    app()
