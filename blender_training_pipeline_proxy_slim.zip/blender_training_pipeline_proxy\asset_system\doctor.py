from __future__ import annotations

import hashlib
import json
from pathlib import Path

import yaml

from .models import AssetManifest


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_asset_path(assets_root: Path, relative: str) -> Path:
    root = assets_root.resolve()
    path = (root / relative).resolve()
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"asset path escapes assets root: {relative}") from exc
    return path


def static_doctor(manifest_path: Path, asset_id: str, assets_root: Path) -> dict:
    manifest = AssetManifest.model_validate(yaml.safe_load(manifest_path.read_text(encoding="utf-8")))
    if asset_id not in manifest.assets:
        raise KeyError(f"unknown asset id: {asset_id}")
    entry = manifest.assets[asset_id]
    path = safe_asset_path(assets_root, entry.file)
    checks: dict[str, bool] = {"path_within_assets_root": True, "exists": path.exists()}
    if path.exists():
        checks["sha256_matches"] = file_sha256(path) == entry.sha256
    if entry.kind == "character":
        checks["rig_contract_present"] = entry.rig is not None
        checks["retarget_profile_present"] = bool(entry.rig and entry.rig.retarget_profile)
        checks["action_vocabulary_present"] = bool(entry.rig and entry.rig.required_actions)
        checks["viseme_map_present"] = bool(entry.rig and entry.rig.visemes)
        if entry.rig and entry.rig.facial_controls:
            checks["facial_control_contract_present"] = True
    if entry.kind == "path":
        checks["path_target_named"] = bool(entry.object or entry.collection)
    return {"asset_id": asset_id, "path": str(path), "checks": checks, "passed": all(checks.values())}


def export_manifest_json(manifest: Path, output: Path) -> Path:
    """Validate assets.yaml and emit the deterministic JSON snapshot Blender consumes."""
    raw = yaml.safe_load(manifest.read_text(encoding="utf-8"))
    model = AssetManifest.model_validate(raw)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(model.model_dump(mode="json"), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return output
