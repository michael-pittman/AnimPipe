from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from asset_system.models import AssetEntry
from blender_training_pipeline.delivery import DeliveryError, resolve_delivery_asset, write_dialogue_srt
from blender_training_pipeline.models import CameraMove, OverlaySlot, PipelineConfig, RenderConfig


def test_asset_path_traversal_rejected() -> None:
    with pytest.raises(ValidationError):
        AssetEntry(kind="overlay", version="1", sha256="x", file="../secret.png")


def test_path_asset_requires_target() -> None:
    with pytest.raises(ValidationError):
        AssetEntry(kind="path", version="1", sha256="x", file="paths/a.blend")


def test_follow_path_requires_asset() -> None:
    with pytest.raises(ValidationError):
        CameraMove(type="follow_path", duration_frames=20)


def test_follow_path_axes_differ() -> None:
    with pytest.raises(ValidationError):
        CameraMove(
            type="follow_path", duration_frames=20, path_asset_id="path.a",
            forward_axis="FORWARD_Z", up_axis="UP_Z",
        )


def test_overlay_expression_injection_rejected() -> None:
    with pytest.raises(ValidationError):
        OverlaySlot(asset_id="overlay.a", start_frame=1, end_frame=10, x="0;movie=/etc/passwd")


def test_blender_eevee_identifier_only() -> None:
    assert RenderConfig(engine="BLENDER_EEVEE").engine == "BLENDER_EEVEE"
    with pytest.raises(ValidationError):
        RenderConfig(engine="BLENDER_EEVEE_NEXT")


def test_gpu_policy_has_no_whisper_cuda_workload() -> None:
    workloads = PipelineConfig().resource_policy.gpu.workloads
    assert "cycles_preview" in workloads
    assert "cycles_final" in workloads
    assert "vision_qa" in workloads
    assert "nvenc" in workloads
    assert "whisper_gpu" not in workloads


def test_srt_explicit_end_required(tmp_path: Path) -> None:
    with pytest.raises(DeliveryError, match="end_frame"):
        write_dialogue_srt(
            [{"start_frame": 24, "text": "hello"}], fps=24, output=tmp_path / "a.srt"
        )


def test_srt_uses_frame_timing(tmp_path: Path) -> None:
    out = write_dialogue_srt(
        [{"start_frame": 24, "end_frame": 48, "text": "hello"}],
        fps=24,
        output=tmp_path / "a.srt",
    )
    text = out.read_text()
    assert "00:00:01,000 --> 00:00:02,000" in text


def test_delivery_asset_resolves_logical_id_and_kind(tmp_path: Path) -> None:
    assets = tmp_path / "assets"
    (assets / "luts").mkdir(parents=True)
    lut = assets / "luts" / "grade.cube"
    lut.write_text("TITLE test\n")
    digest = hashlib.sha256(lut.read_bytes()).hexdigest()
    manifest = tmp_path / "assets.json"
    manifest.write_text(json.dumps({
        "assets": {
            "lut.grade": {
                "kind": "lut", "version": "1", "sha256": digest, "file": "luts/grade.cube"
            }
        }
    }))
    assert resolve_delivery_asset(
        "lut.grade", manifest_path=manifest, assets_root=assets, expected_kind="lut"
    ) == lut.resolve()
    with pytest.raises(DeliveryError, match="kind=overlay"):
        resolve_delivery_asset(
            "lut.grade", manifest_path=manifest, assets_root=assets, expected_kind="overlay"
        )
