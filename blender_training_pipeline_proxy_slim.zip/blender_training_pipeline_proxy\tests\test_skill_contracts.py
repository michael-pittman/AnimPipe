import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_bundle_validator() -> None:
    subprocess.run([sys.executable, str(ROOT / "scripts/90_validate_bundle.py")], cwd=ROOT, check=True)
