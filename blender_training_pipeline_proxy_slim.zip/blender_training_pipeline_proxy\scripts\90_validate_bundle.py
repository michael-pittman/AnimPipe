#!/usr/bin/env python3
from __future__ import annotations

import ast
import hashlib
import json
import re
import shutil
import subprocess
import tomllib
import zipfile
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
checks: dict[str, object] = {}


def error(message: str) -> None:
    errors.append(message)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def frontmatter(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        error(f"missing YAML frontmatter: {path.relative_to(ROOT)}")
        return {}
    try:
        _, fm, _ = text.split("---", 2)
        obj = yaml.safe_load(fm) or {}
        if not isinstance(obj, dict):
            raise TypeError("frontmatter is not a mapping")
        return obj
    except Exception as exc:
        error(f"invalid frontmatter {path.relative_to(ROOT)}: {exc}")
        return {}


# Skills: concise, named, described, packaged.
skill_names: set[str] = set()
skill_lines: dict[str, int] = {}
for skill_md in sorted((ROOT / ".claude/skills").glob("*/SKILL.md")):
    fm = frontmatter(skill_md)
    name = fm.get("name")
    desc = fm.get("description")
    if not name or name != skill_md.parent.name:
        error(f"skill name/path mismatch: {skill_md.relative_to(ROOT)}")
    if not desc:
        error(f"skill description missing: {skill_md.relative_to(ROOT)}")
    lines = len(skill_md.read_text(encoding="utf-8").splitlines())
    if lines > 300:
        error(f"skill exceeds 300-line project cap: {skill_md.relative_to(ROOT)} ({lines})")
    skill_names.add(skill_md.parent.name)
    skill_lines[skill_md.parent.name] = lines
checks["skills"] = {"count": len(skill_names), "line_counts": skill_lines}

for name in sorted(skill_names):
    pkg = ROOT / "skill_packages/generated" / f"{name}.skill"
    if not pkg.exists() or not zipfile.is_zipfile(pkg):
        error(f"generated .skill package missing/invalid: {pkg.relative_to(ROOT)}")
        continue
    with zipfile.ZipFile(pkg) as zf:
        if f"{name}/SKILL.md" not in zf.namelist():
            error(f"invalid .skill internal layout: {pkg.relative_to(ROOT)}")

# Agents: referenced skills exist; max four preloaded; MCP only on debugger.
agent_info: dict[str, object] = {}
for agent_md in sorted((ROOT / ".claude/agents").glob("*.md")):
    fm = frontmatter(agent_md)
    skills = fm.get("skills") or []
    if not isinstance(skills, list):
        error(f"agent skills must be YAML list: {agent_md.name}")
        skills = []
    if len(skills) > 4:
        error(f"agent has >4 preloaded skills: {agent_md.name}")
    missing = [s for s in skills if s not in skill_names]
    if missing:
        error(f"agent {agent_md.name} references missing skills: {missing}")
    has_blender_mcp = "blender" in (fm.get("mcpServers") or [])
    if has_blender_mcp != (agent_md.stem == "blender-debugger"):
        error(f"Blender MCP boundary violation in {agent_md.name}")
    agent_info[agent_md.stem] = {"skills": skills, "blender_mcp": has_blender_mcp}
checks["agents"] = agent_info
if len(agent_info) != 10:
    error(f"expected 10 project agents, found {len(agent_info)}")

# Imported active skills may not invoke attached-repo custom MCP extensions unavailable here.
unsupported = re.compile(r"(?<![A-Za-z0-9_])(anim|pose|rig)\s*\(")
for skill_md in sorted((ROOT / ".claude/skills").glob("*/SKILL.md")):
    match = unsupported.search(skill_md.read_text(encoding="utf-8"))
    if match:
        error(f"unsupported custom Blender-agent MCP call in active skill: {skill_md.relative_to(ROOT)}")

# Blender-agent provenance: exact upstream copies are preserved; active copies are intentionally adapted.
for name in ["animating-basics", "lighting-setups"]:
    active = ROOT / ".claude/skills" / name / "SKILL.md"
    vendor = ROOT / "vendor/blender-agent-upstream/skills" / f"{name}.SKILL.md"
    if not active.exists() or not vendor.exists():
        error(f"Blender-agent selected skill missing: {name}")
    elif active.read_bytes() == vendor.read_bytes():
        error(f"Blender-agent active skill should carry project boundary adaptation: {name}")

# Preserve the six original .skill packages byte-for-byte in both provenance locations.
original_names = [
    "handoff-format", "instructional-design", "patch-proposal-format",
    "perceptual-frame-review", "pipeline-contracts", "repo-boundaries",
]
for name in original_names:
    a = ROOT / "skill_packages" / f"{name}.skill"
    b = ROOT / "vendor/user-supplied-skills" / f"{name}.skill"
    if not a.exists() or not b.exists() or a.read_bytes() != b.read_bytes():
        error(f"user-supplied .skill preservation drift: {name}")

# Supported host Python must not reintroduce CUDA user-space runtime packages.
project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
all_deps = list(project.get("project", {}).get("dependencies", []))
for values in project.get("project", {}).get("optional-dependencies", {}).values():
    all_deps.extend(values)
for dep in all_deps:
    lowered = str(dep).lower()
    if "nvidia-cublas" in lowered or "nvidia-cudnn" in lowered:
        error(f"unsupported CUDA Python runtime dependency found: {dep}")

# Setup scripts must not install a host CUDA development toolkit.
for script in sorted((ROOT / "scripts").glob("*.sh")):
    text = script.read_text(encoding="utf-8")
    bad_install = re.search(r"(?:apt(?:-get)?\s+install[^\n]*)(?:nvidia-cuda-toolkit|cuda-toolkit-[0-9])", text)
    if bad_install:
        error(f"host CUDA Toolkit install found in {script.relative_to(ROOT)}")

# Shell syntax (use shutil.which to find the real bash, not a WSL stub on Windows).
_bash = shutil.which("bash")
for script in sorted((ROOT / "scripts").glob("*.sh")):
    if _bash is None:
        error(f"shell syntax error {script.relative_to(ROOT)}: bash not found in PATH")
        continue
    proc = subprocess.run([_bash, "-n", str(script)], capture_output=True, text=True)
    if proc.returncode:
        error(f"shell syntax error {script.relative_to(ROOT)}: {proc.stderr.strip()}")

# Python syntax without importing Blender.
python_files = (
    list((ROOT / "src").rglob("*.py"))
    + list((ROOT / "asset_system").rglob("*.py"))
    + list((ROOT / "blend_build").rglob("*.py"))
    + list((ROOT / "scripts").glob("*.py"))
    + list((ROOT / "tests").glob("*.py"))
)
for py in sorted(python_files):
    try:
        ast.parse(py.read_text(encoding="utf-8"), filename=str(py))
    except Exception as exc:
        error(f"python syntax error {py.relative_to(ROOT)}: {exc}")

# JSON/TOML/YAML examples.
for js in [
    ROOT / ".claude/settings.json", ROOT / ".mcp.json",
    ROOT / ".vscode/extensions.json", ROOT / ".vscode/settings.json", ROOT / ".vscode/tasks.json",
]:
    try:
        json.loads(js.read_text(encoding="utf-8"))
    except Exception as exc:
        error(f"invalid JSON {js.relative_to(ROOT)}: {exc}")
for toml in [ROOT / "pyproject.toml", ROOT / "pyproject-bpy.toml"]:
    try:
        tomllib.loads(toml.read_text(encoding="utf-8"))
    except Exception as exc:
        error(f"invalid TOML {toml.relative_to(ROOT)}: {exc}")
for yml in [ROOT / "config/base.yaml", ROOT / "config/project.yaml", ROOT / "config/scene/module_01.yaml", ROOT / "config/shot/m01_s030.yaml", ROOT / "assets/assets.yaml.example", ROOT / "config/proxy/style.yaml", ROOT / "config/proxy/vocabulary.yaml", ROOT / "config/proxy/acceptance/base.yaml", ROOT / "config/proxy/acceptance/scene.yaml", ROOT / "proxy_kit/kit.yaml", ROOT / "proxy_kit/acceptance.yaml", *sorted((ROOT / "config/proxy/acceptance/shot").glob("*.yaml"))]:
    try:
        yaml.safe_load(yml.read_text(encoding="utf-8"))
    except Exception as exc:
        error(f"invalid YAML {yml.relative_to(ROOT)}: {exc}")

# Required provenance and generated schema artifacts.
required = [
    ROOT / "vendor/blender-agent-upstream/blender-agent-main.zip",
    ROOT / "vendor/blender-agent-upstream/UPSTREAM_COMMIT.txt",
    ROOT / "vendor/blender-agent-upstream/ARCHIVE_SHA256.txt",
    ROOT / "vendor/blender-agent-upstream/PROVENANCE.json",
    ROOT / "docs/THIRD_PARTY_NOTICES.md",
    ROOT / "docs/BLENDER_AGENT_INTEGRATION.md",
    ROOT / "docs/FINAL_DECISIONS.md",
    ROOT / "vendor/blender-agent-upstream/GPL-3.0.txt",
    ROOT / "config/schema/pipeline.schema.json",
    ROOT / "config/schema/director-script.schema.json",
    ROOT / "config/schema/asset-manifest.schema.json",
    ROOT / "config/schema/visual-review.schema.json",
    ROOT / "config/schema/proxy-kit.schema.json",
]
for path in required:
    if not path.exists():
        error(f"missing required artifact: {path.relative_to(ROOT)}")

archive = ROOT / "vendor/blender-agent-upstream/blender-agent-main.zip"
recorded = (ROOT / "vendor/blender-agent-upstream/ARCHIVE_SHA256.txt").read_text().strip() if archive.exists() else ""
if archive.exists() and sha256(archive) != recorded:
    error("vendored Blender-agent archive SHA-256 does not match recorded value")

# Provenance record must match both exact preserved sources and adapted active skill bytes.
provenance_path = ROOT / "vendor/blender-agent-upstream/PROVENANCE.json"
if provenance_path.exists():
    provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
    if provenance.get("archive_sha256") != recorded:
        error("Blender-agent provenance archive SHA-256 drift")
    for item in provenance.get("selected_skills", []):
        name = item["name"]
        active = ROOT / ".claude/skills" / name / "SKILL.md"
        vendor = ROOT / "vendor/blender-agent-upstream/skills" / f"{name}.SKILL.md"
        if active.exists() and item.get("active_adapted_sha256") != sha256(active):
            error(f"active adapted Blender-agent skill SHA drift: {name}")
        if vendor.exists() and item.get("vendor_exact_sha256") != sha256(vendor):
            error(f"preserved Blender-agent source skill SHA drift: {name}")

report = {"status": "pass" if not errors else "fail", "errors": errors, "checks": checks}
out = ROOT / "reports/bundle-validation.json"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2, sort_keys=True))
raise SystemExit(0 if not errors else 1)
