from __future__ import annotations

from pathlib import Path
import inspect

import yaml

from blender_training_pipeline.config_compile import compile_pipeline
from blender_training_pipeline.proxy_factory import build_manifest, generate_overlays, load_proxy_kit
from blender_training_pipeline.proxy_acceptance import run_proxy_acceptance


ROOT = Path(__file__).resolve().parents[1]


def test_proxy_kit_contract_counts_and_neutral_style() -> None:
    kit = load_proxy_kit(ROOT / "proxy_kit/kit.yaml")
    assert kit.style.id == "proxy_clay_v1"
    assert kit.style.shading.texture_policy == "none"
    assert not kit.style.restrictions.hair_simulation
    assert not kit.style.restrictions.cloth_simulation
    assert len(kit.character.actions) == 20
    assert len([a for a in kit.character.actions if a.category != "pose"]) == 12
    assert len([a for a in kit.character.actions if a.category == "pose"]) == 8
    assert set(kit.character.visemes) == set("ABCDEFGHX")
    assert len(kit.props) == 6
    assert len(kit.paths) == 2
    assert len(kit.camera_templates) == 7
    assert len(kit.lighting_presets) == 4
    assert len(kit.overlays) == 5


def test_all_acceptance_shots_compile_and_reference_vocabulary() -> None:
    kit = load_proxy_kit(ROOT / "proxy_kit/kit.yaml")
    actions = {a.name for a in kit.character.actions}
    props = {p.id for p in kit.props}
    paths = {p.id for p in kit.paths}
    common = [
        ROOT / "config/base.yaml",
        ROOT / "config/proxy/style.yaml",
        ROOT / "config/proxy/vocabulary.yaml",
        ROOT / "config/proxy/acceptance/base.yaml",
        ROOT / "config/proxy/acceptance/scene.yaml",
    ]
    shot_paths = sorted((ROOT / "config/proxy/acceptance/shot").glob("*.yaml"))
    assert len(shot_paths) == 10
    for path in shot_paths:
        model, _, _ = compile_pipeline(common + [path])
        assert model.style.id == kit.style.id
        assert model.camera.template in kit.camera_templates
        assert model.lighting.rig_preset in kit.lighting_presets
        for member in model.cast:
            assert {strip.action for strip in member.actions} <= actions
        for prop in model.props:
            assert prop.asset_id in props
        if model.camera.move.path_asset_id:
            assert model.camera.move.path_asset_id in paths


def test_acceptance_plan_lists_all_ten_shots() -> None:
    raw = yaml.safe_load((ROOT / "proxy_kit/acceptance.yaml").read_text(encoding="utf-8"))
    assert len(raw["shots"]) == 10
    assert raw["shots"][0]["id"] == "proxy_s01"
    assert raw["shots"][-1]["id"] == "proxy_s10"


def test_proxy_manifest_builder_uses_logical_assets(tmp_path: Path) -> None:
    kit = load_proxy_kit(ROOT / "proxy_kit/kit.yaml")
    assets_root = tmp_path / "assets"
    output_root = assets_root / "proxy"
    output_root.mkdir(parents=True)
    for filename in [
        "proxy_character.blend", "proxy_environment.blend", "proxy_props.blend", "proxy_paths.blend"
    ]:
        (output_root / filename).write_bytes(("fake-" + filename).encode())
    generate_overlays(kit, output_root)
    manifest = build_manifest(kit, assets_root=assets_root, output_root=output_root)
    assert len(manifest.assets) == 15
    assert manifest.assets[kit.character.id].rig is not None
    assert manifest.assets[kit.character.id].rig.retarget_profile == "proxy_rig_v1"
    assert manifest.assets["prop.proxy_block"].collection == "COL_PROP_BLOCK"
    assert manifest.assets["path.proxy_short_arc"].object == "PATH_short_arc"
    assert manifest.assets["overlay.proxy.end_card"].kind == "overlay"
    assert all(not entry.file.startswith("/") for entry in manifest.assets.values())


def test_proxy_acceptance_runs_visual_qa_by_default() -> None:
    signature = inspect.signature(run_proxy_acceptance)
    assert signature.parameters["qa"].default is True
