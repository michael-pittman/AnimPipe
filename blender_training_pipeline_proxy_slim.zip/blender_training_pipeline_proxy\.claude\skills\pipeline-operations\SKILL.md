---
name: pipeline-operations
description: Safe execution and publishing rules for the pipeline runner. Use when invoking validate/build/preview/render/QA/mux/publish stages, resuming a job, or recording provenance. Enforce gates in order and never bypass hardware, config, asset or QA failures to get an output.
---

# Pipeline Operations

Expected order: compile/validate -> asset checks -> preview build/render -> deterministic QA -> VLM QA/revision loop -> human approval policy -> final image sequence -> mux -> publish.

Every stage writes a structured handoff and hashes its relevant inputs/artifacts.

GPU stages use `gpu-scheduling`. Final video encoding reads an already completed image sequence; it never becomes the Blender render target.

On failure, preserve partial diagnostics and mark the handoff blocked/rejected. Do not mutate source to make a run pass without the owning agent.
