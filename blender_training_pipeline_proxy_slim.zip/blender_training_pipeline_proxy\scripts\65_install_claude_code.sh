#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

if ! command -v claude >/dev/null 2>&1; then
  curl -fsSL https://claude.ai/install.sh | bash -s stable
fi
export PATH="$HOME/.local/bin:$PATH"
claude --version

if ! command -v uv >/dev/null 2>&1; then
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$PATH"
fi
if ! command -v pyright-langserver >/dev/null 2>&1; then
  uv tool install pyright
fi
pyright --version
command -v pyright-langserver >/dev/null

echo 'Claude Code installed. Authenticate interactively with `claude` if this VM has not been logged in yet.'
