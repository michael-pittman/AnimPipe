"""Preprocess TTS + lip-sync for one acceptance shot (CPU-only, no GPU).

Usage:
    uv run python scripts/preprocess_shot_audio.py <shot_id> <shot_config_yaml> <work_dir>

Outputs under <work_dir>/<shot_id>/audio/:
    speech.wav, transcript.txt, visemes.json

Safe to run in parallel with other shots — no GPU, no shared lock.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Run from the project root so relative imports resolve.
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root / "src"))

from blender_training_pipeline.config_compile import compile_pipeline
from blender_training_pipeline.tts import KokoroClient
from blender_training_pipeline.visemes import rhubarb_cues


def main() -> None:
    if len(sys.argv) != 4:
        print("Usage: preprocess_shot_audio.py <shot_id> <shot_config_yaml> <work_dir>")
        sys.exit(1)

    shot_id = sys.argv[1]
    shot_config = Path(sys.argv[2])
    work_dir = Path(sys.argv[3])

    common_layers = [
        Path("config/base.yaml"),
        Path("config/proxy/style.yaml"),
        Path("config/proxy/vocabulary.yaml"),
        Path("config/proxy/acceptance/base.yaml"),
        Path("config/proxy/acceptance/scene.yaml"),
    ]

    cfg, _, _ = compile_pipeline(common_layers + [shot_config], [])

    if not cfg.dialogue:
        print(f"[{shot_id}] no dialogue — nothing to preprocess")
        return

    if len(cfg.dialogue) != 1:
        print(f"[{shot_id}] ERROR: expected exactly 1 dialogue line, got {len(cfg.dialogue)}")
        sys.exit(1)

    line = cfg.dialogue[0]
    audio_dir = work_dir / shot_id / "audio"
    audio_dir.mkdir(parents=True, exist_ok=True)

    wav = audio_dir / "speech.wav"
    transcript = audio_dir / "transcript.txt"
    cues = audio_dir / "visemes.json"

    print(f"[{shot_id}] synthesizing TTS: {line.text!r}")
    KokoroClient().synthesize(line.text, wav, voice=line.voice_id, speed=1.0)

    transcript.write_text(line.text + "\n", encoding="utf-8")

    print(f"[{shot_id}] running rhubarb lip-sync...")
    rhubarb_cues(wav, cues, transcript)

    print(f"[{shot_id}] done — {wav}, {cues}")


if __name__ == "__main__":
    main()
