import json
from pathlib import Path

import pytest

from blender_training_pipeline.hardware import GpuSnapshot, verify_live_identity


def test_verified_identity(monkeypatch, tmp_path: Path) -> None:
    manifest = tmp_path / "hardware-verified.json"
    manifest.write_text(
        json.dumps(
            {
                "status": "pass",
                "gpu": {
                    "uuid": "GPU-test",
                    "name": "NVIDIA Tesla T4",
                    "memory_total_mib": 15360,
                },
            }
        ),
        encoding="utf-8",
    )
    monkeypatch.setattr(
        "blender_training_pipeline.hardware.query_gpus",
        lambda: [GpuSnapshot(0, "GPU-test", "NVIDIA Tesla T4", 15360, 14000, "595.58.03")],
    )
    gpu = verify_live_identity(manifest)
    assert gpu.uuid == "GPU-test"


def test_verified_identity_rejects_nonpass_manifest(monkeypatch, tmp_path: Path) -> None:
    manifest = tmp_path / "hardware-verified.json"
    manifest.write_text(
        json.dumps(
            {
                "status": "fail",
                "gpu": {
                    "uuid": "GPU-test",
                    "name": "NVIDIA Tesla T4",
                    "memory_total_mib": 15360,
                },
            }
        ),
        encoding="utf-8",
    )
    monkeypatch.setattr(
        "blender_training_pipeline.hardware.query_gpus",
        lambda: [GpuSnapshot(0, "GPU-test", "NVIDIA Tesla T4", 15360, 14000, "595.58.03")],
    )
    with pytest.raises(RuntimeError, match="not PASS"):
        verify_live_identity(manifest)
