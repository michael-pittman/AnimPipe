# Azure NCasT4_v3 Setup Runbook

This setup deliberately refuses to configure GPU software until it confirms the VM identity read-only.

## A. Azure prerequisites outside the VM

Target VM size: `Standard_NC4as_T4_v3`.
For Microsoft's documented Linux GRID procedure, Secure Boot and vTPM must be disabled.

## B. Read-only hardware preflight

```bash
python3 scripts/00_hardware_preflight.py
```

This records Azure IMDS VM size, CPU count, RAM, and visible PCI NVIDIA devices. It fails if the Azure SKU/CPU/RAM do not match the expected class. It does not trust `nvidia-smi` because the driver is not installed yet.

## C. Base packages

```bash
bash scripts/10_install_base_host.sh
```

This installs Linux/graphics/audio/build tooling, Docker Engine, and NVIDIA Container Toolkit. It explicitly does not install a CUDA Toolkit.

## D. Azure GRID driver

```bash
bash scripts/20_install_azure_grid_driver.sh
```

The script requires a passing preflight report and implements the current Microsoft NCasT4_v3 GRID download/install procedure. Reboot afterward.

## E. Post-driver hardware proof

```bash
python3 scripts/30_verify_gpu.py
```

This requires exactly one NVIDIA Tesla T4, records its immutable GPU UUID, checks reported memory is in the expected T4 range, and creates `reports/environment/hardware-verified.json`.

If this file does not exist, GPU scheduling and VRAM gating refuse to run.

## F. Blender and services

Continue with scripts 40–80 in numeric order. The smoke test verifies Blender version, OptiX device discovery, FFmpeg NVENC availability, Docker GPU passthrough, Ollama model access, and Kokoro readiness where those services are enabled.


## Pre-driver T4 proof

Before any package/driver mutation, `00_hardware_preflight.py` validates Azure IMDS SKU,
4 vCPU, expected RAM range, and raw NVIDIA PCI vendor/device identity `10de:1eb8`. NVIDIA
documents PCI device `1EB8` as Tesla T4. The post-driver verifier then records the runtime
GPU name, 16 GB-class VRAM, driver, and UUID. Every GPU lock re-queries and matches that UUID.
