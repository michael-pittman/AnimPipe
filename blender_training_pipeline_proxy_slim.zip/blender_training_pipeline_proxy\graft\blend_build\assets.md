# blend_build/assets.py

- _scene_and_view_layer · function · L14-L15 — def _scene_and_view_layer() -> tuple[Any, Any]
- link_collection · function · L18-L30 — def link_collection(blend_path: Path, collection_name: str) -> Any
- link_object · function · L33-L45 — def link_object(blend_path: Path, object_name: str) -> Any
- link_actions · function · L48-L59 — def link_actions(blend_path: Path, action_names: list[str]) -> dict[str, Any]
- instantiate_override · function · L62-L77 — def instantiate_override(linked_collection: Any, label: str) -> Any
- find_armature · function · L80-L96 — def find_armature(collection: Any, armature_name: str | None) -> Any
- root_object · function · L99-L103 — def root_object(collection: Any, armature: Any) -> Any
- _apply_spawn · function · L106-L112 — def _apply_spawn(obj: Any, spawn: dict[str, Any]) -> None
- _material_lookup · function · L115-L117 — def _material_lookup(overrides: dict[str, Any]) -> dict[str, Any]
- _apply_look_overrides · function · L120-L157 — def _apply_look_overrides(collection: Any, overrides: dict[str, Any]) -> None
- build_cast · function · L160-L201 — def build_cast(ctx: BuildContext) -> dict[str, dict[str, Any]]
- _find_object · function · L204-L208 — def _find_object(collection: Any, requested: str) -> Any
- _apply_dressing_overrides · function · L211-L225 — def _apply_dressing_overrides(collection: Any, overrides: dict[str, Any]) -> None
- build_set · function · L228-L249 — def build_set(ctx: BuildContext) -> Any | None
- link_path_asset · function · L252-L275 — def link_path_asset(ctx: BuildContext, asset_id: str) -> Any
