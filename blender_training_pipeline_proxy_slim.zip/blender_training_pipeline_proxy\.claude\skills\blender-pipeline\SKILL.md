---
name: blender-pipeline
description: Deterministic production Blender builder rules. Use when changing blend_build code, render settings, linked assets/overrides, NLA assembly, camera/light rigs, shape-key cues, compositor setup, or Blender-side validation. The builder consumes resolved JSON only and never uses the live MCP as its build path.
---

# Blender Production Builder

## Input contract
Read one fully resolved JSON config plus the admitted asset manifest. Do not import OmegaConf, TTS clients, Ollama, n8n, or orchestration dependencies inside Blender.

## Build rules
- start from `--factory-startup`;
- link source libraries, then create Library Overrides only where the shot requires local animation/pose state;
- compose named actions as NLA strips for character performance;
- raw keys are acceptable for blocking transforms, camera moves, viseme shape keys and deliberate procedural layers;
- set render/color/camera/light/compositor state from config;
- use fixed seeds when randomness exists;
- run Blender-side assertions before saving;
- write a generated `.blend` and build manifest only to generated paths.

## Blender 5.x
Consult `animating-basics` before reading/modifying Actions. Blender 5.x Actions are layered/slotted; do not assume legacy `action.fcurves`.

## MCP
The official Blender MCP exists for the `blender-debugger` on a scratch copy. It is not a substitute for builder code.
