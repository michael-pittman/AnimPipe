# src/blender_training_pipeline/qa_loop.py

- _prewarm_vlm · function · L18-L38 — def _prewarm_vlm(model: str, base_url: str = "http://127.0.0.1:11434") -> None
- mean_review_score · function · L41-L50 — def mean_review_score(review: VisualReview) -> float
- revision_decision · function · L53-L77 — def revision_decision( review: VisualReview, config: PipelineConfig, *, iteration: int, prior_score: float | None, ) -> tuple[str, str]
- _prior_score · function · L80-L85 — def _prior_score(path: Path | None) -> float | None
- review_iteration · function · L88-L141 — def review_iteration( *, preview: Path, intent: Path, resolved_config: Path, report: Path, candidate_config: Path | None = None, iteration: int = 0, prior_report: Path | None = None, hardware_manifest: Path = Path("reports/environment/hardware-verified.json"), ) -> dict[str, Any]
- run_loop · function · L144-L330 — def run_loop( *, resolved_config: Path, intent: Path, asset_manifest: Path, assets_root: Path, work_dir: Path, hardware_manifest: Path = Path("reports/environment/hardware-verified.json"), keep_frames: bool = False, ) -> dict[str, Any]
