from __future__ import annotations

from pathlib import PurePosixPath
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Coordinates(StrictModel):
    units: Literal["meters"] = "meters"
    up: Literal["Z"] = "Z"
    forward: str = "-Y"
    scale: float = Field(default=1.0, gt=0)


class RigContract(StrictModel):
    armature: str
    retarget_profile: str | None = None
    required_actions: list[str] = Field(default_factory=list)
    visemes: dict[str, str] = Field(default_factory=dict)
    facial_controls: list[str] = Field(default_factory=list)


class Complexity(StrictModel):
    triangles: int = Field(default=0, ge=0)
    texture_memory_estimate_mb: int = Field(default=0, ge=0)


class AssetEntry(StrictModel):
    kind: Literal[
        "character", "set", "prop", "material", "hdri", "audio", "font",
        "path", "lut", "overlay",
    ]
    version: str
    sha256: str
    blender_min: str = "5.2.1"
    file: str
    collection: str | None = None
    object: str | None = None
    coordinates: Coordinates = Field(default_factory=Coordinates)
    rig: RigContract | None = None
    complexity: Complexity = Field(default_factory=Complexity)
    source: str | None = None
    license: str | None = None
    style_id: str | None = None
    tags: list[str] = Field(default_factory=list)
    material_roles: list[str] = Field(default_factory=list)
    interaction_points: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_contract(self) -> AssetEntry:
        path = PurePosixPath(self.file.replace("\\", "/"))
        if path.is_absolute() or ".." in path.parts or not self.file.strip():
            raise ValueError("asset file must be a non-empty relative path beneath assets/")
        if self.kind in {"character", "set"} and not self.collection:
            raise ValueError(f"{self.kind} assets require collection")
        if self.kind == "character":
            if self.rig is None:
                raise ValueError("character assets require a rig contract")
            if not self.rig.retarget_profile:
                raise ValueError("character rig requires normalized retarget_profile")
        if self.kind == "path" and not (self.object or self.collection):
            raise ValueError("path assets require object or collection")
        if self.kind == "prop" and not (self.object or self.collection):
            raise ValueError("prop assets require object or collection")
        return self


class AssetManifest(StrictModel):
    assets: dict[str, AssetEntry]
