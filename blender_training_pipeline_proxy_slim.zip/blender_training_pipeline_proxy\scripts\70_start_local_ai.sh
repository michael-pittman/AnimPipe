#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
import json
from pathlib import Path
p=Path('reports/environment/hardware-verified.json')
if not p.exists() or json.loads(p.read_text()).get('status') != 'pass':
    raise SystemExit('verified T4 hardware manifest required before GPU service startup')
PY
if [[ ! -f infra/.env ]]; then cp infra/.env.example infra/.env; fi
if [[ ! -f infra/kokoro.env ]]; then
  key=$(openssl rand -hex 32)
  sed "s/replace-with-random-local-key/$key/" infra/kokoro.env.example > infra/kokoro.env
  chmod 600 infra/kokoro.env
fi
docker run --rm --gpus all ubuntu:24.04 nvidia-smi >/dev/null
docker compose --env-file infra/.env -f infra/docker-compose.yml pull
docker compose --env-file infra/.env -f infra/docker-compose.yml up -d
MODEL=$(grep '^QWEN_VISION_MODEL=' infra/.env | cut -d= -f2-)
docker exec anim-ollama ollama pull "$MODEL"
docker exec anim-ollama ollama stop "$MODEL" >/dev/null 2>&1 || true
bash scripts/lock_container_images.sh
