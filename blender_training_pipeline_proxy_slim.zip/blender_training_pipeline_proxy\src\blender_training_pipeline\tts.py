from __future__ import annotations

import os
from pathlib import Path

import httpx


def _env_file_api_key(path: Path = Path("infra/kokoro.env")) -> str | None:
    if not path.exists():
        return None
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("KOKORO_API_KEY="):
            return line.split("=", 1)[1].strip() or None
    return None


class KokoroClient:
    def __init__(self, base_url: str = "http://127.0.0.1:8880", api_key: str | None = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key or os.getenv("KOKORO_API_KEY") or _env_file_api_key()

    def synthesize(
        self,
        text: str,
        output: Path,
        *,
        voice: str = "af_heart",
        speed: float = 1.0,
        response_format: str = "wav",
        model: str = "tts-1",
    ) -> Path:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        payload = {
            "model": model, "input": text, "voice": voice,
            "speed": speed, "response_format": response_format,
        }
        output.parent.mkdir(parents=True, exist_ok=True)
        with httpx.Client(timeout=180.0) as client:
            response = client.post(f"{self.base_url}/v1/audio/speech", headers=headers, json=payload)
            response.raise_for_status()
            output.write_bytes(response.content)
        return output
