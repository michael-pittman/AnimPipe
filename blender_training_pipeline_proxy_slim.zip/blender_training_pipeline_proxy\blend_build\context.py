"""Shared helpers for the deterministic Blender builder.

Runs inside Blender's bundled Python. **No third-party imports** — Blender does
not ship pydantic or PyYAML, so the builder consumes the already-validated
resolved JSON produced host-side by ``pipe config compile`` and the JSON asset
manifest produced by ``pipe asset export-manifest``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Blender keyframe interpolation modes that accept an easing direction.
_EASED_INTERPOLATIONS = {
    "SINE", "QUAD", "CUBIC", "QUART", "QUINT", "EXPO", "CIRC", "BACK", "BOUNCE", "ELASTIC",
}
_PLAIN_INTERPOLATIONS = {"CONSTANT", "LINEAR", "BEZIER"}
_EASING_SUFFIX = {"in": "EASE_IN", "out": "EASE_OUT", "in_out": "EASE_IN_OUT"}


class BuildError(RuntimeError):
    """Raised when the build cannot proceed. Always names the config path at fault."""


def req(cfg: dict[str, Any], path: str) -> Any:
    """Fetch a dotted config path, raising a BuildError that names the missing key.

    The resolved config is schema-validated host-side, so a miss here means the
    builder and the schema have drifted — which is worth failing loudly on rather
    than defaulting silently.
    """
    node: Any = cfg
    walked: list[str] = []
    for part in path.split("."):
        walked.append(part)
        if not isinstance(node, dict) or part not in node:
            raise BuildError(
                f"resolved config is missing '{path}' "
                f"(stopped at '{'.'.join(walked)}')"
            )
        node = node[part]
    return node


def opt(cfg: dict[str, Any], path: str, default: Any = None) -> Any:
    try:
        return req(cfg, path)
    except BuildError:
        return default


def set_config(cfg: dict[str, Any]) -> dict[str, Any]:
    """``set`` is aliased to ``set_spec`` in the Pydantic model; accept either."""
    if "set" in cfg:
        return cfg["set"]
    return cfg.get("set_spec", {})


def parse_easing(name: str) -> tuple[str, str]:
    """Translate a config easing name into (interpolation, easing).

    ``"BEZIER"`` -> ``("BEZIER", "AUTO")``; ``"back_out"`` -> ``("BACK", "EASE_OUT")``;
    ``"quad_in_out"`` -> ``("QUAD", "EASE_IN_OUT")``. Easing is where generated motion
    stops looking generated, so an unrecognised name is an error rather than a
    silent fallback to linear.
    """
    token = (name or "BEZIER").strip().upper()
    if token in _PLAIN_INTERPOLATIONS:
        return token, "AUTO"
    if token in _EASED_INTERPOLATIONS:
        return token, "AUTO"

    lowered = (name or "").strip().lower()
    for suffix, easing in sorted(_EASING_SUFFIX.items(), key=lambda kv: -len(kv[0])):
        if lowered.endswith("_" + suffix):
            interp = lowered[: -(len(suffix) + 1)].upper()
            if interp in _EASED_INTERPOLATIONS:
                return interp, easing
            raise BuildError(f"unknown easing interpolation '{interp}' in '{name}'")
    raise BuildError(f"unrecognised easing '{name}'")


def srgb_to_linear(value: float) -> float:
    if value <= 0.04045:
        return value / 12.92
    return ((value + 0.055) / 1.055) ** 2.4


def kelvin_to_linear_rgb(kelvin: float) -> tuple[float, float, float]:
    """Planckian-locus approximation, returned in Blender's linear light space.

    Blender light data has no Kelvin field (blackbody lives in the shader graph),
    so colour temperature from config is converted here. Normalised so the
    brightest channel is 1.0 — energy stays the only intensity control.
    """
    temp = max(1000.0, min(40000.0, float(kelvin))) / 100.0

    if temp <= 66.0:
        red = 255.0
        green = 99.4708025861 * _ln(temp) - 161.1195681661
    else:
        red = 329.698727446 * ((temp - 60.0) ** -0.1332047592)
        green = 288.1221695283 * ((temp - 60.0) ** -0.0755148492)

    if temp >= 66.0:
        blue = 255.0
    elif temp <= 19.0:
        blue = 0.0
    else:
        blue = 138.5177312231 * _ln(temp - 10.0) - 305.0447927307

    channels = [max(0.0, min(255.0, c)) / 255.0 for c in (red, green, blue)]
    linear = [srgb_to_linear(c) for c in channels]
    peak = max(linear) or 1.0
    return (linear[0] / peak, linear[1] / peak, linear[2] / peak)


def _ln(value: float) -> float:
    import math

    return math.log(max(value, 1e-6))


@dataclass
class BuildContext:
    """Everything the builder modules share, plus the assertion log."""

    cfg: dict[str, Any]
    manifest: dict[str, Any]
    assets_root: Path
    assertions: list[dict[str, Any]] = field(default_factory=list)
    resolved: dict[str, Any] = field(default_factory=dict)

    def assert_that(self, check: str, passed: bool, evidence: str = "") -> bool:
        self.assertions.append({"check": check, "passed": bool(passed), "evidence": evidence})
        return bool(passed)

    def failures(self) -> list[dict[str, Any]]:
        return [a for a in self.assertions if not a["passed"]]

    def asset(self, asset_id: str) -> dict[str, Any]:
        assets = self.manifest.get("assets", {})
        if asset_id not in assets:
            raise BuildError(
                f"asset id '{asset_id}' is not in the manifest; "
                "configs reference logical IDs only — register it in assets.yaml"
            )
        return assets[asset_id]

    def asset_path(self, asset_id: str) -> Path:
        entry = self.asset(asset_id)
        root = self.assets_root.resolve()
        path = (root / entry["file"]).resolve()
        try:
            path.relative_to(root)
        except ValueError as exc:
            raise BuildError(f"asset '{asset_id}' escapes assets root: {entry['file']}") from exc
        if not path.exists():
            raise BuildError(f"asset '{asset_id}' file not found: {path}")
        return path

    @property
    def fps(self) -> int:
        return int(req(self.cfg, "render.fps"))
