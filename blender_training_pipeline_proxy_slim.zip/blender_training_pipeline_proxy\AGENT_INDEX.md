# Agent Index

| Agent | Primary responsibility | Preloaded skills | Live Blender MCP |
|---|---|---|---|
| `pipeline-architect` | schemas, contracts, ADRs | pipeline-contracts, repo-boundaries, patch-proposal-format, handoff-format | no |
| `environment-bootstrapper` | Azure/Linux/GPU/Blender/services | hardware-qualification, vm-bootstrap, repo-boundaries, handoff-format | no |
| `asset-factory` | deterministic proxy/reusable asset generation | proxy-asset-factory, asset-contract, animation-vocabulary, handoff-format | no |
| `asset-validator` | admission, rig/action/viseme contracts | asset-contract, pipeline-contracts, repo-boundaries, handoff-format | no |
| `animation-director` | director script, shot intent, performance vocabulary | instructional-design, director-script, animation-vocabulary, handoff-format | no |
| `blender-builder` | deterministic `bpy` implementation | blender-pipeline, animating-basics, pipeline-contracts, handoff-format | no |
| `audio-lipsync-engineer` | TTS, alignment, visemes | audio-lipsync, pipeline-contracts, repo-boundaries, handoff-format | no |
| `blender-debugger` | inspect scratch Blender, diagnose only | animating-basics, lighting-setups, patch-proposal-format, handoff-format | **yes** |
| `render-qa` | deterministic + VLM preview QA | perceptual-frame-review, preview-revision-loop, patch-proposal-format, handoff-format | no |
| `pipeline-runner` | execute gates/jobs/publish | pipeline-operations, gpu-scheduling, pipeline-contracts, handoff-format | no |

`animating-basics` and `lighting-setups` are project-boundary adaptations of selected skills from the supplied Blender-agent archive. Exact unmodified upstream copies are preserved under `vendor/blender-agent-upstream/skills/`. Skills that depend on custom `anim(...)`, `pose(...)`, or `rig(...)` MCP extensions are intentionally not active because this project standardizes on Blender Lab's official MCP surface.
