from __future__ import annotations

import json
from pathlib import Path

import pytest

from blend_build.context import (
    BuildContext,
    BuildError,
    kelvin_to_linear_rgb,
    parse_easing,
    req,
    set_config,
)


def _ctx(**overrides) -> BuildContext:
    manifest = {
        "assets": {
            "char.a": {
                "kind": "character",
                "file": "characters/a.blend",
                "collection": "CHAR_a",
                "complexity": {"texture_memory_estimate_mb": 400},
            }
        }
    }
    cfg = {"render": {"fps": 24}, "cast": [{"id": "char.a"}]}
    cfg.update(overrides)
    return BuildContext(cfg=cfg, manifest=manifest, assets_root=Path("assets"))


class TestEasing:
    def test_plain_interpolation_passes_through(self):
        assert parse_easing("BEZIER") == ("BEZIER", "AUTO")
        assert parse_easing("LINEAR") == ("LINEAR", "AUTO")

    def test_directional_easing_is_split(self):
        assert parse_easing("back_out") == ("BACK", "EASE_OUT")
        assert parse_easing("quad_in_out") == ("QUAD", "EASE_IN_OUT")
        assert parse_easing("elastic_in") == ("ELASTIC", "EASE_IN")

    def test_unknown_easing_raises_rather_than_defaulting(self):
        # Silently falling back to linear would turn a config typo into motion
        # that looks subtly wrong with nothing in the logs.
        with pytest.raises(BuildError):
            parse_easing("swoosh_out")
        with pytest.raises(BuildError):
            parse_easing("nonsense")


class TestColorTemperature:
    def test_normalised_to_unit_peak(self):
        for kelvin in (2000, 3200, 5600, 6500, 12000):
            rgb = kelvin_to_linear_rgb(kelvin)
            assert abs(max(rgb) - 1.0) < 1e-9
            assert all(0.0 <= c <= 1.0 for c in rgb)

    def test_warm_is_redder_than_cool(self):
        warm = kelvin_to_linear_rgb(2700)
        cool = kelvin_to_linear_rgb(8000)
        assert warm[2] < cool[2]
        assert warm[0] >= cool[0] - 1e-9


class TestConfigAccess:
    def test_missing_path_names_the_key(self):
        ctx = _ctx()
        with pytest.raises(BuildError) as excinfo:
            req(ctx.cfg, "camera.lens_mm")
        assert "camera.lens_mm" in str(excinfo.value)

    def test_set_alias_is_accepted_either_way(self):
        assert set_config({"set": {"environment_asset_id": "x"}})["environment_asset_id"] == "x"
        assert set_config({"set_spec": {"environment_asset_id": "y"}})["environment_asset_id"] == "y"
        assert set_config({}) == {}

    def test_unknown_asset_id_is_rejected(self):
        ctx = _ctx()
        with pytest.raises(BuildError) as excinfo:
            ctx.asset("char.missing")
        assert "char.missing" in str(excinfo.value)


class TestAssertions:
    def test_failures_are_collected_not_raised(self):
        ctx = _ctx()
        ctx.assert_that("ok check", True)
        ctx.assert_that("bad check", False, "evidence")
        assert len(ctx.assertions) == 2
        assert [a["check"] for a in ctx.failures()] == ["bad check"]


class TestPatchAllowList:
    def test_structural_paths_are_not_patchable_by_the_critic(self):
        from blender_training_pipeline.models import QaConfig

        prefixes = QaConfig().allowed_patch_prefixes
        # A 4B vision model must not be able to rewrite an action stack or move a
        # character; those route to animation-director as a proposal instead.
        assert "cast." not in prefixes
        assert "blocking." not in prefixes
        assert "render." not in prefixes
        assert "camera." in prefixes


class TestManifestExport:
    def test_yaml_manifest_exports_to_json(self, tmp_path: Path):
        from asset_system.doctor import export_manifest_json

        source = Path("assets/assets.yaml.example")
        target = tmp_path / "assets.resolved.json"
        export_manifest_json(source, target)

        data = json.loads(target.read_text(encoding="utf-8"))
        assert "char.instructor_a" in data["assets"]
        assert data["assets"]["char.instructor_a"]["rig"]["visemes"]["D"] == "viseme_D"

    def test_export_is_byte_stable(self, tmp_path: Path):
        from asset_system.doctor import export_manifest_json

        source = Path("assets/assets.yaml.example")
        first = export_manifest_json(source, tmp_path / "a.json").read_bytes()
        second = export_manifest_json(source, tmp_path / "b.json").read_bytes()
        assert first == second


class TestContactSheet:
    def test_tiles_frames_into_one_image(self, tmp_path: Path):
        from PIL import Image

        from blender_training_pipeline.delivery import contact_sheet

        frames = []
        for index in range(5):
            path = tmp_path / f"{index:04d}.png"
            Image.new("RGB", (320, 180), (index * 40, 10, 10)).save(path)
            frames.append(path)

        output = contact_sheet(frames=frames, output=tmp_path / "sheet.png", columns=3)
        sheet = Image.open(output)
        assert sheet.width == 640 * 3
        assert sheet.height > 0

    def test_empty_frame_list_is_an_error(self, tmp_path: Path):
        from blender_training_pipeline.delivery import DeliveryError, contact_sheet

        with pytest.raises(DeliveryError):
            contact_sheet(frames=[], output=tmp_path / "sheet.png")


class TestGpuLockStatePath:
    def test_state_path_follows_the_lock_path(self, tmp_path: Path, monkeypatch):
        from blender_training_pipeline import gpu_lock
        from blender_training_pipeline.hardware import GpuSnapshot

        snapshot = GpuSnapshot(0, "GPU-test", "Tesla T4", 15360, 15000, "999.00")
        monkeypatch.setattr(gpu_lock, "verify_live_identity", lambda _p: snapshot)
        # chdir to tmp_path so the default scratch/locks path doesn't collide with
        # pipeline runs that may have left state files in the project working directory.
        monkeypatch.chdir(tmp_path)

        lock_path = tmp_path / "custom.lock"
        with gpu_lock.gpu_lock("vision_qa", 1000, 512, 5, lock_path=lock_path):
            assert (tmp_path / "custom.json").exists()
            # The default location must stay untouched when a custom lock is used.
            assert not Path("scratch/locks/gpu.compute.json").exists()
        assert not (tmp_path / "custom.json").exists()
