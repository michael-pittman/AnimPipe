# tests/test_config_patch.py

- review · function · L13-L19 — def review(path: str) -> VisualReview
- test_allowlisted_patch_validates · function · L22-L25 — def test_allowlisted_patch_validates() -> None
- test_code_or_render_patch_is_blocked · function · L28-L31 — def test_code_or_render_patch_is_blocked() -> None
- test_style_patch_is_blocked · function · L34-L37 — def test_style_patch_is_blocked() -> None
