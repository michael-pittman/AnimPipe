# src/blender_training_pipeline/delivery.py

- _get_ffmpeg · function · L26-L27 — def _get_ffmpeg() -> str
- _get_blender · function · L30-L33 — def _get_blender(override: str | None = None) -> str
- DeliveryError · class · L36-L37 — class DeliveryError(RuntimeError)
- build_shot · function · L40-L66 — def build_shot( *, config: Path, manifest: Path, output: Path, assets_root: Path = Path("assets"), preview: bool = False, report: Path | None = None, blender: str = BLENDER, ) -> dict[str, Any]
- render_frames · function · L69-L86 — def render_frames( *, blend: Path, output_dir: Path, frames: list[int] | None = None, blender: str = BLENDER ) -> list[Path]
- _load_manifest · function · L89-L92 — def _load_manifest(path: Path) -> AssetManifest
- resolve_delivery_asset · function · L95-L110 — def resolve_delivery_asset( asset_id: str, *, manifest_path: Path, assets_root: Path, expected_kind: str ) -> Path
- _srt_time · function · L113-L118 — def _srt_time(frame: int, fps: int) -> str
- _caption_phrases · function · L121-L139 — def _caption_phrases(text: str, *, max_words: int = 4, max_chars: int = 24) -> list[str]
- _caption_display_text · function · L142-L148 — def _caption_display_text(text: str, *, line_width: int = 20) -> str
- write_dialogue_srt · function · L151-L183 — def write_dialogue_srt(dialogue: list[dict[str, Any]], *, fps: int, output: Path) -> Path
- _ffmpeg_filter_path · function · L186-L188 — def _ffmpeg_filter_path(path: Path) -> str: # libavfilter paths use ':' and quote as syntax; asset manifests already prohibit traversal.
- encode · function · L191-L319 — def encode( *, frames_dir: Path, output: Path, fps: int, frame_start: int = 0, codec: str = "h264_nvenc", cq: int = 20, audio: Path | None = None, audio_codec: str = "aac", metadata: dict[str, str] | None = None, pattern: str = "%04d.png", comp: dict[str, Any] | None = None, dialogue: list[dict[str, Any]] | None = None, asset_manifest: Path | None = None, assets_root: Path = Path("assets"), ) -> Path
- nvenc_available · function · L322-L351 — def nvenc_available() -> bool
- contact_sheet · function · L354-L381 — def contact_sheet( *, frames: list[Path], output: Path, columns: int = 3, thumb_width: int = 640, labels: list[str] | None = None, ) -> Path
- sample_video_frames · function · L384-L400 — def sample_video_frames(*, video: Path, frames: list[int], output_dir: Path) -> list[Path]
