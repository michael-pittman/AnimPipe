---
name: instructional-design
description: Applies learning-science principles — segmenting, cognitive load management, dual coding, signaling, and pacing — when turning training content into a shot list, script, or scene config. Use this whenever you are writing or revising narration, deciding how long a beat should run, choosing what to show on screen versus say aloud, sequencing a module, or judging whether an animation helps or distracts. Consult it before the cinematography choices, since a technically beautiful shot that violates cognitive load principles still teaches badly.
---

# Instructional Design for Animated Training

This is training content. The measure is whether someone can do the thing afterward, not
whether the shot looks good. These principles are where most of that outcome is decided,
and they constrain the creative choices that come later.

## Start from the objective, not the story

Every module opens with a stated behavioral objective: *after this, the learner can
<verb> <object> <under what conditions>*. Use observable verbs — identify, calculate,
configure, escalate. Not "understand," not "be aware of."

Every shot must trace to an objective. If a shot serves no objective, cut it. Charming
material that doesn't serve an objective is the most expensive thing in the pipeline —
it costs render time and learner attention and returns nothing.

## Segmenting

Learners retain more when they control the pace and the material arrives in discrete
chunks.

- **One idea per segment.** A segment is 20–90 seconds. If a segment needs more than 90
  seconds, it contains two ideas.
- **Hard boundaries between segments** — a beat of silence, a visual reset, a title card.
  The boundary is what signals "that idea is complete, file it."
- **4–7 segments per module.** Beyond that, split the module.
- Mark boundaries in config as `beat_*` markers so downstream steps can build chapter
  points and the learner can replay a single idea.

## Cognitive load

Working memory is the binding constraint. Three loads compete for it:

- **Intrinsic** — the difficulty of the material. Manage by sequencing simple-to-complex,
  not by dumbing down.
- **Extraneous** — everything that costs attention without teaching. This is what you
  control most directly, and it is where animation most often does harm.
- **Germane** — effort that builds the mental model. This is the good kind; protect room
  for it by cutting extraneous load.

Concrete rules that follow:

- **Never narrate and display dense text simultaneously.** The learner cannot read and
  listen at once. Either the text is a short label the narration expands, or the narration
  pauses while they read.
- **No decorative motion during explanation.** Background animation, drifting cameras, and
  idle character business during a difficult point are pure extraneous load. Hold still
  when the idea is hard.
- **Remove before you add.** If a diagram needs a new element, ask what can leave.

## Dual coding — words plus pictures, not words plus words

Spoken narration paired with a relevant visual beats either alone. Spoken narration paired
with the *same words on screen* is worse than narration alone.

- Narrate the process; show the thing.
- On-screen text is for labels, numbers, and terms the learner must recognize later — not
  for sentences.
- If a term has a precise spelling the learner needs, show it once, briefly, while the
  narration says it.

## Signaling

Direct attention explicitly rather than trusting the learner to find the right part of the
frame.

- Highlight, outline, dim-the-rest, or a character's pointing gesture — one signal at a
  time.
- Signal slightly **before** the narration reaches it, by roughly 6–10 frames at 24fps.
  Attention needs to arrive before the word does.
- Camera moves are signals too. A push-in says "this matters." Don't spend one on
  something that doesn't.

## Pacing and narration

- Target 130–150 words per minute for instructional narration. Faster reads as rushed and
  measurably hurts retention on unfamiliar material.
- **Pause after each new term or number** — a full second. This is where the learner
  encodes it, and it is the single cheapest retention gain available.
- Write for the ear: short sentences, active voice, second person, concrete nouns. Read
  every line aloud before committing it.
- Never let narration explain something the visual is contradicting or lagging behind.
  Sync is a comprehension issue, not a polish issue.

## When not to animate

Animation earns its cost when it shows **change over time**, **spatial relationships**, or
**procedure**. For everything else it is decoration.

- A definition is a title card.
- A comparison is a static side-by-side, held.
- A list is a list.
- A process, a mechanism, a physical arrangement, a sequence of actions — animate that.

Say so in `notes` when a beat would be better served by a held frame. Recommending less
animation is a legitimate and valuable output from this role.

## Structure of a module

```
1. Objective stated plainly           (~10s)
2. Why it matters / the failure case  (~20s)
3. Segments, simple → complex         (4–7 × 20–90s)
4. Worked example end to end          (~60s)
5. Recap against the objective        (~15s)
```

The recap restates the objective and nothing new. If something appears in the recap that
wasn't taught, a segment is missing.

## Accessibility is not optional

- Every line of narration has a caption. Captions are content, not an afterthought — they
  must match the delivered audio exactly, which means generating them from the aligned
  audio rather than the draft script.
- Never carry meaning by color alone.
- Anything essential on screen must survive at mobile size. Check the contact sheet.
- Keep contrast within WCAG AA for on-screen text.

## What to hand off

Shot YAML plus a short rationale in `notes` linking each segment to its objective. If you
cut, merged, or held a shot for instructional reasons, say why — the next agent has no way
to infer it, and reviewers will otherwise "fix" it back.
