#!/usr/bin/env python3
"""Generate deterministic Proxy Animation Kit .blend assets from validated JSON.

Run only through the host `pipe proxy generate` command. This script deliberately
uses Blender stdlib + bpy only; creative values come from the validated proxy kit
spec rather than being buried in builder code.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any

import bpy
from mathutils import Vector


def args() -> argparse.Namespace:
    raw = sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []
    p = argparse.ArgumentParser()
    p.add_argument("--spec", required=True)
    p.add_argument("--output-root", required=True)
    p.add_argument("--report", required=True)
    return p.parse_args(raw)


def clear_all() -> None:
    for obj in list(bpy.data.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    for collection in list(bpy.data.collections):
        bpy.data.collections.remove(collection)
    for datablocks in (
        bpy.data.curves, bpy.data.armatures, bpy.data.meshes, bpy.data.actions,
        bpy.data.materials, bpy.data.cameras, bpy.data.lights,
    ):
        for block in list(datablocks):
            datablocks.remove(block)


def make_collection(name: str) -> Any:
    col = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(col)
    return col


def move_to(obj: Any, collection: Any) -> None:
    for old in list(obj.users_collection):
        old.objects.unlink(obj)
    collection.objects.link(obj)


def material(role: str, style: dict[str, Any]) -> Any:
    name = f"MAT_PROXY_{role.upper()}"
    existing = bpy.data.materials.get(name)
    if existing is not None:
        return existing
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = next((n for n in mat.node_tree.nodes if n.bl_idname == "ShaderNodeBsdfPrincipled"), None)
    if bsdf is None:
        raise RuntimeError("Principled BSDF unavailable")
    rgba = style["palette"][role]
    bsdf.inputs["Base Color"].default_value = tuple(float(v) for v in rgba)
    bsdf.inputs["Roughness"].default_value = float(style["shading"]["roughness"])
    bsdf.inputs["Metallic"].default_value = float(style["shading"]["metallic"])
    return mat


def cube(name: str, location: tuple[float, float, float], dimensions: tuple[float, float, float], mat: Any, collection: Any) -> Any:
    bpy.ops.mesh.primitive_cube_add(location=location)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = dimensions
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.data.materials.append(mat)
    move_to(obj, collection)
    return obj


def sphere(name: str, location: tuple[float, float, float], radius: float, mat: Any, collection: Any) -> Any:
    bpy.ops.mesh.primitive_uv_sphere_add(segments=20, ring_count=12, radius=radius, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.data.materials.append(mat)
    move_to(obj, collection)
    return obj


def cylinder_between(name: str, start: tuple[float, float, float], end: tuple[float, float, float], radius: float, mat: Any, collection: Any) -> Any:
    a, b = Vector(start), Vector(end)
    vec = b - a
    mid = (a + b) * 0.5
    bpy.ops.mesh.primitive_cylinder_add(vertices=16, radius=radius, depth=max(vec.length, 0.001), location=mid)
    obj = bpy.context.object
    obj.name = name
    obj.rotation_mode = "QUATERNION"
    obj.rotation_quaternion = vec.to_track_quat("Z", "Y")
    obj.rotation_mode = "XYZ"
    obj.data.materials.append(mat)
    move_to(obj, collection)
    return obj


def parent_to_bone(obj: Any, arm: Any, bone: str) -> None:
    world = obj.matrix_world.copy()
    obj.parent = arm
    obj.parent_type = "BONE"
    obj.parent_bone = bone
    obj.matrix_world = world


def make_armature(character: dict[str, Any], collection: Any) -> tuple[Any, dict[str, tuple[tuple[float, float, float], tuple[float, float, float]]]]:
    h = float(character["geometry"]["height_m"])
    x_shoulder = float(character["geometry"]["torso_width_m"]) * 0.58
    bones = {
        "root": ((0, 0, 0.05*h), (0, 0, 0.18*h)),
        "pelvis": ((0, 0, 0.38*h), (0, 0, 0.50*h)),
        "spine": ((0, 0, 0.50*h), (0, 0, 0.64*h)),
        "chest": ((0, 0, 0.64*h), (0, 0, 0.76*h)),
        "neck": ((0, 0, 0.76*h), (0, 0, 0.84*h)),
        "head": ((0, 0, 0.84*h), (0, 0, 0.98*h)),
        "upper_arm.L": ((-x_shoulder, 0, 0.73*h), (-0.29*h, 0, 0.63*h)),
        "forearm.L": ((-0.29*h, 0, 0.63*h), (-0.43*h, 0, 0.54*h)),
        "hand.L": ((-0.43*h, 0, 0.54*h), (-0.50*h, 0, 0.51*h)),
        "upper_arm.R": ((x_shoulder, 0, 0.73*h), (0.29*h, 0, 0.63*h)),
        "forearm.R": ((0.29*h, 0, 0.63*h), (0.43*h, 0, 0.54*h)),
        "hand.R": ((0.43*h, 0, 0.54*h), (0.50*h, 0, 0.51*h)),
        "thigh.L": ((-0.11*h, 0, 0.42*h), (-0.12*h, 0, 0.23*h)),
        "shin.L": ((-0.12*h, 0, 0.23*h), (-0.12*h, 0, 0.055*h)),
        "foot.L": ((-0.12*h, 0, 0.055*h), (-0.12*h, -0.12*h, 0.035*h)),
        "thigh.R": ((0.11*h, 0, 0.42*h), (0.12*h, 0, 0.23*h)),
        "shin.R": ((0.12*h, 0, 0.23*h), (0.12*h, 0, 0.055*h)),
        "foot.R": ((0.12*h, 0, 0.055*h), (0.12*h, -0.12*h, 0.035*h)),
    }
    data = bpy.data.armatures.new(character["armature"] + "_DATA")
    arm = bpy.data.objects.new(character["armature"], data)
    collection.objects.link(arm)
    bpy.context.view_layer.objects.active = arm
    arm.select_set(True)
    bpy.ops.object.mode_set(mode="EDIT")
    created = {}
    for name, (head, tail) in bones.items():
        b = data.edit_bones.new(name)
        b.head, b.tail = head, tail
        created[name] = b
    for child, parent in {
        "pelvis":"root", "spine":"pelvis", "chest":"spine", "neck":"chest", "head":"neck",
        "upper_arm.L":"chest", "forearm.L":"upper_arm.L", "hand.L":"forearm.L",
        "upper_arm.R":"chest", "forearm.R":"upper_arm.R", "hand.R":"forearm.R",
        "thigh.L":"pelvis", "shin.L":"thigh.L", "foot.L":"shin.L",
        "thigh.R":"pelvis", "shin.R":"thigh.R", "foot.R":"shin.R",
    }.items():
        created[child].parent = created[parent]
    bpy.ops.object.mode_set(mode="POSE")
    for pbone in arm.pose.bones:
        pbone.rotation_mode = "XYZ"
    bpy.ops.object.mode_set(mode="OBJECT")
    arm.select_set(False)
    return arm, bones


def add_shape_keys(face: Any, names: list[str]) -> None:
    face.shape_key_add(name="Basis")
    for idx, name in enumerate(names):
        key = face.shape_key_add(name=name, from_mix=False)
        # Deterministic, deliberately exaggerated proxy deformations. They are
        # visual test signals, not intended to be anatomical facial animation.
        phase = (idx % 5) - 2
        for point in key.data:
            if name.startswith("VISEME_"):
                point.co.x *= 1.0 + 0.04 * phase
                point.co.z *= 1.0 - 0.05 * phase
            elif name == "BLINK":
                point.co.z *= 0.70
            elif name == "EXP_smile":
                point.co.x *= 1.10
                point.co.z += abs(point.co.x) * 0.10
            elif name == "EXP_frown":
                point.co.x *= 0.94
                point.co.z -= abs(point.co.x) * 0.08
            elif name == "EXP_surprise":
                point.co.z *= 1.30
            elif name == "BROW_UP":
                point.co.z += 0.035
            elif name == "BROW_DOWN":
                point.co.z -= 0.035
            elif name == "LOOK_LEFT":
                point.co.x -= 0.025
            elif name == "LOOK_RIGHT":
                point.co.x += 0.025


def reset_pose(arm: Any) -> None:
    for p in arm.pose.bones:
        p.location = (0.0, 0.0, 0.0)
        p.rotation_euler = (0.0, 0.0, 0.0)
        p.scale = (1.0, 1.0, 1.0)


def make_action(arm: Any, spec: dict[str, Any]) -> Any:
    name = str(spec["name"])
    duration = int(spec["duration_frames"])
    action = bpy.data.actions.new(name)
    action.use_fake_user = True
    # Blender 4.4+ slotted actions: create the target slot explicitly, then
    # ordinary keyframe_insert() populates the channel bag for this armature.
    if hasattr(action, "slots"):
        slot = action.slots.new(id_type="OBJECT", name=arm.name)
    else:
        slot = None
    anim = arm.animation_data_create()
    anim.action = action
    if slot is not None and hasattr(anim, "action_slot"):
        anim.action_slot = slot
    reset_pose(arm)

    def rot(bone: str, frame: int, xyz_deg: tuple[float, float, float]) -> None:
        p = arm.pose.bones[bone]
        p.rotation_euler = tuple(math.radians(v) for v in xyz_deg)
        p.keyframe_insert(data_path="rotation_euler", frame=frame)

    mid = max(1, round(duration / 2))
    last = max(1, duration)
    # Proxy actions intentionally overstate motion so automated visual QA can
    # distinguish a failed strip from a successful strip at low resolution.
    if name == "idle_neutral_loop":
        rot("chest", 1, (0, 0, -2))
        rot("chest", mid, (0, 0, 2))
        rot("chest", last, (0, 0, -2))
        rot("head", 1, (0, -2, 0))
        rot("head", mid, (0, 2, 0))
        rot("head", last, (0, -2, 0))
    elif name == "walk_cycle":
        for frame, sign in ((1, 1), (mid, -1), (last, 1)):
            rot("thigh.L", frame, (24 * sign, 0, 0))
            rot("thigh.R", frame, (-24 * sign, 0, 0))
            rot("upper_arm.L", frame, (-18 * sign, 0, 0))
            rot("upper_arm.R", frame, (18 * sign, 0, 0))
    elif name in {"turn_left_90", "turn_right_90"}:
        sign = 1 if "left" in name else -1
        rot("root", 1, (0, 0, 0))
        rot("root", last, (0, 0, 90 * sign))
    elif name == "gesture_present":
        rot("upper_arm.R", 1, (0, 0, 0))
        rot("upper_arm.R", mid, (-15, -15, -55))
        rot("upper_arm.R", last, (0, 0, 0))
        rot("forearm.R", mid, (0, -10, -35))
    elif name in {"point_left", "point_right"}:
        side = "L" if "left" in name else "R"
        sign = 1 if side == "L" else -1
        rot(f"upper_arm.{side}", 1, (0, 0, 0))
        rot(f"upper_arm.{side}", mid, (0, -10, 75 * sign))
        rot(f"upper_arm.{side}", last, (0, 0, 0))
        rot(f"forearm.{side}", mid, (0, 0, 25*sign))
    elif name == "wave":
        rot("upper_arm.R", 1, (0, 0, -65))
        rot("forearm.R", 1, (0, 0, -60))
        rot("forearm.R", mid, (0, 0, -25))
        rot("forearm.R", last, (0, 0, -60))
    elif name == "head_nod":
        rot("head", 1, (0, 0, 0))
        rot("head", mid, (18, 0, 0))
        rot("head", last, (0, 0, 0))
    elif name == "head_shake":
        rot("head", 1, (0, 0, -12))
        rot("head", mid, (0, 0, 12))
        rot("head", last, (0, 0, -12))
    elif name == "reach_grab":
        rot("upper_arm.R", 1, (0, 0, 0))
        rot("upper_arm.R", last, (-15, -15, -65))
        rot("forearm.R", last, (0, 20, -45))
    elif name == "place_release":
        rot("upper_arm.R", 1, (-15, -15, -65))
        rot("forearm.R", 1, (0, 20, -45))
        rot("upper_arm.R", last, (10, -5, -35))
        rot("forearm.R", last, (0, 5, -20))
    elif name.startswith("pose_"):
        poses = {
            "pose_neutral": ((0,0,0),(0,0,0)),
            "pose_present": ((-10,-10,-45),(0,-10,-30)),
            "pose_listen": ((0,0,-8),(0,0,0)),
            "pose_think": ((-8,-10,-35),(0,-15,-55)),
            "pose_point": ((0,-10,-70),(0,0,-25)),
            "pose_hold": ((-12,-12,-45),(0,10,-55)),
            "pose_ready": ((-5,0,-15),(0,0,-15)),
            "pose_end": ((0,0,-35),(0,0,-25)),
        }
        a, f = poses.get(name, ((0,0,0),(0,0,0)))
        # Two identical keys give NLA a non-zero source range while remaining a held pose.
        rot("upper_arm.R", 1, a)
        rot("forearm.R", 1, f)
        rot("upper_arm.R", 2, a)
        rot("forearm.R", 2, f)
    else:
        rot("chest", 1, (0, 0, 0))
        rot("chest", last, (0, 0, 0))

    if hasattr(action, "asset_mark") and spec.get("category") == "pose":
        action.asset_mark()
    anim.action = None
    return action


def generate_character(spec: dict[str, Any], out: Path) -> dict[str, Any]:
    clear_all()
    style = spec["style"]
    char = spec["character"]
    col = make_collection(char["collection"])
    mchar = material("character", style)
    mfocus = material("focus", style)
    arm, bones = make_armature(char, col)
    g = char["geometry"]
    h = float(g["height_m"])
    r = float(g["limb_radius_m"])

    torso = cube(
        "BODY_torso",
        (0, 0, 0.62 * h),
        (g["torso_width_m"], g["torso_depth_m"], g["torso_height_m"]),
        mchar,
        col,
    )
    parent_to_bone(torso, arm, "chest")
    head = sphere(
        "BODY_head",
        (0, 0, 0.89 * h),
        float(g["head_radius_m"]),
        mchar,
        col,
    )
    parent_to_bone(head, arm, "head")
    for bone in ("upper_arm.L","forearm.L","upper_arm.R","forearm.R","thigh.L","shin.L","thigh.R","shin.R"):
        obj = cylinder_between("BODY_" + bone, *bones[bone], r, mchar, col)
        parent_to_bone(obj, arm, bone)
    for bone in ("hand.L","hand.R"):
        center = Vector(bones[bone][1])
        obj = sphere("BODY_" + bone, tuple(center), float(g["hand_radius_m"]), mchar, col)
        parent_to_bone(obj, arm, bone)
    foot_dims=tuple(g["foot_dimensions_m"])
    for side in ("L","R"):
        center = Vector(bones[f"foot.{side}"][1])
        obj = cube("BODY_foot." + side, tuple(center), foot_dims, mchar, col)
        parent_to_bone(obj, arm, f"foot.{side}")

    eye_z = 0.91 * h
    eye_x = float(g["head_radius_m"]) * 0.42
    face_y = -float(g["head_radius_m"]) * 0.90
    for side, x in (("L",-eye_x),("R",eye_x)):
        eye = sphere("FACE_eye." + side, (x, face_y, eye_z), float(g["head_radius_m"]) * 0.12, mfocus, col)
        parent_to_bone(eye, arm, "head")
    mouth = cube(
        "FACE_controls",
        (0, face_y - 0.005, 0.85 * h),
        (float(g["head_radius_m"]) * 0.85, 0.025, float(g["head_radius_m"]) * 0.30),
        mfocus,
        col,
    )
    parent_to_bone(mouth, arm, "head")
    mouth.hide_render = True  # control mesh; never rendered directly
    add_shape_keys(mouth, list(char["visemes"].values()) + list(char["expressions"]))

    for action in char["actions"]:
        make_action(arm, action)
    reset_pose(arm)
    out.parent.mkdir(parents=True, exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(out))
    return {"file": str(out), "collection": char["collection"], "armature": char["armature"], "actions": [a["name"] for a in char["actions"]]}


def generate_set(spec: dict[str, Any], out: Path) -> dict[str, Any]:
    clear_all()
    style = spec["style"]
    set_spec = spec["set"]
    col = make_collection(set_spec["collection"])
    for item in set_spec["elements"]:
        mat=material(item["material_role"],style)
        loc = tuple(item["location"])
        dims = tuple(item["dimensions"])
        if item["primitive"] == "cylinder":
            bpy.ops.mesh.primitive_cylinder_add(vertices=20, radius=0.5, depth=1.0, location=loc)
            obj = bpy.context.object
            obj.name = item["name"]
            obj.dimensions = dims
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            obj.data.materials.append(mat)
            move_to(obj, col)
        else:
            cube(item["name"],loc,dims,mat,col)
    out.parent.mkdir(parents=True, exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(out))
    return {"file":str(out),"collection":set_spec["collection"],"objects":[i["name"] for i in set_spec["elements"]]}


def generate_props(spec: dict[str, Any], out: Path) -> dict[str, Any]:
    clear_all()
    style = spec["style"]
    generated = []
    for item in spec["props"]:
        col = make_collection(item["collection"])
        mat = material(item["material_role"], style)
        dims = tuple(item["dimensions"])
        kind=item["primitive"]
        if kind in {"cylinder","pointer"}:
            bpy.ops.mesh.primitive_cylinder_add(vertices=20, radius=0.5, depth=1.0, location=(0,0,0))
            obj = bpy.context.object
            obj.dimensions = dims
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        else:
            bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
            obj = bpy.context.object
            obj.dimensions = dims
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        obj.name = "ROOT_" + item["id"].split(".")[-1].upper()
        obj.data.materials.append(mat)
        move_to(obj, col)
        generated.append({"id":item["id"],"collection":item["collection"],"root":obj.name})
    out.parent.mkdir(parents=True, exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(out))
    return {"file":str(out),"props":generated}


def generate_paths(spec: dict[str, Any], out: Path) -> dict[str, Any]:
    clear_all()
    generated = []
    for item in spec["paths"]:
        curve = bpy.data.curves.new(item["object"] + "_DATA", type="CURVE")
        curve.dimensions = "3D"
        curve.resolution_u = 12
        spline = curve.splines.new("BEZIER")
        spline.bezier_points.add(len(item["points"]) - 1)
        for point,co in zip(spline.bezier_points,item["points"]):
            point.co = tuple(co)
            point.handle_left_type = "AUTO"
            point.handle_right_type = "AUTO"
        obj = bpy.data.objects.new(item["object"], curve)
        bpy.context.scene.collection.objects.link(obj)
        generated.append(item["object"])
    out.parent.mkdir(parents=True, exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(out))
    return {"file":str(out),"paths":generated}


def main() -> None:
    ns = args()
    spec = json.loads(Path(ns.spec).read_text(encoding="utf-8"))
    root = Path(ns.output_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    report={"blender_version":bpy.app.version_string,"generated":{}}
    try:
        report["generated"]["character"]=generate_character(spec,root/"proxy_character.blend")
        report["generated"]["set"]=generate_set(spec,root/"proxy_environment.blend")
        report["generated"]["props"]=generate_props(spec,root/"proxy_props.blend")
        report["generated"]["paths"]=generate_paths(spec,root/"proxy_paths.blend")
        report["status"]="ok"
    except Exception as exc:
        import traceback
        report.update({"status":"blocked","error":str(exc),"traceback":traceback.format_exc()})
    Path(ns.report).parent.mkdir(parents=True, exist_ok=True)
    Path(ns.report).write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if report["status"] != "ok": raise SystemExit(2)


if __name__ == "__main__":
    main()
