# Claude Code Project Instructions — Blender Training Video Pipeline

## Mission
Build short instructional animations deterministically from validated configuration. The source of truth is text config + admitted assets + code. `.blend`, renders, audio cues, and videos are generated artifacts.

## Non-negotiable invariants

1. Use **OmegaConf**, not Hydra, for initial config layering: `base < project < scene < shot < CLI`.
2. Validate the fully resolved object with **Pydantic v2**, then emit immutable `resolved_config.json` plus a SHA-256 hash.
3. Production Blender receives resolved JSON only. Do not import OmegaConf, TTS, Ollama, or orchestration libraries into Blender's embedded Python.
4. No magic production values in builder code. Values come from the resolved config or asset contract.
5. Assets are referenced only by logical IDs from `assets/assets.yaml`.
6. Character performance composes named NLA actions; do not author bespoke raw performance keyframes when a vocabulary action exists.
6a. Proxy/future generated assets follow a style contract and asset spec. Generated `.blend` files are rebuildable outputs, never the editable source of truth.
6b. `FACE_controls` mesh must always have `hide_render=True`. The proxy character generator (`scripts/100_generate_proxy_kit_blender.py`) sets this; if you regenerate assets verify it's set. A missing `hide_render=True` makes the 953m control mesh render as a white billboard.
6c. Shape keys in the proxy character must use `from_mix=False`. Using the default `from_mix=True` accumulates coordinate offsets across sequential `shape_key_add()` calls, causing exponential mesh growth.
7. The official Blender MCP is **inspection/debug only**. It must operate on a scratch copy, never the canonical repo build artifact.
8. Do not use MCP-generated scene mutations as deliverables. Diagnose, propose a patch, then modify config/builder code and rebuild.
9. Never assume the GPU. Before GPU work, require `reports/environment/hardware-verified.json` and confirm the live GPU UUID still matches it. **Azure reassigns the GPU UUID on every VM restart** — always run `uv run pipe hardware refresh-uuid` as the first step after any VM restart or resume before running any pipeline commands.
10. Acquire the host GPU lock before Cycles/OptiX, Ollama VLM inference, GPU faster-whisper, or optional GPU TTS.
11. There is **no host CUDA Toolkit dependency**. Do not install `cuda-toolkit`, `nvidia-cuda-toolkit`, or `nvcc`. Driver/runtime libraries inside a container or Python wheel are acceptable when required by that workload.
12. Render final output to EXR/PNG image sequences, never directly to video. FFmpeg/NVENC performs mux/encode.
13. Every QA revision is a **config-only proposal**. A vision model must never patch `bpy` builder code.
14. Cap automated preview-revise iterations; default policy is in config.
15. Use structured handoffs and preserve provenance hashes.

## Runtime boundaries

- Host pipeline: Python 3.11
- `bpy` integration test env: Python 3.13 + `bpy==5.2.1`
- Production Blender: Blender 5.2.1 embedded Python 3.13
- Local visual QA: Ollama (no Docker needed on Azure T4), model `qwen2.5vl:3b` loaded via `ollama create` from GGUF (Cloudflare R2 blocks direct pull)
- TTS: Kokoro on port 8880 via `PYTHONPATH=infra .venv/Scripts/uvicorn kokoro_server:app --port 8880`

## VLM QA constraints (qwen2.5vl:3b on T4)

- **Image size cap**: Contact sheets at 1920px+ wide cause degenerate `@@@` output from the vision encoder overflowing the token context. `vision_review.py` auto-resizes to ≤960px wide before encoding.
- **Post-render crash loop**: After a Blender Cycles/OptiX render session exits, Ollama's llama-server enters a crash/restart loop (~35 s). `/api/tags` returns 200 during this window — only a real test inference proves recovery. `_wait_ollama_healthy()` polls with a real inference call before proceeding.
- **Output cap**: Set `num_predict: 2048` + brevity instruction to prevent JSON truncation. Without this, the model generates 38K+ chars of verbose output mid-string.
- **Keep-alive**: Use `keep_alive: -1` in inference calls so the model stays loaded across shots. Never use `keep_alive: 0` during a multi-shot pipeline run — reload triggers the crash loop.
- **Pre-warm**: `qa_loop.py` calls `_prewarm_vlm()` before each render to ensure the model is loaded before Blender starts, avoiding the reload-crash timing issue.

## Agent routing

- architecture/schema: `pipeline-architect`
- VM/bootstrap/hardware: `environment-bootstrapper`
- asset creation/regeneration: `asset-factory`
- asset admission: `asset-validator`
- instructional/creative config: `animation-director`
- deterministic bpy code: `blender-builder`
- speech/visemes: `audio-lipsync-engineer`
- live Blender diagnosis: `blender-debugger`
- render/semantic QA: `render-qa`
- safe execution/publishing: `pipeline-runner`

Do not load every skill into every agent. Each agent is intentionally scoped to a small set of skills.
