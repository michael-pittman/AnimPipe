---
name: gpu-scheduling
description: Single-T4 scheduling and VRAM admission policy. Use before Cycles/OptiX, Ollama vision QA, GPU faster-whisper, or optional GPU TTS. Requires verified hardware identity, a fresh nvidia-smi check, the OS GPU lock, and configured VRAM estimate/reserve; never run competing compute workloads opportunistically.
---

# GPU Scheduling

The first implementation serializes T4 compute workloads on purpose.

## Required sequence

```text
verified hardware manifest
  -> fresh UUID/model/VRAM check
  -> OS flock acquisition
  -> optional stale-model unload
  -> VRAM admission check
  -> workload
  -> provenance record
  -> release lock
```

Use `python -m blender_training_pipeline.gpu_lock run ...` rather than creating your own lock files.

## Workload classes
- `cycles`
- `vision_qa`
- `whisper_gpu`
- `tts_gpu`
- `nvenc` (serialized initially; may be split later after measurement)

Estimated peak memory and reserve are config values. Hardware identity is not.

Ollama VLM calls must use `keep_alive=0`, then confirm VRAM is released before starting Cycles when that matters.
