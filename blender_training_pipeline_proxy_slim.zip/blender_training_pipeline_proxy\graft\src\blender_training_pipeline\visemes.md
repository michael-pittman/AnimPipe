# src/blender_training_pipeline/visemes.py

- _find_rhubarb · function · L9-L24 — def _find_rhubarb() -> str: # Prefer PATH; fall back to vendor bundle (Windows / dev environments)
- rhubarb_cues · function · L27-L35 — def rhubarb_cues(wav: Path, output_json: Path, transcript: Path | None = None) -> dict
