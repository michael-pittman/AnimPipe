"""Blender 5.2 scene setup and pre-save validation."""

from __future__ import annotations

from typing import Any

import bpy

from .context import BuildContext, BuildError, opt, req


def apply_scene(ctx: BuildContext, preview: bool = False) -> None:
    cfg = ctx.cfg
    scene = bpy.context.scene
    render = req(cfg, "render")

    scene.render.engine = render["engine"]
    scene.render.resolution_x = int(render["resolution"]["width"])
    scene.render.resolution_y = int(render["resolution"]["height"])
    scene.render.fps = int(render["fps"])
    scene.frame_start = int(render["frame_start"])
    scene.frame_end = int(render["frame_end"])
    scene.render.use_simplify = bool(render["simplify"])

    scene.view_settings.view_transform = render["view_transform"]
    scene.view_settings.look = render["look"]
    # Blender 5.x requires media_type to be selected before file_format.
    scene.render.image_settings.media_type = "IMAGE"
    scene.render.image_settings.file_format = opt(cfg, "output.image_format", "PNG")

    samples = int(render["samples"])
    percentage = int(render["resolution"]["percentage"])
    if preview:
        samples = int(opt(cfg, "preview.samples", 16))
        percentage = int(opt(cfg, "preview.resolution_percentage", 25))
        override = opt(cfg, "preview.engine_override")
        if override:
            scene.render.engine = override
    scene.render.resolution_percentage = percentage

    if scene.render.engine == "CYCLES":
        _configure_cycles(scene, render, samples)
    elif scene.render.engine == "BLENDER_EEVEE":
        scene.eevee.taa_render_samples = samples

    ctx.assert_that(
        "scene configured",
        True,
        f"{scene.render.engine} {scene.render.resolution_x}x{scene.render.resolution_y}"
        f"@{percentage}% frames {scene.frame_start}-{scene.frame_end}"
        + (" [preview]" if preview else ""),
    )


def _configure_cycles(scene: Any, render: dict[str, Any], samples: int) -> None:
    scene.cycles.samples = samples
    scene.cycles.adaptive_threshold = float(render["adaptive_threshold"])
    scene.cycles.use_denoising = bool(render["denoiser"])
    if render["denoiser"]:
        scene.cycles.denoiser = render["denoiser"]
    scene.cycles.seed = int(render["seed"])
    scene.render.use_persistent_data = bool(render["persistent_data"])

    limit = int(render.get("texture_limit", 0))
    if limit > 0:
        allowed = {128, 256, 512, 1024, 2048, 4096, 8192}
        if limit not in allowed:
            raise BuildError(f"render.texture_limit must be 0 or one of {sorted(allowed)}")
        scene.render.use_simplify = True
        # Blender 5.2 exposes texture_resolution_render; older Cycles builds use
        # texture_limit_render. Support the pinned runtime and fail loudly if a
        # future API offers neither.
        if hasattr(scene.cycles, "texture_resolution_render"):
            scene.cycles.texture_resolution_render = str(limit)
        elif hasattr(scene.cycles, "texture_limit_render"):
            scene.cycles.texture_limit_render = str(limit)
        else:
            raise BuildError("Cycles texture-size-limit API unavailable in this Blender build")

    if render["device"] == "CPU":
        scene.cycles.device = "CPU"
        return

    prefs = bpy.context.preferences.addons["cycles"].preferences
    prefs.compute_device_type = "OPTIX"
    prefs.get_devices()
    optix = [d for d in prefs.devices if d.type == "OPTIX"]
    if not optix:
        raise BuildError(
            "render.device is GPU but Blender found no OptiX device. "
            "Run scripts/30_verify_gpu.py — falling back to CPU on 4 vCPU is not viable."
        )
    for device in prefs.devices:
        device.use = device.type == "OPTIX"
    scene.cycles.device = "GPU"


def validate(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> None:
    scene = bpy.context.scene
    ctx.assert_that("scene has a camera", scene.camera is not None)
    ctx.assert_that(
        "every cast member resolved",
        len(cast) == len(ctx.cfg.get("cast", [])),
        f"{len(cast)}/{len(ctx.cfg.get('cast', []))}",
    )
    ctx.assert_that(
        "frame range is non-empty",
        scene.frame_end >= scene.frame_start,
        f"{scene.frame_start}-{scene.frame_end}",
    )
    _assert_materials_resolved(ctx)
    _assert_no_unkeyed_overrides(ctx, cast)
    _assert_texture_budget(ctx)


def _assert_materials_resolved(ctx: BuildContext) -> None:
    offenders: list[str] = []
    for material in bpy.data.materials:
        if not material.use_nodes or material.node_tree is None:
            continue
        for node in material.node_tree.nodes:
            if node.bl_idname != "ShaderNodeBsdfPrincipled":
                continue
            socket = node.inputs.get("Base Color")
            if socket is None or socket.is_linked:
                continue
            value = list(socket.default_value)[:3]
            if max(value) <= 0.0:
                offenders.append(f"{material.name}/{node.name}")
    ctx.assert_that(
        "no material renders black from an unset base colour",
        not offenders,
        ", ".join(offenders[:5]) if offenders else "clean",
    )


def _assert_no_unkeyed_overrides(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> None:
    blocked = {track["character_id"] for track in ctx.cfg.get("blocking", [])}
    missing = []
    for character_id in blocked:
        root = cast.get(character_id, {}).get("root")
        if root is None or root.animation_data is None or root.animation_data.action is None:
            missing.append(character_id)
    ctx.assert_that(
        "blocked characters carry keyframes",
        not missing,
        ", ".join(missing) if missing else "ok",
    )


def _assert_texture_budget(ctx: BuildContext) -> None:
    """Static manifest warning only; host GPU admission is authoritative."""
    policy = opt(ctx.cfg, "resource_policy.gpu", {}) or {}
    workloads = policy.get("workloads", {})
    budget_mib = int(workloads.get("cycles_final", {}).get("estimated_peak_mib", 0))
    if budget_mib <= 0:
        return
    declared = 0
    for asset_id in _referenced_assets(ctx):
        entry = ctx.manifest.get("assets", {}).get(asset_id, {})
        declared += int(entry.get("complexity", {}).get("texture_memory_estimate_mb", 0))
    ctx.assert_that(
        "declared texture memory fits the cycles_final estimate",
        declared <= budget_mib,
        f"{declared} MiB declared vs {budget_mib} MiB estimate (live gate remains authoritative)",
    )


def _referenced_assets(ctx: BuildContext) -> list[str]:
    from .context import set_config

    ids = [member["id"] for member in ctx.cfg.get("cast", [])]
    set_id = set_config(ctx.cfg).get("environment_asset_id")
    if set_id:
        ids.append(set_id)
    hdri = opt(ctx.cfg, "lighting.hdri_asset_id")
    if hdri:
        ids.append(hdri)
    path = opt(ctx.cfg, "camera.move.path_asset_id")
    if path:
        ids.append(path)
    return ids
