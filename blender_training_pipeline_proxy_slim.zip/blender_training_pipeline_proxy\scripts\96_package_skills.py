#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ROOT / ".claude" / "skills"
OUT = ROOT / "skill_packages" / "generated"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for old in OUT.glob("*.skill"):
        old.unlink()
    manifest = []
    for skill_dir in sorted(p for p in SKILLS.iterdir() if p.is_dir()):
        src = skill_dir / "SKILL.md"
        if not src.exists():
            continue
        dest = OUT / f"{skill_dir.name}.skill"
        with zipfile.ZipFile(dest, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.write(src, arcname=f"{skill_dir.name}/SKILL.md")
        manifest.append({"name": skill_dir.name, "path": str(dest.relative_to(ROOT)), "sha256": sha256(dest)})
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(f"packaged {len(manifest)} skills")


if __name__ == "__main__":
    main()
