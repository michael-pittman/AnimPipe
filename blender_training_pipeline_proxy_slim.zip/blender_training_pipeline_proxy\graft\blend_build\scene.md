# blend_build/scene.py

- apply_scene · function · L12-L52 — def apply_scene(ctx: BuildContext, preview: bool = False) -> None
- _configure_cycles · function · L55-L95 — def _configure_cycles(scene: Any, render: dict[str, Any], samples: int) -> None
- validate · function · L98-L113 — def validate(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> None
- _assert_materials_resolved · function · L116-L134 — def _assert_materials_resolved(ctx: BuildContext) -> None
- _assert_no_unkeyed_overrides · function · L137-L148 — def _assert_no_unkeyed_overrides(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> None
- _assert_texture_budget · function · L151-L166 — def _assert_texture_budget(ctx: BuildContext) -> None
- _referenced_assets · function · L169-L182 — def _referenced_assets(ctx: BuildContext) -> list[str]
