# src/blender_training_pipeline/_tools.py

- _win_search_dirs · function · L15-L40 — def _win_search_dirs(name: str) -> list[Path]
- find_tool · function · L43-L59 — def find_tool(name: str) -> str
- ensure_tool_on_path · function · L62-L73 — def ensure_tool_on_path(name: str) -> str
