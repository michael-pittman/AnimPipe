---
name: pipeline-contracts
description: The authoritative reference for the animation pipeline's config schema, asset manifest, naming conventions, and contract versioning. Use this whenever you are reading, writing, generating, or validating any pipeline YAML/JSON, referencing an asset, naming an action or shape key, or about to hardcode a value in builder code. Consult it before proposing any change to a schema, manifest entry, or naming rule — every agent in this pipeline depends on these contracts holding, so guessing at a field name or path instead of checking here is the most common cause of downstream breakage.
---

# Pipeline Contracts

The pipeline works because every agent reads and writes the same shapes. This skill is
the single source of truth for those shapes. Read it before producing any structured
artifact; consult it again before inventing a field, an ID, or a filename.

**Only `pipeline-architect` may change these contracts.** Every other agent treats this
document as read-only and raises a `contract_gap` blocker (see `handoff-format`) instead
of improvising.

## Why this matters

Nine agents write into one pipeline. If the animation-director invents `camera.focal` while
the blender-builder expects `camera.lens`, nothing fails loudly — you get a silent default
and a wrong-looking render three steps later. Contracts turn that class of bug into a
validation error at parse time.

## Config layering

Configs merge with **OmegaConf** in a fixed precedence. Later layers override earlier ones, key by key. Hydra is intentionally deferred.

```
base.yaml  <  project.yaml  <  scene/<id>.yaml  <  shot/<id>.yaml  <  CLI --override
```

Rules:
- **Never write a value into a lower layer to fix a higher-layer problem.** If one shot
  needs a different lens, override it in that shot, not in `project.yaml`.
- Every field must exist with a default in the schema. A shot YAML should be short — only
  what differs from the project.
- CLI overrides are for experiments only. Anything worth keeping gets committed to a layer.

## Where the schema lives

```
config/schema/          Pydantic v2 models — the definitive field list
config/schema/*.schema.json                     JSON Schemas, regenerated on change
```

**Read the Pydantic models before generating config.** This document describes the
contract's structure and rules; the models are the field-level truth and they move faster
than prose does.

Generating config: emit YAML, then validate with `pipe validate` before handing off. Never
hand off unvalidated config.

## Top-level config groups

`render`, `camera`, `lighting`, `set`, `cast`, `blocking`, `dialogue`, `comp`, `output`,
`scene`, `render`, `camera`, `lighting`, `set`, `cast`, `blocking`, `dialogue`, `comp`,
`output`, `preview`, `resource_policy`, `qa`, and `metadata`. `scene` is the director-script
semantic object; later shot fields realize its beats in Blender. Each is a nested object, never a flat prefixed key — `camera.lens`, not
`camera_lens`.

## Asset references

**Agents never write filesystem paths.** All asset access goes through logical IDs
resolved by `assets/assets.yaml`.

```yaml
# correct
cast:
  - id: char.instructor_a
    spawn: [0, 0, 0]

# wrong — breaks the moment an asset moves or versions
cast:
  - path: assets/characters/instructor_a_v3.blend
```

Manifest entry shape:

```yaml
char.instructor_a:
  file: characters/instructor_a.blend
  collection: RIG_instructor_a
  kind: character
  contract: rig/v1
  version: 3
```

`contract` names the rig contract the asset claims to satisfy. `asset-validator` verifies
the claim; everyone else trusts it.

## Naming conventions

These names are the vocabulary the animation-director composes with. They must be stable.

| Thing | Pattern | Example |
|---|---|---|
| Asset ID | `<kind>.<snake_name>` | `char.instructor_a`, `set.lab_interior` |
| Action | `<category>_<descriptor>[_<variant>]` | `idle_neutral`, `gesture_point_a` |
| Viseme shape key | `viseme_<X>` where X is A–H | `viseme_D` |
| Expression shape key | `expr_<name>` | `expr_concerned` |
| Scene ID | `<module>` | `module_01` |
| Shot ID | `<module>_s<NNN>` | `m01_s030` |
| Marker | `beat_<name>` | `beat_intro_end` |

Shot numbers increment by 10 so shots can be inserted without renumbering.

## Frames, time, and units

- Time is expressed in **frames**, not seconds, in all builder-facing config. `fps` lives in
  `base.yaml` and is the only place a conversion happens.
- Scene unit scale is 1.0 = 1 meter. Assets that violate this are rejected at admission.
- `+Y` is screen-forward for characters. Facing is expressed in degrees about `+Z`.

## Contract versioning

Contracts are semver'd in `config/schema/VERSION`.

- **Patch** — added an optional field with a default. No agent action needed.
- **Minor** — added a required field with a safe default, or deprecated a field. Existing
  configs still validate.
- **Major** — renamed or removed a field, changed a type or a naming rule. Requires a
  migration script in `config/migrations/` and a re-validation pass over all committed
  configs.

Every artifact records the contract version it was produced against. When you read an
artifact whose version is behind the current major, do not interpret it — raise a blocker.

## Proposing a contract change

Any agent may propose; only `pipeline-architect` may apply. Emit this as a blocker:

```json
{
  "blocker": "contract_gap",
  "need": "camera shake amplitude is not expressible",
  "proposed_field": "camera.shake.amplitude",
  "type": "float, default 0.0",
  "affects": ["animation-director", "blender-builder"],
  "workaround": "none — currently requires a hardcoded value in camera.py"
}
```

Do not work around a contract gap by hardcoding. A hardcoded value is invisible to every
other agent and defeats the point of the pipeline being configurable.

## The hardcoding rule

If builder code needs a number, that number comes from config with a schema default. The
only permitted literals in builder code are structural constants that are not creative
choices — array indices, API enum values, epsilon comparisons.

When you find yourself typing a number that someone might reasonably want to change later,
stop and add it to the schema instead.
