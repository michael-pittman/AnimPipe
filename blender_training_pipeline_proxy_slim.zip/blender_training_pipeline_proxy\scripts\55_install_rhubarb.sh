#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
VERSION="1.14.0"
TAG="v${VERSION}"
API="https://api.github.com/repos/DanielSWolf/rhubarb-lip-sync/releases/tags/${TAG}"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

meta="$TMP/release.json"
curl -fsSL "$API" -o "$meta"
asset_name="$(jq -r '.assets[] | select(.name | test("Linux\\.zip$")) | .name' "$meta" | head -n1)"
asset_url="$(jq -r --arg n "$asset_name" '.assets[] | select(.name==$n) | .browser_download_url' "$meta")"
asset_digest="$(jq -r --arg n "$asset_name" '.assets[] | select(.name==$n) | (.digest // "")' "$meta")"
[[ -n "$asset_name" && -n "$asset_url" && "$asset_url" != null ]] || { echo 'Linux Rhubarb release asset not found' >&2; exit 2; }

archive="$TMP/$asset_name"
curl -fL "$asset_url" -o "$archive"
actual="$(sha256sum "$archive" | awk '{print $1}')"
if [[ "$asset_digest" == sha256:* ]]; then
  expected="${asset_digest#sha256:}"
  [[ "$actual" == "$expected" ]] || { echo 'Rhubarb SHA-256 mismatch' >&2; exit 3; }
fi

sudo rm -rf "/opt/rhubarb/${VERSION}"
sudo mkdir -p "/opt/rhubarb/${VERSION}"
sudo unzip -q "$archive" -d "/opt/rhubarb/${VERSION}"
bin="$(find "/opt/rhubarb/${VERSION}" -type f -name rhubarb -perm /111 | head -n1)"
[[ -n "$bin" ]] || { echo 'Rhubarb executable not found after extraction' >&2; exit 4; }
sudo ln -sfn "$bin" /usr/local/bin/rhubarb
mkdir -p reports/environment
{
  echo "version=${VERSION}"
  echo "asset=${asset_name}"
  echo "sha256=${actual}"
  echo "source=${asset_url}"
} > reports/environment/rhubarb-version.txt
rhubarb --version
