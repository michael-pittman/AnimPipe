# Multi-Team Pipeline Review — 2026-09-11

Seven independent review tracks were applied to the updated builder. This document records findings, fixes, and what still requires the real Azure VM.

## 1. Architecture & contracts

**Finding:** The host/Blender boundary remains correct, but several schema fields had drifted ahead of implementation.

**Resolved:** Follow Path, set dressing, post-render comp, retarget normalization, typed caption/overlay contracts, path asset kind, and bounded QA orchestration now have executable implementations or explicit admission semantics.

## 2. Blender / bpy compatibility

**Finding:** The schema still admitted the pre-5.0 engine ID `BLENDER_EEVEE_NEXT`. Blender 5.x uses `BLENDER_EEVEE`. Blender 5.x also requires `ImageFormatSettings.media_type` to be selected before `file_format`.

**Resolved:** IDs and setup order corrected. Added `scripts/45_blender_api_contract_probe.py` to assert the exact APIs used by the builder under the pinned Blender 5.2.1 executable.

**Verified externally:** current Blender release/API documentation, NLA slots, Follow Path properties, background `gpu.init()`, and Cycles texture simplification behavior.

## 3. GPU / Azure runtime

**Finding:** CLI rendering could bypass the live hardware/VRAM gate when `--config` was omitted, and NVENC encoding had no GPU lock.

**Resolved:** `pipe render frames` now requires resolved config and always selects `cycles_preview` or `cycles_final` admission policy. NVENC encode also uses the exclusive GPU scheduler. Live UUID/name/VRAM validation remains authoritative; the manifest's texture estimate is only an early warning.

**Verified externally:** Microsoft still documents `595.58.03-grid-azure` for NCasT4_v3 and requires Secure Boot/vTPM disabled for the manual GRID procedure.

## 4. Claude agents / skills

**Finding:** Existing boundaries remain sound: only the debugger gets official Blender MCP and no agent preloads more than four skills. The operational skills did not yet mention the now-executable QA loop or Follow Path behavior.

**Resolved:** project skills updated to describe executable gates and boundaries. Vendor Blender-agent custom MCP operations remain inactive; only standard-bpy-compatible knowledge is used.

## 5. Audio / TTS / lipsync

**Finding:** Kokoro and Rhubarb modules existed but had no first-class CLI workflow; faster-whisper was installed but not exposed for alignment.

**Resolved:** added `pipe audio synthesize`, `pipe audio visemes`, and `pipe audio align`. Alignment is CPU/int8. The supported host environment installs neither a CUDA development toolkit nor CUDA Python user-space runtime for Whisper.

## 6. Render QA / vision loop

**Finding:** `review_iteration` enforced one critic step but did not itself own build→render→review→revision.

**Resolved:** `pipe qa run-loop` now owns the bounded loop. Each candidate is allow-list patched and Pydantic-validated before the next build. Cycles preview and Qwen VLM calls independently pass through the live GPU/VRAM gate. The loop terminates on pass, explicit escalation, insufficient score improvement, build failure, or revision cap.

## 7. Operations / delivery

**Finding:** FFmpeg assumed frame 0, while Blender shots typically start at frame 1 or another configured frame. Post-render comp fields were not applied.

**Resolved:** encode uses `render.frame_start`; LUT, captions, and overlays are applied in FFmpeg; captions require explicit frame bounds. Smoke tests now check required FFmpeg filters and run the unit suite plus Blender API probe.

## External verification snapshot

As of 2026-09-11:

- Blender 5.2.1 is the active 5.2 LTS patch release.
- official `bpy==5.2.1` requires CPython 3.13; host pipeline stays Python 3.11.
- `fake-bpy-module-5.2==20260730` is the current version-specific IDE stub package.
- Microsoft documents GRID `595.58.03-grid-azure` for NCasT4_v3.
- FFmpeg documents `lut3d` and `overlay`; smoke test additionally verifies the installed build exposes `subtitles`.

## VM-only acceptance remaining

These are environment acceptance checks, not source-code gaps:

1. Azure IMDS reports the expected SKU.
2. the actual PCI/GPU identity is one Tesla T4 with expected VRAM.
3. GRID installation succeeds and survives reboot.
4. Blender 5.2.1 sees OptiX and passes the API contract probe.
5. FFmpeg's installed build exposes NVENC + required filters.
6. NVIDIA Container Toolkit passes T4 through to Ollama.
7. Qwen3-VL and Kokoro service smoke calls succeed.
8. one real admitted character/set/path asset completes build→preview→QA→encode.

## 8. Security & configuration boundaries

**Finding:** delivery artwork initially resolved raw paths and overlay coordinates accepted unrestricted FFmpeg expressions. The local Kokoro service also generated an API key that the host CLI did not automatically read.

**Resolved:** LUT/overlay artwork is now referenced only by logical manifest IDs; manifest file paths are constrained to relative paths under the configured asset root and checked again after resolution. Overlay coordinates accept only simple arithmetic tokens, preventing filter-graph separator/quoting injection. `pipe audio synthesize` now reads `KOKORO_API_KEY` from the process environment or `infra/kokoro.env`, matching the service bootstrap.

## Local release validation

The reviewed bundle is regenerated and tested after all fixes. See `FINAL_VALIDATION.md` and `reports/final-validation.json` for exact machine-readable results. Target-GPU checks remain deliberately separated from source validation because they can only be proved on the Azure VM.
