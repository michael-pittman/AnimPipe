"""Fail fast if the pinned Blender runtime no longer exposes APIs the builder uses."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import bpy
import gpu


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def main() -> None:
    require(bpy.app.version[:2] == (5, 2), f"expected Blender 5.2.x, found {bpy.app.version_string}")
    engine_items = {item.identifier for item in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items}
    require("BLENDER_EEVEE" in engine_items, "BLENDER_EEVEE engine identifier missing")
    image_props = bpy.types.ImageFormatSettings.bl_rna.properties
    require("media_type" in image_props.keys(), "ImageFormatSettings.media_type missing")
    constraint_props = bpy.types.FollowPathConstraint.bl_rna.properties
    for name in ["offset_factor", "use_fixed_location", "forward_axis", "up_axis"]:
        require(name in constraint_props.keys(), f"FollowPathConstraint.{name} missing")
    strip_props = bpy.types.NlaStrip.bl_rna.properties
    for name in ["action_slot", "action_suitable_slots"]:
        require(name in strip_props.keys(), f"NlaStrip.{name} missing")
    scene = bpy.context.scene
    require(
        hasattr(scene.cycles, "texture_resolution_render") or hasattr(scene.cycles, "texture_limit_render"),
        "Cycles render texture-size-limit API missing",
    )
    # gpu.init() initialises the display/OpenGL backend.  On headless Windows servers
    # (T4 in TCC mode, no WGL-capable adapter) the native call raises an
    # EXCEPTION_ACCESS_VIOLATION that Python cannot catch.  Skip it there; it is
    # validated separately by a live render probe that requires a WDDM display context.
    if sys.platform != "win32":
        gpu.init()
        gpu_init_ok = True
        gpu_init_note = "ok"
    else:
        gpu_init_ok = None  # type: ignore[assignment]
        gpu_init_note = "deferred to live render probe (Windows/TCC)"
    report = {
        "status": "pass",
        "blender_version": bpy.app.version_string,
        "eevee_engine": "BLENDER_EEVEE",
        "image_media_type": True,
        "nla_slots": True,
        "follow_path": True,
        "cycles_texture_limit_api": (
            "texture_resolution_render" if hasattr(scene.cycles, "texture_resolution_render")
            else "texture_limit_render"
        ),
        "gpu_init": gpu_init_ok,
        "gpu_init_note": gpu_init_note,
    }
    out = Path("reports/environment/blender-api-contract.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
