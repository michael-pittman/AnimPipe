---
name: proxy-asset-factory
description: Generate and admit the neutral Proxy Animation Kit from validated specs without inventing final art direction.
---
# Proxy Asset Factory

Use this skill when creating or revising reusable proxy assets.

## Boundary

- Source of truth: `proxy_kit/kit.yaml` + `config/proxy/style.yaml`.
- The generated `.blend` files are build artifacts.
- Do not hand-edit generated proxy `.blend` files as the fix. Patch the spec or generator and regenerate.
- Keep the proxy style neutral: role-separated grayscale, low detail, no textures, no cloth/hair/particles/displacement.
- Use standard `bpy` only. Do not depend on custom Blender-agent MCP calls.

## Required kit

The canonical v1 kit must provide:
- one rigged instructor mannequin;
- 12 reusable motion Actions and 8 held pose Actions;
- Rhubarb A-H/X viseme shape keys;
- blink/brow/expression/look proxy shape keys;
- left/right hand attachment bones;
- modular room with foreground/set/background/focus material roles;
- six interaction props;
- two camera paths;
- five transparent graphics overlays.

## Workflow

1. Validate `proxy_kit/kit.yaml` with `pipe proxy validate`.
2. On the Blender host, run `pipe proxy generate`.
3. Treat any generation failure as a spec/generator defect.
4. Run Asset Doctor on generated entries if deeper inspection is needed.
5. Keep generated files beneath `assets/proxy/` and reference them only through logical manifest IDs.

## Acceptance

Generation is successful only if the emitted manifest validates and every generated asset passes static admission. The 10-shot acceptance film is the system-level test, not asset beauty.
