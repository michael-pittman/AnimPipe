# src/blender_training_pipeline/tts.py

- _env_file_api_key · function · L9-L15 — def _env_file_api_key(path: Path = Path("infra/kokoro.env")) -> str | None
- KokoroClient · class · L18-L45 — class KokoroClient
- __init__ · method · L19-L21 — def __init__(self, base_url: str = "http://127.0.0.1:8880", api_key: str | None = None) -> None
- synthesize · method · L23-L45 — def synthesize( self, text: str, output: Path, *, voice: str = "af_heart", speed: float = 1.0, response_format: str = "wav", model: str = "tts-1", ) -> Path
