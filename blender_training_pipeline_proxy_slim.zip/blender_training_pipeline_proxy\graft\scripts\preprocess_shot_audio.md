# scripts/preprocess_shot_audio.py

- main · function · L25-L68 — def main() -> None
