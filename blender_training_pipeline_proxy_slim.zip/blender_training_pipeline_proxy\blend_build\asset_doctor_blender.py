from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import bpy


def parse_args() -> argparse.Namespace:
    args = sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []
    p = argparse.ArgumentParser()
    p.add_argument("--blend", required=True)
    p.add_argument("--collection")
    p.add_argument("--armature")
    p.add_argument("--actions", nargs="*", default=[])
    p.add_argument("--visemes", nargs="*", default=[])
    p.add_argument("--expressions", nargs="*", default=[])
    p.add_argument("--report", required=True)
    return p.parse_args(args)


def main() -> None:
    ns = parse_args()
    bpy.ops.wm.open_mainfile(filepath=str(Path(ns.blend).resolve()))
    checks = {}
    if ns.collection:
        checks["collection"] = ns.collection in bpy.data.collections
    if ns.armature:
        obj = bpy.data.objects.get(ns.armature)
        checks["armature"] = bool(obj and obj.type == "ARMATURE")
    checks["actions"] = all(name in bpy.data.actions for name in ns.actions)
    if ns.actions and hasattr(bpy.types.Action, "slots"):
        checks["action_slots"] = all(len(bpy.data.actions[name].slots) > 0 for name in ns.actions if name in bpy.data.actions)
    key_sets = [
        {kb.name for kb in obj.data.shape_keys.key_blocks}
        for obj in bpy.data.objects
        if obj.type == "MESH" and obj.data.shape_keys
    ]
    checks["visemes"] = not ns.visemes or any(all(name in keys for name in ns.visemes) for keys in key_sets)
    union = set().union(*key_sets) if key_sets else set()
    checks["expressions"] = all(name in union for name in ns.expressions)
    report = {"checks": checks, "passed": all(checks.values()), "blender_version": bpy.app.version_string}
    Path(ns.report).write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if not report["passed"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
