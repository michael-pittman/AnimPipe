# blend_build/performance.py

- _ensure_anim_data · function · L23-L26 — def _ensure_anim_data(obj: Any) -> Any
- _get_track · function · L29-L35 — def _get_track(anim_data: Any, name: str) -> Any
- assign_slot · function · L38-L66 — def assign_slot(strip: Any, target: Any) -> str | None
- build_strip · function · L69-L110 — def build_strip(anim_data: Any, target: Any, spec: dict[str, Any], actions: dict[str, Any]) -> Any
- build_performances · function · L113-L144 — def build_performances(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> None
- bpy_strip_probe · function · L147-L151 — def bpy_strip_probe() -> Any
