# src/blender_training_pipeline/config_compile.py

- _sha256_bytes · function · L13-L14 — def _sha256_bytes(data: bytes) -> str
- compile_pipeline · function · L17-L29 — def compile_pipeline( layers: Iterable[Path], overrides: list[str] | None = None ) -> tuple[PipelineConfig, dict, str]
- write_compiled · function · L32-L37 — def write_compiled(layers: list[Path], output: Path, overrides: list[str] | None = None) -> str
- validate_director_script · function · L40-L48 — def validate_director_script(path: Path) -> DirectorScriptDocument: # Scene YAML files are dual-purpose: they contain a `scene` director-script block # and may also carry pipeline-config overrides (e.g. `set`, `metadata`). # DirectorScriptDocument expects only the `scene` key, so extract just that subtree.
