#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v uv >/dev/null 2>&1; then
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$PATH"
fi
uv python install 3.11 3.13
rm -rf .venv .venv-bpy
uv venv --python 3.11 .venv
uv pip install --python .venv/bin/python -e '.[dev]'
uv venv --python 3.13 .venv-bpy
uv pip install --python .venv-bpy/bin/python 'bpy==5.2.1' 'pytest>=8,<9'
.venv/bin/python -c 'import pydantic, omegaconf; print("host env OK")'
.venv-bpy/bin/python -c 'import bpy; print("bpy", bpy.app.version_string)'
