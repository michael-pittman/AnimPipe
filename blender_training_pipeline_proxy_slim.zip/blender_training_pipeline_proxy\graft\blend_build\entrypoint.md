# blend_build/entrypoint.py

- parse_args · function · L40-L49 — def parse_args() -> argparse.Namespace
- sha256 · function · L52-L53 — def sha256(path: Path) -> str
- clear_scene · function · L56-L65 — def clear_scene() -> None
- build · function · L68-L112 — def build(ns: argparse.Namespace) -> dict
- main · function · L115-L137 — def main() -> None
