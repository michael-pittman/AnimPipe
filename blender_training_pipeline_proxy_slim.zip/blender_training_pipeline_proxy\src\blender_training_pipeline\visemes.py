from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path


def _find_rhubarb() -> str:
    # Prefer PATH; fall back to vendor bundle (Windows / dev environments)
    in_path = shutil.which("rhubarb")
    if in_path:
        return in_path
    candidates = sorted(
        Path(__file__).parent.parent.parent.glob(
            "vendor/rhubarb/**/" + ("rhubarb.exe" if __import__("sys").platform == "win32" else "rhubarb")
        )
    )
    if candidates:
        return str(candidates[0])
    raise FileNotFoundError(
        "rhubarb not found in PATH or vendor/rhubarb/. "
        "Run scripts/55_install_rhubarb.sh or add the vendor path to PATH."
    )


def rhubarb_cues(wav: Path, output_json: Path, transcript: Path | None = None) -> dict:
    rhubarb = _find_rhubarb()
    command = [rhubarb, "-f", "json", "-o", str(output_json)]
    if transcript is not None:
        command += ["--dialogFile", str(transcript)]
    command.append(str(wav))
    output_json.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(command, check=True)
    return json.loads(output_json.read_text(encoding="utf-8"))
