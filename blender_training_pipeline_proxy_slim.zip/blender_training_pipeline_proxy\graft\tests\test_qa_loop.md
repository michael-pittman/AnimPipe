# tests/test_qa_loop.py

- _review · function · L6-L18 — def _review(verdict: str = "revise", score: float = 0.8, changes: bool = True) -> VisualReview
- test_revision_allowed_before_cap · function · L21-L24 — def test_revision_allowed_before_cap() -> None
- test_revision_escalates_at_cap · function · L27-L30 — def test_revision_escalates_at_cap() -> None
- test_revision_escalates_without_minimum_improvement · function · L33-L36 — def test_revision_escalates_without_minimum_improvement() -> None
