---
name: patch-proposal-format
description: How to turn a live Blender MCP diagnosis into a reviewable patch proposal instead of writing code directly. Use this whenever you have inspected a scene, found a root cause, and are about to fix it — and whenever you are tempted to run bpy code that mutates anything beyond the scratch instance. The debugging agent's scene state comes from an unsandboxed MCP session, so its findings must be proposals that another agent reviews and applies; consult this before acting on any diagnosis.
---

# Patch Proposal Format

You diagnose. You do not patch. This is the boundary that keeps an unsandboxed MCP session
out of the deterministic build path.

## Why the separation exists

Blender's MCP server executes generated code inside Blender with no guards. Your session
runs against a scratch instance precisely so that mistakes are cheap. But that also means
everything you learn is derived from a session that could have been mutated in ways you
didn't intend and can't fully audit. Code written from that state, committed directly to
`blend_build/`, would carry that uncertainty into every future render.

So: your output is evidence plus a proposed change. `blender-builder` reviews, implements,
and tests it in the clean path.

## What you may and may not do

**May:** query scene graph, dump datablocks, read modifier and driver state, inspect node
trees, run non-destructive experiments in the scratch instance, render preview frames to
`scratch/`, mutate the scratch scene freely to test a hypothesis.

**May not:** edit anything under `blend_build/`, `config/`, or `assets/`; save a `.blend`
into `build/`; modify supplied assets; propose loosening the MCP sandbox.

Mutating the scratch scene to test a fix is encouraged — that's how you get evidence. Just
never mistake "it works in scratch" for "it's fixed."

## The proposal

Write to `reports/debug/<task_id>.json` and reference it from your handoff envelope.

```json
{
  "symptom": "m01_s030 renders instructor_a fully black under key light",
  "reproduction": {
    "config": "config/shot/m01_s030.yaml",
    "command": "pipe build shot m01_s030 --preview",
    "deterministic": true
  },
  "evidence": [
    "material INST_skin: Principled BSDF base color input unconnected, socket default (0,0,0)",
    "same material renders correctly in assets/characters/instructor_a.blend",
    "library override created before material slot resolution in assets.py:link_character"
  ],
  "root_cause": "Library override is applied to the object before the material datablock is resolved, so the override captures an unlinked material state.",
  "confidence": "high",
  "proposed_change": {
    "file": "blend_build/assets.py",
    "function": "link_character",
    "change": "Resolve and validate material slots after override creation, not before; assert every Principled BSDF base color input is connected or has a non-zero default.",
    "diff_sketch": "move the slot-resolution block below `create_library_override(...)`; add `_assert_materials_resolved(obj)` after it"
  },
  "verification": "Build m01_s030 preview; assert mean luminance of the character matte region is > 0.02. Add a unit test linking a character and asserting no material has an unconnected base color.",
  "scope": "Affects every shot linking a character. Expect a full re-render.",
  "alternatives_rejected": [
    "Setting base color default in the asset — hides the ordering bug and diverges the studio copy."
  ]
}
```

## Field guidance

**`symptom`** — what a human would observe, not your interpretation. "Renders black," not
"material bug."

**`reproduction`** — the exact command. If you cannot reproduce it deterministically, say
so and set `confidence` to `low`; an intermittent bug needs different handling and the
builder must know that up front.

**`evidence`** — concrete observations from the live scene, each independently checkable.
This is the most valuable part of the proposal. The builder can re-derive your reasoning
but cannot re-derive what you saw in a session that no longer exists.

**`root_cause`** — one sentence, mechanistic. If you can only describe a correlation, say
that explicitly and set `confidence` to `medium` or `low`. A confidently stated wrong cause
costs more than an honest uncertain one, because the builder will implement it.

**`confidence`** — `high` (reproduced, cause isolated, fix verified in scratch), `medium`
(cause identified, fix untested), `low` (plausible hypothesis only).

**`proposed_change`** — file, function, and the change in prose. A `diff_sketch` is
welcome; a full patch is not, because the builder must own the implementation.

**`verification`** — how the builder proves it worked, ideally as an assertion or test that
survives in the suite. Every real bug should leave a regression test behind.

**`scope`** — what else this touches and whether a re-render is needed. Underestimating
scope is the failure mode here; a fix in `assets.py` almost never affects one shot.

**`alternatives_rejected`** — briefly. This prevents the builder re-treading a path you
already ruled out, and it exposes reasoning errors for review.

## Contract gaps, not workarounds

If the fix requires a value that has no schema field, the proposal is a `contract_gap`
blocker routed to `pipeline-architect`, not a hardcoded constant in the proposed change.
Debugging pressure is exactly when hardcoding feels most justified and does the most damage.

## When you cannot find the cause

Say so. Emit the proposal with `root_cause: null`, `confidence: "low"`, and everything you
ruled out. A well-documented dead end is genuinely useful — it saves the next agent from
repeating the search. Inventing a plausible-sounding cause to avoid an empty field is the
worst available outcome.
