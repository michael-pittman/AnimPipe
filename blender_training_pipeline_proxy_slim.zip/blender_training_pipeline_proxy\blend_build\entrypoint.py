from __future__ import annotations

# Production Blender entry point. Run with:
#   blender --background --factory-startup --python blend_build/entrypoint.py -- \
#     --config build/<shot>/resolved_config.json \
#     --manifest build/assets.resolved.json \
#     --assets-root assets \
#     --output build/<shot>/scene.blend [--preview]
#
# Intentionally MCP-free: nothing here depends on a live Blender session, and the
# same config always produces the same .blend.
import argparse
import hashlib
import json
import sys
import traceback
from pathlib import Path

import bpy

_HERE = Path(__file__).resolve().parent
if str(_HERE.parent) not in sys.path:
    sys.path.insert(0, str(_HERE.parent))

from blend_build.assets import build_cast, build_set
from blend_build.camera import build_camera
from blend_build.context import BuildContext, BuildError
from blend_build.performance import build_performances
from blend_build.props import build_props
from blend_build.scene import apply_scene, validate
from blend_build.stages import (
    build_blocking,
    build_comp,
    build_facial_cues,
    build_lighting,
    build_lipsync,
)


def parse_args() -> argparse.Namespace:
    args = sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--assets-root", default="assets")
    parser.add_argument("--output", required=True)
    parser.add_argument("--preview", action="store_true")
    parser.add_argument("--report", default=None)
    return parser.parse_args(args)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def clear_scene() -> None:
    """Start from an empty scene even under --factory-startup.

    factory-startup still gives us the default cube, camera and light. Leaving
    them in means a shot can render "fine" using scenery nobody configured.
    """
    for obj in list(bpy.data.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    for collection in list(bpy.data.collections):
        bpy.data.collections.remove(collection)


def build(ns: argparse.Namespace) -> dict:
    config_path = Path(ns.config).resolve()
    manifest_path = Path(ns.manifest).resolve()
    assets_root = Path(ns.assets_root).resolve()
    output = Path(ns.output).resolve()

    cfg = json.loads(config_path.read_text(encoding="utf-8"))
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    ctx = BuildContext(cfg=cfg, manifest=manifest, assets_root=assets_root)

    clear_scene()
    apply_scene(ctx, preview=ns.preview)

    build_set(ctx)
    cast = build_cast(ctx)
    build_performances(ctx, cast)
    build_props(ctx, cast)
    build_blocking(ctx, cast)
    build_facial_cues(ctx, cast)
    build_lipsync(ctx, cast)
    build_camera(ctx, cast)
    build_lighting(ctx)
    build_comp(ctx)

    validate(ctx, cast)

    failures = ctx.failures()
    output.parent.mkdir(parents=True, exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(output))

    return {
        "status": "blocked" if failures else "ok",
        "config": str(config_path),
        "config_sha256": sha256(config_path),
        "manifest_sha256": sha256(manifest_path),
        "blend": str(output),
        "blend_sha256": sha256(output),
        "blender_version": bpy.app.version_string,
        "preview": bool(ns.preview),
        "shot_id": cfg.get("metadata", {}).get("shot_id"),
        "scene_id": cfg.get("metadata", {}).get("scene_id"),
        "contract_version": cfg.get("metadata", {}).get("contract_version"),
        "assertions": ctx.assertions,
        "failed_assertions": failures,
    }


def main() -> None:
    ns = parse_args()
    report_path = Path(ns.report) if ns.report else Path(ns.output).with_name("build_manifest.json")
    report_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        report = build(ns)
    except BuildError as exc:
        report = {"status": "blocked", "error": str(exc), "error_type": "BuildError"}
    except Exception as exc:  # noqa: BLE001 - the report must survive any failure
        report = {
            "status": "blocked",
            "error": str(exc),
            "error_type": type(exc).__name__,
            "traceback": traceback.format_exc(),
        }

    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    if report["status"] != "ok":
        print(f"BUILD BLOCKED: {report.get('error') or report.get('failed_assertions')}",
              file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
