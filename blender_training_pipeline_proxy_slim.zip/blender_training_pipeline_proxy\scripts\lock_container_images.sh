#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p reports/environment
python3 - <<'PY'
import json, subprocess
from pathlib import Path

names = ["anim-ollama", "anim-kokoro"]
out = {}
locked = {}
for name in names:
    try:
        image_id = subprocess.check_output(
            ["docker", "inspect", "--format", "{{.Image}}", name], text=True
        ).strip()
        configured = subprocess.check_output(
            ["docker", "inspect", "--format", "{{.Config.Image}}", name], text=True
        ).strip()
        raw = subprocess.check_output(["docker", "image", "inspect", image_id], text=True)
        image = json.loads(raw)[0]
        digests = image.get("RepoDigests") or []
        out[name] = {
            "configured_image": configured,
            "image_id": image_id,
            "repo_digests": digests,
        }
        if digests:
            locked[name] = digests[0]
    except subprocess.CalledProcessError:
        out[name] = {"not_running": True}

Path("reports/environment/container-images.json").write_text(
    json.dumps(out, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)

# Produce a ready-to-use immutable image env once registry RepoDigests are available.
if "anim-ollama" in locked and "anim-kokoro" in locked:
    model = "qwen2.5vl:3b"
    env = Path("infra/.env")
    if env.exists():
        for line in env.read_text(encoding="utf-8").splitlines():
            if line.startswith("QWEN_VISION_MODEL="):
                model = line.split("=", 1)[1].strip()
    Path("infra/.env.locked").write_text(
        f"OLLAMA_IMAGE={locked['anim-ollama']}\n"
        f"KOKORO_IMAGE={locked['anim-kokoro']}\n"
        f"QWEN_VISION_MODEL={model}\n",
        encoding="utf-8",
    )
PY
