# tests/test_asset_contract.py

- test_example_asset_manifest_schema · function · L8-L10 — def test_example_asset_manifest_schema() -> None
