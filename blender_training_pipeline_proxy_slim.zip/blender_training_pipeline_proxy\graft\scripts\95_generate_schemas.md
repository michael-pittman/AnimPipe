# scripts/95_generate_schemas.py

- main · function · L26-L31 — def main() -> None
