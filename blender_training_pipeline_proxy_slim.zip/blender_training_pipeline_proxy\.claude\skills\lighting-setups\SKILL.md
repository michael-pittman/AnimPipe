---
name: lighting-setups
description: Blender lighting implementation guidance adapted from the supplied Blender-agent repo. Use for standard-bpy three-point/HDRI rig construction and lighting diagnosis while keeping every creative value sourced from validated config.
---

# Lighting Setups — Config Driven

The supplied Blender-agent repo provides useful three-point and HDRI patterns. In this
pipeline they are implementation patterns, **not creative defaults**. Energy, color
temperature, placement policy, HDRI ID, rotation and strength come from resolved config.

## Three-point rig

For each configured key/fill/rim light:

1. Resolve its role and parameters from `lighting` config.
2. Create/reuse the named light datablock deterministically.
3. Construct placement from the selected rig preset and framing/subject target.
4. Aim by vector/constraint logic rather than hand-edited viewport rotations.
5. Record the generated object/datablock names in the build manifest when useful for QA.

Never copy hard-coded wattage, color or distances from an example into builder code.

## HDRI world

Resolve the HDRI through the asset manifest. Load the admitted file, build the world node
graph deterministically, and apply configured rotation/strength. Config references logical
asset IDs, never filesystem paths.

## Diagnosis

If lighting appears wrong, inspect in this order:

- shipping render engine and GPU initialization
- view transform/colorspace
- linked asset/world state
- light transforms and target geometry
- configured energy/color temperature/HDRI strength
- occlusion/shadow behavior

Judge from a **pipeline preview render** in the intended engine. The official Blender MCP may
inspect a disposable scratch copy, but it is not the render/build path.

Exact upstream source is preserved under `vendor/blender-agent-upstream/skills/`.
