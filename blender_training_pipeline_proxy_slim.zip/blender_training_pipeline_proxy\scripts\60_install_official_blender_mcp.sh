#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v uv >/dev/null || { echo 'uv is required; run 50_install_python_envs.sh first' >&2; exit 2; }
uv tool install --force 'git+https://projects.blender.org/lab/blender_mcp.git#subdirectory=mcp'
blender-mcp --help >/dev/null
cat <<'EOF'
Official Blender MCP server installed.
Next, open Blender 5.2.1 and install/enable the MCP add-on from the Blender Lab MCP page/repository.
Keep host 127.0.0.1 and port 9876. Project MCP config is already in .mcp.json.
Use it only with a scratch Blender instance as described in docs/MCP_SECURITY.md.
EOF
