"""Link asset libraries and build local overrides only when shot mutation requires them."""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any

import bpy

from .context import BuildContext, BuildError, set_config


def _scene_and_view_layer() -> tuple[Any, Any]:
    return bpy.context.scene, bpy.context.view_layer


def link_collection(blend_path: Path, collection_name: str) -> Any:
    with bpy.data.libraries.load(str(blend_path), link=True) as (data_from, data_to):
        available = list(data_from.collections)
        if collection_name not in available:
            raise BuildError(
                f"collection '{collection_name}' not found in {blend_path.name}; "
                f"available: {', '.join(available) or '(none)'}"
            )
        data_to.collections = [collection_name]
    linked = data_to.collections[0]
    if linked is None:
        raise BuildError(f"failed to link collection '{collection_name}' from {blend_path}")
    return linked


def link_object(blend_path: Path, object_name: str) -> Any:
    with bpy.data.libraries.load(str(blend_path), link=True) as (data_from, data_to):
        available = list(data_from.objects)
        if object_name not in available:
            raise BuildError(
                f"object '{object_name}' not found in {blend_path.name}; "
                f"available: {', '.join(available) or '(none)'}"
            )
        data_to.objects = [object_name]
    linked = data_to.objects[0]
    if linked is None:
        raise BuildError(f"failed to link object '{object_name}' from {blend_path}")
    return linked


def link_actions(blend_path: Path, action_names: list[str]) -> dict[str, Any]:
    if not action_names:
        return {}
    with bpy.data.libraries.load(str(blend_path), link=True) as (data_from, data_to):
        available = set(data_from.actions)
        missing = [name for name in action_names if name not in available]
        if missing:
            raise BuildError(
                f"{blend_path.name} is missing required actions: {', '.join(sorted(missing))}"
            )
        data_to.actions = list(action_names)
    return {action.name: action for action in data_to.actions}


def instantiate_override(linked_collection: Any, label: str) -> Any:
    scene, view_layer = _scene_and_view_layer()
    if linked_collection.name not in scene.collection.children:
        scene.collection.children.link(linked_collection)
    view_layer.update()
    objects = list(linked_collection.all_objects)
    if not objects:
        raise BuildError(f"linked collection '{linked_collection.name}' contains no objects")
    view_layer.objects.active = objects[0]
    override = linked_collection.override_hierarchy_create(scene, view_layer, do_fully_editable=True)
    if override is None:
        raise BuildError(f"library override creation failed for '{label}'")
    if linked_collection.name in scene.collection.children:
        scene.collection.children.unlink(linked_collection)
    view_layer.update()
    return override


def find_armature(collection: Any, armature_name: str | None) -> Any:
    armatures = [obj for obj in collection.all_objects if obj.type == "ARMATURE"]
    if not armatures:
        raise BuildError(f"no armature in '{collection.name}'")
    if armature_name:
        for obj in armatures:
            if obj.name == armature_name or obj.name.startswith(armature_name):
                return obj
        raise BuildError(
            f"armature '{armature_name}' not found in '{collection.name}'; "
            f"present: {', '.join(o.name for o in armatures)}"
        )
    if len(armatures) > 1:
        raise BuildError(
            f"'{collection.name}' has {len(armatures)} armatures and the manifest names none"
        )
    return armatures[0]


def root_object(collection: Any, armature: Any) -> Any:
    roots = [obj for obj in collection.all_objects if obj.parent is None]
    if armature in roots:
        return armature
    return roots[0] if roots else armature


def _apply_spawn(obj: Any, spawn: dict[str, Any]) -> None:
    location = spawn.get("location", [0.0, 0.0, 0.0])
    rotation = spawn.get("rotation_deg", [0.0, 0.0, 0.0])
    scale = spawn.get("scale", [1.0, 1.0, 1.0])
    obj.location = tuple(float(v) for v in location)
    obj.rotation_euler = tuple(math.radians(float(v)) for v in rotation)
    obj.scale = tuple(float(v) for v in scale)


def _material_lookup(overrides: dict[str, Any]) -> dict[str, Any]:
    materials = overrides.get("materials") if isinstance(overrides, dict) else None
    return materials if isinstance(materials, dict) else overrides


def _apply_look_overrides(collection: Any, overrides: dict[str, Any]) -> None:
    if not overrides:
        return
    requested = _material_lookup(overrides)
    if not isinstance(requested, dict):
        raise BuildError("look_overrides must be a mapping")
    matched: set[str] = set()
    for obj in collection.all_objects:
        if obj.type != "MESH":
            continue
        for slot in obj.material_slots:
            material = slot.material
            if material is None:
                continue
            base_name = material.name.split(".")[0]
            spec = requested.get(material.name) or requested.get(base_name)
            if not isinstance(spec, dict):
                continue
            local = material.copy()
            local.name = f"{base_name}__shot"
            slot.material = local
            matched.add(base_name)
            if local.use_nodes and local.node_tree:
                for node in local.node_tree.nodes:
                    if node.bl_idname != "ShaderNodeBsdfPrincipled":
                        continue
                    base_color = spec.get("base_color")
                    if base_color is not None:
                        rgba = list(base_color)
                        if len(rgba) == 3:
                            rgba.append(1.0)
                        node.inputs["Base Color"].default_value = rgba
                    roughness = spec.get("roughness")
                    if roughness is not None:
                        node.inputs["Roughness"].default_value = float(roughness)
    missing = set(requested) - matched
    if missing:
        raise BuildError(f"look_overrides reference unmatched materials: {', '.join(sorted(missing))}")


def build_cast(ctx: BuildContext) -> dict[str, dict[str, Any]]:
    built: dict[str, dict[str, Any]] = {}
    for member in ctx.cfg.get("cast", []):
        asset_id = member["id"]
        entry = ctx.asset(asset_id)
        if entry.get("kind") != "character":
            raise BuildError(f"cast asset '{asset_id}' must be kind=character")
        blend_path = ctx.asset_path(asset_id)
        collection_name = entry.get("collection")
        if not collection_name:
            raise BuildError(f"manifest entry '{asset_id}' has no collection name")

        rig = entry.get("rig") or {}
        admitted_profile = rig.get("retarget_profile")
        requested_profile = member.get("retarget_profile")
        if not admitted_profile:
            raise BuildError(f"character '{asset_id}' lacks admitted rig.retarget_profile")
        if requested_profile and requested_profile != admitted_profile:
            raise BuildError(
                f"character '{asset_id}' requested retarget_profile '{requested_profile}' but "
                f"asset was admitted as '{admitted_profile}'; retarget before admission"
            )

        linked = link_collection(blend_path, collection_name)
        override = instantiate_override(linked, asset_id)
        armature = find_armature(override, rig.get("armature"))
        root = root_object(override, armature)
        needed = sorted({strip["action"] for strip in member.get("actions", [])})
        actions = link_actions(blend_path, needed)
        _apply_spawn(root, member.get("spawn", {}))
        _apply_look_overrides(override, member.get("look_overrides", {}))

        built[asset_id] = {
            "collection": override,
            "armature": armature,
            "root": root,
            "actions": actions,
            "visemes": rig.get("visemes", {}),
            "entry": entry,
        }
        ctx.assert_that(f"cast '{asset_id}' linked and overridden", True, override.name)
    return built


def _find_object(collection: Any, requested: str) -> Any:
    for obj in collection.all_objects:
        if obj.name == requested or obj.name.startswith(requested):
            return obj
    raise BuildError(f"dressing override object '{requested}' not found in '{collection.name}'")


def _apply_dressing_overrides(collection: Any, overrides: dict[str, Any]) -> None:
    for object_name, spec in overrides.items():
        if not isinstance(spec, dict):
            raise BuildError(f"set.dressing_overrides.{object_name} must be a mapping")
        obj = _find_object(collection, object_name)
        if "location" in spec:
            obj.location = tuple(float(v) for v in spec["location"])
        if "rotation_deg" in spec:
            obj.rotation_euler = tuple(math.radians(float(v)) for v in spec["rotation_deg"])
        if "scale" in spec:
            obj.scale = tuple(float(v) for v in spec["scale"])
        if "hide_render" in spec:
            obj.hide_render = bool(spec["hide_render"])
        if "hide_viewport" in spec:
            obj.hide_viewport = bool(spec["hide_viewport"])


def build_set(ctx: BuildContext) -> Any | None:
    set_cfg = set_config(ctx.cfg)
    asset_id = set_cfg.get("environment_asset_id")
    if not asset_id:
        ctx.assert_that("set asset linked", True, "no set configured")
        return None
    entry = ctx.asset(asset_id)
    if entry.get("kind") != "set":
        raise BuildError(f"environment asset '{asset_id}' must be kind=set")
    collection_name = entry.get("collection")
    if not collection_name:
        raise BuildError(f"manifest entry '{asset_id}' has no collection name")
    linked = link_collection(ctx.asset_path(asset_id), collection_name)
    dressing = set_cfg.get("dressing_overrides") or {}
    if dressing:
        collection = instantiate_override(linked, asset_id)
        _apply_dressing_overrides(collection, dressing)
        ctx.assert_that(f"set '{asset_id}' overridden for dressing", True, collection.name)
        return collection
    bpy.context.scene.collection.children.link(linked)
    ctx.assert_that(f"set '{asset_id}' linked", True, linked.name)
    return linked


def link_path_asset(ctx: BuildContext, asset_id: str) -> Any:
    entry = ctx.asset(asset_id)
    if entry.get("kind") != "path":
        raise BuildError(f"camera path asset '{asset_id}' must be kind=path")
    blend_path = ctx.asset_path(asset_id)
    object_name = entry.get("object")
    collection_name = entry.get("collection")
    if object_name:
        obj = link_object(blend_path, object_name)
        bpy.context.scene.collection.objects.link(obj)
    elif collection_name:
        collection = link_collection(blend_path, collection_name)
        curves = [obj for obj in collection.all_objects if obj.type == "CURVE"]
        if len(curves) != 1:
            raise BuildError(
                f"path collection '{collection_name}' must contain exactly one CURVE; found {len(curves)}"
            )
        bpy.context.scene.collection.children.link(collection)
        obj = curves[0]
    else:
        raise BuildError(f"path asset '{asset_id}' names neither object nor collection")
    if obj.type != "CURVE":
        raise BuildError(f"path asset '{asset_id}' target '{obj.name}' is {obj.type}, expected CURVE")
    return obj
