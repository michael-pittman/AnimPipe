---
name: render-qa
description: Deterministic visual regression checks for preview/final frames. Use for SHA-256 identity, pHash, SSIM, frame-set selection and baseline comparisons. Semantic/art-direction judgment belongs to perceptual-frame-review and preview-revision-loop.
---

# Render QA

Use SHA-256 for exact identity and provenance. Use perceptual hash and SSIM on normalized preview images for visual equivalence/regression. Do not declare a semantic pass from similarity metrics alone.

Store thresholds in config. Store baseline ID/hash alongside metrics so a comparison is reproducible.
