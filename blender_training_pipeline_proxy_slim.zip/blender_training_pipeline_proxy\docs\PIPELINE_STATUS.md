# Pipeline Status — 2026-09-18

This document tracks the current operational state of the portrait proxy-acceptance pipeline.
It is the live status reference for recent QA findings and known acceptance gaps.

## Current state

- The portrait acceptance path is actively being tuned against delivered-output review, not only config/schema checks.
- Caption sizing/placement, overlay placement, color normalization, sparse-preview remapping, and shot-10 timing/end-card issues have been patched in source/config.
- The acceptance run is still **not signed off** for final delivery because shot 6 prop continuity remains under review.

## Confirmed improvements already landed

- `src/blender_training_pipeline/vision_review.py` now asks the critic to inspect delivered-video evidence for caption occlusion, overlay misuse, lip-sync visibility, prop continuity, and score calibration.
- `src/blender_training_pipeline/qa_loop.py` now remaps sampled preview frames into a dense review sequence before delivery-preview encoding so the critic sees temporally meaningful evidence.
- `src/blender_training_pipeline/delivery.py` escapes FFmpeg `select` sampling correctly.
- `blend_build/stages.py` exaggerates proxy mouth/head motion more clearly for lip-sync visibility.
- Portrait acceptance config fixes already landed for captions, overlays, framing, color normalization, and shot-10 timing.

## Open blockers

### 1. Shot 6 prop continuity

- File under active iteration: `config/proxy/acceptance/shot/proxy_s06.yaml`
- Current issue: the pointer is visible in portrait, but the delivered output still does not consistently read as hand-held through the later beat.
- Latest review result: the earlier delivery beat is improved, but the later beat still lets the pointer drift into a torso-crossing diagonal.

### 2. Final-film QA gap

- The current automated QA loop is per-shot, image-based, and pre-concat.
- There is no post-concat acceptance pass for `build/proxy_acceptance/proxy_acceptance_film.mp4`.
- The current QA preview is encoded without audio, so dead air, abrupt narration cutoffs, and freeze-like transitions across shot joins can escape automated review.

## What QA does today

- Rebuilds a preview blend from resolved config.
- Renders selected frames.
- Builds a contact sheet and delivery-style preview for the critic.
- Applies allow-listed config revisions when the review suggests a valid improvement.

## What QA does not do yet

- Review the concatenated final film after shot assembly.
- Listen for silence, narration cutoffs, or boundary dead air.
- Run a dedicated frozen-frame detector across shot transitions.
- Guarantee that a high score reflects true delivered-video continuity.

## Acceptance guidance right now

- Treat `pipe proxy acceptance --preview --audio` as a strong per-shot systems test, not as complete final-film sign-off.
- Perform a human review of the concatenated portrait output before calling the pipeline accepted.
- Prioritize delivered-frame verification for lip-sync, caption occlusion, overlays, and props.
