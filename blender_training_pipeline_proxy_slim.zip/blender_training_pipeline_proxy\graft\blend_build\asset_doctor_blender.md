# blend_build/asset_doctor_blender.py

- parse_args · function · L11-L21 — def parse_args() -> argparse.Namespace
- main · function · L24-L47 — def main() -> None
