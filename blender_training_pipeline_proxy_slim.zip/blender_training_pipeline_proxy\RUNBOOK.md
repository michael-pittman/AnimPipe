# Blender Training Pipeline — Operator Runbook

This runbook is the shortest supported path from a fresh Azure VM to the first deterministic
shot. Detailed rationale is in `docs/`.

## 1. Qualify the Azure VM before changing the GPU stack

```bash
python3 scripts/00_hardware_preflight.py
```

Do not continue unless `reports/environment/hardware-preflight.json` is `pass`. This checks
the Azure SKU/host shape and raw NVIDIA Tesla T4 PCI identity before driver installation.

## 2. Install the host and Microsoft-documented GRID driver

```bash
bash scripts/10_install_base_host.sh
bash scripts/20_install_azure_grid_driver.sh
sudo reboot
```

After reconnecting:

```bash
python3 scripts/30_verify_gpu.py
```

This writes the authoritative GPU UUID/name/VRAM/driver record. Every GPU admission later
re-queries `nvidia-smi` and compares the live device to this record.

## 3. Install Blender, host Python, audio tooling, MCP, and Claude Code

```bash
bash scripts/40_install_blender.sh
bash scripts/50_install_python_envs.sh
bash scripts/55_install_rhubarb.sh
bash scripts/60_install_official_blender_mcp.sh
bash scripts/65_install_claude_code.sh
bash scripts/66_install_claude_plugins.sh
```

The default host Python environment does not install CUDA development/runtime wheels for
Whisper. Faster-whisper begins CPU-side. There is no host CUDA Toolkit dependency.

Install/enable the official Blender Lab MCP add-on in the **scratch Blender profile only**.
The `.mcp.json` project config supplies the stdio server to Claude Code; only the
`blender-debugger` agent is granted that MCP server.

## 4. Start local AI services

```bash
bash scripts/70_start_local_ai.sh
```

This starts:
- Ollama on `127.0.0.1:11434` with `qwen2.5vl:3b` for preview critique (loaded via `ollama create` from GGUF — Cloudflare R2 blocks direct pull).
- Kokoro on `127.0.0.1:8880` for CPU TTS.

The Qwen model is pulled and then unloaded so it does not retain T4 VRAM while idle.

## 5. Run the Phase-0 smoke gate

```bash
bash scripts/80_smoke_test.sh
```

The smoke gate verifies live T4 identity, Docker GPU passthrough, Blender/OptiX, the pinned
Blender 5.2 API contract, NVENC plus LUT/subtitle/overlay filters, Rhubarb, the full Python
test suite, config/schema compilation, local services, skill packaging, and bundle structure.

## 6. Open the project in VS Code

Use **VS Code Remote SSH** and open this repository on the VM. Accept the recommended
extensions from `.vscode/extensions.json`.

Start Claude Code from the repository root:

```bash
claude
```

Project model settings pin Sonnet 4.6. The project agents and skills under `.claude/` are
loaded from the repository.

## 7. Generate and admit the Proxy Animation Kit

Before introducing real art assets, prove the complete production path with the neutral proxy kit:

```bash
.venv/bin/pipe proxy validate
.venv/bin/pipe proxy generate
```

Generation is deterministic from `proxy_kit/kit.yaml`. It creates the proxy mannequin, 20 reusable Actions/poses, nine Rhubarb visemes, facial controls, modular FG/MG/BG set pieces, six interaction props, two camera paths, five graphics overlays, and the manifest used by the normal builder. Blender-side Asset Doctor must pass before the kit is admitted.

Then run the ~50-second acceptance film:

```bash
.venv/bin/pipe proxy acceptance --preview --audio
```

Visual QA is enabled by default. Add `--no-qa` only when isolating a build/render failure; it is not the acceptance criterion. The ten shots deliberately exercise locomotion, NLA layering, facial cues, visemes, captions/overlays, FG/MG/BG staging, prop attach/release, Follow Path camera movement, lighting presets and final delivery. Generated proxy assets are build artifacts and remain ignored by Git.

See `docs/PROXY_ANIMATION_KIT.md` for the complete vocabulary and acceptance contract.
See `docs/PIPELINE_STATUS.md` for the current portrait acceptance status and known QA gaps. Today the automated loop is still per-shot and pre-concat, so the concatenated film requires explicit human review for dead air, abrupt narration cutoffs, and transition freezes.

## 8. Compile the example director scene + shot

```bash
.venv/bin/pipe config validate-scene config/scene/module_01.yaml
.venv/bin/pipe config compile \
  config/base.yaml \
  config/project.yaml \
  config/scene/module_01.yaml \
  config/shot/m01_s030.yaml \
  -o build/m01_s030/resolved_config.json
```

The JSON output, not the layered YAML, is the Blender build contract.

## 9. Admit real assets before shot authoring

Copy `assets/assets.yaml.example` to `assets/assets.yaml`, populate logical asset IDs, then:

```bash
.venv/bin/pipe asset doctor char.instructor_a
.venv/bin/pipe asset doctor char.instructor_a --blender
```

Do not work around a failed rig/action/viseme contract in shot code.

## 10. Exercise the deterministic Blender entry point

Once assets pass admission, export the manifest and use the host wrapper:

```bash
.venv/bin/pipe asset export-manifest --manifest assets/assets.yaml -o build/assets.resolved.json
.venv/bin/pipe build shot \
  --config build/m01_s030/resolved_config.json \
  --manifest build/assets.resolved.json \
  --output build/m01_s030/scene.blend \
  --preview
```

Production build commands never use MCP.

## 11. GPU workload rule

Any Cycles render, Ollama vision review, optional GPU Kokoro job, or NVENC delivery task
must run through the host GPU lock/admission policy. Example for a custom command:

```bash
.venv/bin/pipe gpu run cycles-final 12000 -- blender --background ...
```

The configured workload estimates live in `resource_policy.gpu.workloads`; prefer those over
ad-hoc estimates in orchestration code.

## 12. Preview QA loop

The preferred path is the bounded controller, not manual iteration:

```bash
.venv/bin/pipe qa run-loop \
  --config build/m01_s030/resolved_config.json \
  --intent config/scene/module_01.yaml \
  --asset-manifest build/assets.resolved.json \
  --work-dir reports/qa/m01_s030
```

The controller rebuilds a preview, acquires the `cycles_preview` GPU gate, renders configured
beat frames, generates a contact sheet, acquires the `vision_qa` gate, asks Qwen3-VL for the
schema-constrained review, validates allow-listed config changes, and repeats. It terminates
on pass, explicit escalation, insufficient score improvement, build failure, or revision cap.

`pipe qa review-iteration` remains available for diagnostics, but production orchestration should
use `qa run-loop`. Human approval remains the final policy gate before final render/publish.

## 13. MCP debugging rule

Copy a generated blend into scratch space and inspect that copy with `blender-debugger`.
Never turn a mutated MCP scratch scene into a deliverable. The debugger returns a config/code
patch proposal; the builder then recreates the scene cleanly.

## 14. Audio and lip sync

```bash
.venv/bin/pipe audio synthesize "Welcome to the module." -o scratch/audio/line.wav
.venv/bin/pipe audio align scratch/audio/line.wav -o scratch/audio/line.words.json
.venv/bin/pipe audio visemes scratch/audio/line.wav -o scratch/audio/line.visemes.json
```

Alignment is CPU/int8 in the supported build. No CUDA toolkit or CUDA Python runtime is installed for faster-whisper.

## 15. Final render and publish

```bash
.venv/bin/pipe render frames build/m01_s030/scene.blend \
  --config build/m01_s030/resolved_config.json \
  -o renders/m01_s030

.venv/bin/pipe render encode renders/m01_s030 \
  --config build/m01_s030/resolved_config.json \
  -o out/m01_s030.mp4
```

`render frames` cannot bypass the verified GPU/VRAM gate. NVENC encode acquires the same
exclusive GPU scheduler. `render encode` applies configured LUT, burn-in captions and overlay
slots without rerendering Cycles.

Persist config hash,
git SHA, asset fingerprints, Blender/GPU identity, model/provider versions, image comparison
metrics, and final encoding settings in the run manifest.
