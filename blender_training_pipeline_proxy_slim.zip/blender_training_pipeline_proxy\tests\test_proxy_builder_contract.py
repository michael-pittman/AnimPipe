from __future__ import annotations

from blender_training_pipeline.models import PipelineConfig


def test_prop_attachment_and_camera_template_validate() -> None:
    model = PipelineConfig.model_validate({
        "camera": {
            "template": "medium",
            "templates": {
                "medium": {
                    "lens_mm": 55,
                    "offset": [0, -4, 2],
                    "target_offset": [0, 0, 1.2],
                }
            },
        },
        "props": [{
            "id": "block",
            "asset_id": "prop.block",
            "attachments": [{
                "target_character_id": "char.a",
                "bone": "hand.R",
                "start_frame": 10,
                "end_frame": 20,
                "release_transform": {"location": [1, 2, 3]},
            }],
        }],
    })
    assert model.camera.templates["medium"].target_offset[2] == 1.2
    assert model.props[0].attachments[0].bone == "hand.R"


def test_style_contract_is_part_of_resolved_pipeline() -> None:
    model = PipelineConfig.model_validate({
        "style": {
            "id": "proxy_clay_v1",
            "palette": {"character": [0.4, 0.4, 0.4, 1.0]},
            "shading": {"texture_policy": "none", "roughness": 0.7, "metallic": 0.0},
        }
    })
    assert model.style.id == "proxy_clay_v1"
    assert model.style.shading.texture_policy == "none"
