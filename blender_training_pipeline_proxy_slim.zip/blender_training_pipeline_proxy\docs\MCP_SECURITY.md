# Official Blender MCP Security Boundary

Use only Blender Lab's official MCP server for live inspection.

The MCP executes LLM-generated Python inside Blender without a security sandbox. Therefore it is never part of the production build path.

## Production identity
`anim-build` user/process: repository read/write, canonical assets read-only for builders, build/render scratch write. No live MCP required.

## Debug identity
`anim-mcp` user/process: no cloud credentials, no sudo, repo read-only or absent, canonical assets read-only, write only to MCP scratch. It opens a copied generated `.blend`.

## Workflow

1. deterministic build creates `build/<shot>/scene.blend`
2. copy it to `scratch/mcp/<shot>-debug.blend`
3. open scratch copy in Blender
4. `blender-debugger` uses official MCP to inspect/render/search docs/execute diagnostic code
5. debugger emits a structured patch proposal
6. `blender-builder` or `animation-director` makes the approved source change
7. rebuild from scratch

Never save MCP-mutated state back into canonical `build/`, `assets/`, or the git tree.
