#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export PATH="$HOME/.local/bin:$PATH"
command -v claude >/dev/null || { echo 'Claude Code is not installed' >&2; exit 2; }
command -v pyright-langserver >/dev/null || { echo 'pyright-langserver is not on PATH' >&2; exit 3; }

# Official marketplace is auto-added on first interactive run. Add it explicitly if needed.
claude plugin marketplace add anthropics/claude-plugins-official >/dev/null 2>&1 || true
for plugin in \
  pyright-lsp \
  security-guidance \
  commit-commands \
  pr-review-toolkit \
  plugin-dev \
  skill-creator
do
  claude plugin install "${plugin}@claude-plugins-official" --scope project
done

echo 'Claude project plugins installed. Start/restart Claude Code, or run /reload-plugins in an active session.'
