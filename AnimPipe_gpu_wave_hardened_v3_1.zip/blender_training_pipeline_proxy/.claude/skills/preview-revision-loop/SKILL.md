---
name: preview-revision-loop
description: Governs automated render-inspect-revise QA. Use for single-shot diagnosis or multi-shot wave review. Requires delivery-style evidence, required observable checks, config-only revisions, dirty-shot retries, iteration caps and final-film QA.
---

# Preview → Inspect → Revise

## Multi-shot order
1. compile/audio preparation in parallel
2. preview builds in parallel
3. one dirty-shot Cycles render wave
4. union configured preview frames with all required-observable frames, then encode sparse frames into delivery-style evidence
5. one VLM review wave with the model resident
6. required-observable + score gates
7. apply allow-listed config patches only
8. rebuild/re-render only dirty shots
9. after concat, run final-film deterministic + visual QA

The critic judges delivered pixels. Config claims are not evidence.

Required observables are explicit shot contracts such as a late prop hold, visible face motion or a successful release. A `pass` verdict cannot override a missing required observable or score threshold.

Stop on pass, invalid patch, insufficient improvement, iteration cap, or escalation. Never patch `style.*` or builder/source code from the critic loop.
