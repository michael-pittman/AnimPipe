---
name: gpu-scheduling
description: Single-T4 scheduling and VRAM admission policy. Use before Cycles/OptiX, Ollama vision QA, or NVENC. Requires verified hardware identity, fresh VRAM admission, explicit compute/encode locks, and wave scheduling; never run competing compute workloads opportunistically.
---

# GPU Scheduling

The T4 has one compute resource. Improve throughput by reducing context churn, not by overlapping Cycles and VLM inference.

## Required sequence

```text
verified hardware manifest
  -> CPU preparation may fan out
  -> acquire compute transition lock once
  -> unload any stale VLM residency while lock is held
  -> re-check live VRAM admission
  -> render dirty-shot wave in one Blender process
  -> release compute lock
  -> acquire compute lock once
  -> load VLM once
  -> review dirty-shot wave
  -> unload VLM
  -> repeat only for revised shots
```

Always re-check live GPU UUID/model/VRAM after the compute lock is acquired and after stale VLM residency has been released. Estimated peak memory and reserve come from config.

## Resource classes
- `compute`: Cycles/OptiX and VLM inference; never overlap on the single T4.
- `encode`: NVENC fixed-function work. It may use a separate lock only when `allow_nvenc_overlap_with_compute` is explicitly enabled and measured safe.

## Ollama residency
Keep the VLM loaded across one review wave using `resource_policy.gpu.vision_keep_alive`. Explicitly unload it before the next Cycles wave. Do not preload the VLM before rendering.
