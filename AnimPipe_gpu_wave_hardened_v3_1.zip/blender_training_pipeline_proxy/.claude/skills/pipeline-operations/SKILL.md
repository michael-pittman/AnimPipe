---
name: pipeline-operations
description: Safe execution and publishing rules for validation, build, render, wave QA, concat, evidence export and publish. Enforce gates in order, maximize CPU parallelism, and never bypass hardware/config/asset/QA failures.
---

# Pipeline Operations

Production order:

```text
compile + cached audio/TTS fan-out
-> asset checks
-> parallel preview builds
-> GPU render wave
-> VLM review wave
-> dirty-shot revision waves
-> accepted full-frame render wave
-> parallel encode
-> concat
-> final-film QA
-> evidence bundle
-> publish
```

Render image sequences; never render production directly into a movie container. Preserve structured handoffs and hashes.

Reuse TTS/viseme artifacts when their request fingerprint is unchanged. A per-shot QA pass is not final-film acceptance. The concatenated MP4 must pass stream, silence, freeze/transition and visual-continuity checks.
