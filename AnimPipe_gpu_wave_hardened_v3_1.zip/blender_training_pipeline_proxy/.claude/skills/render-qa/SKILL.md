---
name: render-qa
description: Deterministic and delivered-output QA for preview/final frames and concatenated films. Use for hashes/SSIM/pHash, frame evidence, FFmpeg freeze/silence detection, stream metadata and compact QA evidence export.
---

# Render QA

Use SHA-256 for exact provenance and pHash/SSIM for visual regression. These metrics do not establish semantic correctness.

For delivered film acceptance also inspect:
- ffprobe stream/duration metadata
- FFmpeg `freezedetect` around shot joins
- FFmpeg `silencedetect` for interior dead air
- labeled frames before/after every join
- final-film VLM transition/prop/caption/lip-sync review

A shot fails when any required observable or any scored dimension misses its configured floor, even if the mean score is high. A film fails acceptance when a blocking deterministic check or configured final-film visual score floor fails. Export compact contact sheets + JSON evidence even when full render media is excluded from a slim archive.
