from __future__ import annotations

import json
import zipfile
from pathlib import Path

from blender_training_pipeline.evidence_export import export_qa_evidence
from blender_training_pipeline.final_film_qa import _parse_freezes, _parse_silence
from blender_training_pipeline.models import PipelineConfig, QaObservable
from blender_training_pipeline.qa_evidence import evidence_frame_numbers, remap_sparse_delivery
from blender_training_pipeline.qa_loop import dimension_failures, observable_failures, revision_decision
from blender_training_pipeline.qa_models import (
    ConfigChange,
    DimensionReview,
    ObservableReview,
    VisualReview,
)


def _review(*, observable: ObservableReview | None = None, changes: bool = False) -> VisualReview:
    dim = DimensionReview(grade="pass", note="visible", score=0.90)
    return VisualReview(
        verdict="pass",
        summary="evidence reviewed",
        framing=dim,
        legibility=dim,
        staging=dim,
        lighting=dim,
        continuity=dim,
        instructional_intent=dim,
        observables=[observable] if observable else [],
        changes=(
            [ConfigChange(
                path="camera.lens_mm",
                proposed_value=60.0,
                rationale="improve evidence",
                confidence=0.9,
            )]
            if changes else []
        ),
    )


def test_required_observable_can_block_generic_pass() -> None:
    cfg = PipelineConfig()
    cfg.qa.required_observables = [
        QaObservable(id="pointer_held_late", description="pointer remains in hand", frames=[60, 90, 120])
    ]
    review = _review()
    assert observable_failures(review, cfg)
    action, reason = revision_decision(review, cfg, iteration=0, prior_score=None)
    assert action == "escalate"
    assert "observable" in reason or "evidence" in reason


def test_required_observable_allows_pass_when_visible() -> None:
    cfg = PipelineConfig()
    cfg.qa.required_observables = [
        QaObservable(id="pointer_held_late", description="pointer remains in hand", frames=[60, 90, 120])
    ]
    review = _review(observable=ObservableReview(
        id="pointer_held_late", visible=True, note="stable grip", score=0.91
    ))
    action, _ = revision_decision(review, cfg, iteration=0, prior_score=None)
    assert action == "pass"


def test_required_observable_frames_are_forced_into_evidence() -> None:
    cfg = PipelineConfig.model_validate({
        "render": {"frame_start": 1, "frame_end": 120},
        "preview": {"contact_sheet_frames": [1, 30, 60, 90, 120]},
        "qa": {"required_observables": [{
            "id": "grab",
            "description": "grab transfer",
            "frames": [44, 60],
        }]},
    })
    assert evidence_frame_numbers(cfg) == [1, 30, 44, 60, 90, 120]


def test_one_bad_dimension_cannot_hide_behind_good_mean() -> None:
    cfg = PipelineConfig()
    review = _review()
    review.continuity = DimensionReview(grade="fail", note="prop drift", score=0.40)
    assert dimension_failures(review, cfg)
    action, reason = revision_decision(review, cfg, iteration=0, prior_score=None)
    assert action == "escalate"
    assert "continuity" in reason or "critic" in reason


def test_sparse_delivery_timing_is_remapped() -> None:
    cfg = PipelineConfig.model_validate({
        "render": {"fps": 24, "frame_start": 1, "frame_end": 120},
        "dialogue": [{
            "speaker": "char.a", "text": "hello", "voice_id": "v",
            "start_frame": 10, "end_frame": 100,
        }],
        "comp": {"overlay_slots": [{
            "asset_id": "overlay.a", "start_frame": 30, "end_frame": 90,
            "x": "0", "y": "0",
        }]},
    })
    dialogue, comp, dense = remap_sparse_delivery(cfg, [1, 30, 60, 90, 120])
    assert dense == {1: 1, 30: 2, 60: 3, 90: 4, 120: 5}
    assert dialogue[0]["start_frame"] == 2
    assert dialogue[0]["end_frame"] == 4
    assert comp["overlay_slots"][0]["start_frame"] == 2
    assert comp["overlay_slots"][0]["end_frame"] == 4


def test_ffmpeg_event_parsers_capture_trailing_events() -> None:
    freezes = _parse_freezes(
        "freeze_start: 1.25\nfreeze_duration: 0.8\nfreeze_end: 2.05\nfreeze_start: 8.0\n",
        10.0,
    )
    assert freezes[0] == {"start": 1.25, "end": 2.05, "duration": 0.8}
    assert freezes[1]["end"] == 10.0
    silences = _parse_silence(
        "silence_start: 3.0\nsilence_end: 5.0 | silence_duration: 2.0\n",
        10.0,
    )
    assert silences == [{"start": 3.0, "end": 5.0, "duration": 2.0}]


def test_evidence_export_is_compact_by_default(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)
    evidence = Path("reports/acceptance/evidence/final_film")
    evidence.mkdir(parents=True)
    (evidence / "final-film-contact.png").write_bytes(b"png")
    (evidence / "final-film-qa.json").write_text("{}")
    build = Path("build/proxy_acceptance")
    build.mkdir(parents=True)
    (build / "acceptance_report.json").write_text("{}")
    (build / "proxy_acceptance_film.mp4").write_bytes(b"large-video")
    out = export_qa_evidence()
    with zipfile.ZipFile(out) as archive:
        names = set(archive.namelist())
    assert "evidence/final_film/final-film-contact.png" in names
    assert "proxy_acceptance_film.mp4" not in names
    assert "evidence_manifest.json" in names


def test_release_packager_excludes_runtime_and_keeps_proxy_placeholder() -> None:
    import importlib.util
    from pathlib import Path

    script = Path(__file__).resolve().parents[1] / "scripts" / "120_package_release.py"
    spec = importlib.util.spec_from_file_location("release_packager", script)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    assert module.excluded(Path("infra/kokoro.env"))
    assert module.excluded(Path("build/proxy_acceptance/film.mp4"))
    assert module.excluded(Path("src/pkg/__pycache__/x.pyc"))
    assert module.excluded(Path("reports/acceptance/evidence/final-film-contact.png"))
    assert module.excluded(Path("reports/acceptance/acceptance_results_combined.json"))
    assert module.excluded(Path("reports/acceptance/qa_evidence_bundle.zip"))
    assert not module.excluded(
        Path("reports/acceptance/qa_evidence_bundle.zip"), include_evidence=True
    )
    assert module.excluded(Path("assets/proxy/proxy_character.blend"))
    assert not module.excluded(Path("assets/proxy/.gitkeep"))
    assert not module.excluded(Path("src/blender_training_pipeline/qa_wave.py"))


def test_gpu_policy_includes_transition_wait_defaults() -> None:
    cfg = PipelineConfig()
    assert cfg.resource_policy.gpu.admission_wait_seconds >= 0
    assert cfg.resource_policy.gpu.admission_poll_seconds > 0
    assert cfg.qa.segment_duration_tolerance_seconds >= 0
    assert cfg.qa.audio_start_tolerance_seconds >= 0


def test_gpu_lock_can_wait_for_model_vram_release(tmp_path: Path, monkeypatch) -> None:
    from blender_training_pipeline import gpu_lock as gpu_lock_module
    from blender_training_pipeline.hardware import GpuSnapshot

    snapshots = [
        GpuSnapshot(0, "GPU-x", "Tesla T4", 16384, 5000, "591.59"),
        GpuSnapshot(0, "GPU-x", "Tesla T4", 16384, 5000, "591.59"),
        GpuSnapshot(0, "GPU-x", "Tesla T4", 16384, 15000, "591.59"),
    ]
    calls = {"count": 0}

    def fake_verify(_manifest: Path) -> GpuSnapshot:
        index = min(calls["count"], len(snapshots) - 1)
        calls["count"] += 1
        return snapshots[index]

    monkeypatch.setattr(gpu_lock_module, "verify_live_identity", fake_verify)
    monkeypatch.setattr(gpu_lock_module.time, "sleep", lambda _seconds: None)

    with gpu_lock_module.gpu_lock(
        "cycles_preview",
        estimated_peak_mib=6000,
        reserve_mib=2048,
        timeout_seconds=1,
        manifest_path=tmp_path / "unused.json",
        lock_path=tmp_path / "compute.lock",
        admission_wait_seconds=1.0,
        admission_poll_seconds=0.01,
    ) as gpu:
        assert gpu.memory_free_mib == 15000
    assert calls["count"] >= 3


def test_final_film_helpers_share_blender_frame_clock() -> None:
    from blender_training_pipeline.final_film_qa import (
        _expected_audio_start,
        _expected_segment_duration,
    )

    cfg = PipelineConfig.model_validate({
        "render": {"fps": 24, "frame_start": 1, "frame_end": 120},
        "dialogue": [{
            "speaker": "char.a", "text": "hello", "voice_id": "v",
            "start_frame": 13, "end_frame": 100,
        }],
    })
    assert _expected_segment_duration(cfg) == 5.0
    assert _expected_audio_start(cfg) == 0.5


def test_claude_runtime_model_matches_schema_default() -> None:
    root = Path(__file__).resolve().parents[1]
    claude = (root / "CLAUDE.md").read_text(encoding="utf-8")
    assert "`qwen2.5vl:3b` Azure/T4-proven default" in claude
    assert PipelineConfig().qa.vision_model == "qwen2.5vl:3b"


def test_release_packager_generates_manifest_for_exact_archive_payload(tmp_path: Path) -> None:
    import hashlib
    import importlib.util

    script = Path(__file__).resolve().parents[1] / "scripts" / "120_package_release.py"
    spec = importlib.util.spec_from_file_location("release_packager_manifest", script)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    source = tmp_path / "source"
    source.mkdir()
    (source / "README.md").write_text("hello\n", encoding="utf-8")
    (source / "MANIFEST.sha256").write_text("stale\n", encoding="utf-8")
    (source / "build").mkdir()
    (source / "build" / "runtime.mp4").write_bytes(b"runtime")
    module.ROOT = source

    output = tmp_path / "release.zip"
    packaged, _digest, count = module.package(output, "repo")
    assert packaged == output
    assert count == 2  # README + freshly generated manifest
    with zipfile.ZipFile(output) as archive:
        manifest = archive.read("repo/MANIFEST.sha256").decode("utf-8")
        expected = hashlib.sha256(b"hello\n").hexdigest()
        assert manifest == f"{expected}  README.md\n"
        assert "repo/build/runtime.mp4" not in archive.namelist()


def test_contract_patch_version_bumped_for_hardening_fields() -> None:
    root = Path(__file__).resolve().parents[1]
    assert PipelineConfig().metadata.contract_version == "1.0.1"
    assert (root / "config/schema/VERSION").read_text(encoding="utf-8").strip() == "1.0.1"
