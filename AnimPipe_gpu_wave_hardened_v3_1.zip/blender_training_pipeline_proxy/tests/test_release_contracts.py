from __future__ import annotations

import hashlib
import json
import tomllib
from pathlib import Path

import pytest
from pydantic import ValidationError

from asset_system.models import AssetEntry
import blender_training_pipeline.delivery as delivery
from blender_training_pipeline.delivery import (
    DeliveryError,
    _frame_seconds,
    encode,
    resolve_delivery_asset,
    write_dialogue_srt,
)
from blender_training_pipeline.models import CameraMove, OverlaySlot, PipelineConfig, RenderConfig
from blender_training_pipeline import __version__


def test_asset_path_traversal_rejected() -> None:
    with pytest.raises(ValidationError):
        AssetEntry(kind="overlay", version="1", sha256="x", file="../secret.png")


def test_path_asset_requires_target() -> None:
    with pytest.raises(ValidationError):
        AssetEntry(kind="path", version="1", sha256="x", file="paths/a.blend")


def test_follow_path_requires_asset() -> None:
    with pytest.raises(ValidationError):
        CameraMove(type="follow_path", duration_frames=20)


def test_follow_path_axes_differ() -> None:
    with pytest.raises(ValidationError):
        CameraMove(
            type="follow_path", duration_frames=20, path_asset_id="path.a",
            forward_axis="FORWARD_Z", up_axis="UP_Z",
        )


def test_overlay_expression_injection_rejected() -> None:
    with pytest.raises(ValidationError):
        OverlaySlot(asset_id="overlay.a", start_frame=1, end_frame=10, x="0;movie=/etc/passwd")


def test_blender_eevee_identifier_only() -> None:
    assert RenderConfig(engine="BLENDER_EEVEE").engine == "BLENDER_EEVEE"
    with pytest.raises(ValidationError):
        RenderConfig(engine="BLENDER_EEVEE_NEXT")


def test_gpu_policy_has_no_whisper_cuda_workload() -> None:
    workloads = PipelineConfig().resource_policy.gpu.workloads
    assert "cycles_preview" in workloads
    assert "cycles_final" in workloads
    assert "vision_qa" in workloads
    assert "nvenc" in workloads
    assert "whisper_gpu" not in workloads


def test_srt_explicit_end_required(tmp_path: Path) -> None:
    with pytest.raises(DeliveryError, match="end_frame"):
        write_dialogue_srt(
            [{"start_frame": 24, "text": "hello"}], fps=24, output=tmp_path / "a.srt"
        )


def test_srt_uses_frame_timing(tmp_path: Path) -> None:
    out = write_dialogue_srt(
        [{"start_frame": 24, "end_frame": 48, "text": "hello"}],
        fps=24,
        frame_start=1,
        output=tmp_path / "a.srt",
    )
    text = out.read_text()
    assert "00:00:00,958 --> 00:00:02,000" in text


def test_delivery_frame_clock_starts_at_render_frame_start() -> None:
    assert _frame_seconds(1, fps=24, frame_start=1) == 0.0
    assert _frame_seconds(7, fps=24, frame_start=1) == pytest.approx(0.25)


def test_audio_is_delayed_to_dialogue_frame_clock(tmp_path: Path, monkeypatch) -> None:
    frames = tmp_path / "frames"
    frames.mkdir()
    (frames / "0001.png").write_bytes(b"png")
    audio = tmp_path / "speech.wav"
    audio.write_bytes(b"wav")
    output = tmp_path / "shot.mp4"
    captured: list[str] = []

    class Result:
        returncode = 0
        stderr = ""

    def fake_run(cmd, **_kwargs):
        captured.extend(str(part) for part in cmd)
        output.write_bytes(b"mp4")
        return Result()

    monkeypatch.setattr(delivery.shutil, "which", lambda _name: "/usr/bin/ffmpeg")
    monkeypatch.setattr(delivery.subprocess, "run", fake_run)
    encode(
        frames_dir=frames,
        output=output,
        fps=24,
        frame_start=1,
        codec="libx264",
        audio=audio,
        audio_start_frame=7,
    )
    af = captured[captured.index("-af") + 1]
    assert "adelay=delays=250:all=1" in af
    assert af.endswith("apad")


def test_delivery_asset_resolves_logical_id_and_kind(tmp_path: Path) -> None:
    assets = tmp_path / "assets"
    (assets / "luts").mkdir(parents=True)
    lut = assets / "luts" / "grade.cube"
    lut.write_text("TITLE test\n")
    digest = hashlib.sha256(lut.read_bytes()).hexdigest()
    manifest = tmp_path / "assets.json"
    manifest.write_text(json.dumps({
        "assets": {
            "lut.grade": {
                "kind": "lut", "version": "1", "sha256": digest, "file": "luts/grade.cube"
            }
        }
    }))
    assert resolve_delivery_asset(
        "lut.grade", manifest_path=manifest, assets_root=assets, expected_kind="lut"
    ) == lut.resolve()
    with pytest.raises(DeliveryError, match="kind=overlay"):
        resolve_delivery_asset(
            "lut.grade", manifest_path=manifest, assets_root=assets, expected_kind="overlay"
        )


def test_package_version_consistency() -> None:
    root = Path(__file__).resolve().parents[1]
    with (root / "pyproject.toml").open("rb") as handle:
        pyproject = tomllib.load(handle)
    release = json.loads((root / "RELEASE_INFO.json").read_text(encoding="utf-8"))
    assert pyproject["project"]["version"] == __version__ == release["package_version"]
