from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

from .config_patch import apply_review_candidate
from .delivery import build_shot
from .gpu_lock import gpu_lock
from .models import PipelineConfig
from .ollama_control import load_model, unload_model
from .qa_evidence import build_delivery_evidence, evidence_frame_numbers
from .qa_models import VisualReview
from .render_wave import render_wave
from .vision_review import review_preview


def mean_review_score(review: VisualReview) -> float:
    dimensions = [
        review.framing,
        review.legibility,
        review.staging,
        review.lighting,
        review.continuity,
        review.instructional_intent,
    ]
    return sum(item.score for item in dimensions) / len(dimensions)


def dimension_failures(review: VisualReview, config: PipelineConfig) -> list[str]:
    """Return independently failing visual dimensions.

    A mean score can hide a real continuity defect behind strong lighting or
    framing scores.  Final acceptance therefore treats the configured vision
    threshold as a floor for every scored dimension, not merely the average.
    """
    dimensions = {
        "framing": review.framing,
        "legibility": review.legibility,
        "staging": review.staging,
        "lighting": review.lighting,
        "continuity": review.continuity,
        "instructional_intent": review.instructional_intent,
    }
    failures: list[str] = []
    for name, item in dimensions.items():
        if item.grade == "fail":
            failures.append(f"{name}: critic grade=fail")
        elif item.score < config.qa.vision_pass_threshold:
            failures.append(
                f"{name}: score {item.score:.3f} < {config.qa.vision_pass_threshold:.3f}"
            )
    return failures


def observable_failures(review: VisualReview, config: PipelineConfig) -> list[str]:
    indexed = {item.id: item for item in review.observables}
    failures: list[str] = []
    for required in config.qa.required_observables:
        if not required.required:
            continue
        seen = indexed.get(required.id)
        if seen is None:
            failures.append(f"{required.id}: critic returned no evidence result")
        elif not seen.visible:
            failures.append(f"{required.id}: required evidence not visible")
        elif seen.score < config.qa.observable_pass_threshold:
            failures.append(
                f"{required.id}: score {seen.score:.3f} < "
                f"{config.qa.observable_pass_threshold:.3f}"
            )
    return failures


def revision_decision(
    review: VisualReview,
    config: PipelineConfig,
    *,
    iteration: int,
    prior_score: float | None,
) -> tuple[str, str]:
    score = mean_review_score(review)
    dim_failures = dimension_failures(review, config)
    obs_failures = observable_failures(review, config)

    if review.verdict == "escalate":
        return "escalate", "vision critic requested human escalation"

    if (
        review.verdict == "pass"
        and score >= config.qa.vision_pass_threshold
        and not dim_failures
        and not obs_failures
    ):
        return "pass", "vision critic, dimension floors and required-observable gates passed"

    gate_reasons: list[str] = []
    if score < config.qa.vision_pass_threshold:
        gate_reasons.append(
            f"mean visual score {score:.3f} < {config.qa.vision_pass_threshold:.3f}"
        )
    gate_reasons.extend(dim_failures)
    gate_reasons.extend(obs_failures)

    if iteration >= config.qa.max_revisions:
        return "escalate", (
            f"maximum revision count reached ({config.qa.max_revisions}); "
            + "; ".join(gate_reasons)
        )
    if not review.changes:
        return "escalate", (
            "visual/observable gate failed but critic proposed no config revision: "
            + "; ".join(gate_reasons or [review.summary])
        )
    if prior_score is not None:
        improvement = score - prior_score
        if improvement < config.qa.min_score_improvement:
            return (
                "escalate",
                f"score improvement {improvement:.4f} is below required "
                f"{config.qa.min_score_improvement:.4f}",
            )
    return "revise", "validated config-only revision may proceed"


def _prior_score(path: Path | None) -> float | None:
    if path is None:
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    value = data.get("score")
    return float(value) if value is not None else None


def review_iteration(
    *,
    preview: Path,
    intent: Path,
    resolved_config: Path,
    report: Path,
    candidate_config: Path | None = None,
    iteration: int = 0,
    prior_report: Path | None = None,
    hardware_manifest: Path = Path("reports/environment/hardware-verified.json"),
) -> dict[str, Any]:
    if iteration < 0:
        raise ValueError("iteration must be >= 0")
    raw = json.loads(resolved_config.read_text(encoding="utf-8"))
    config = PipelineConfig.model_validate(raw)
    policy = config.resource_policy.gpu
    workload = policy.workloads["vision_qa"]
    with gpu_lock(
        workload="vision_qa",
        estimated_peak_mib=workload.estimated_peak_mib,
        reserve_mib=policy.reserve_mib,
        timeout_seconds=policy.lock_timeout_seconds,
        manifest_path=hardware_manifest,
        resource="compute",
        admission_wait_seconds=policy.admission_wait_seconds,
        admission_poll_seconds=policy.admission_poll_seconds,
    ):
        load_model(config.qa.vision_model, keep_alive=policy.vision_keep_alive)
        try:
            review = review_preview(
                preview,
                intent.read_text(encoding="utf-8"),
                resolved_config.read_text(encoding="utf-8"),
                model=config.qa.vision_model,
                keep_alive=policy.vision_keep_alive,
            )
        finally:
            unload_model(config.qa.vision_model, tolerate_unavailable=True)
    score = mean_review_score(review)
    prior_score = _prior_score(prior_report)
    action, reason = revision_decision(review, config, iteration=iteration, prior_score=prior_score)
    result: dict[str, Any] = {
        "iteration": iteration,
        "critic_verdict": review.verdict,
        "action": action,
        "reason": reason,
        "score": score,
        "prior_score": prior_score,
        "dimension_failures": dimension_failures(review, config),
        "observable_failures": observable_failures(review, config),
        "review": review.model_dump(mode="json"),
    }
    if action == "revise" and candidate_config is not None:
        candidate = apply_review_candidate(raw, review)
        candidate_config.parent.mkdir(parents=True, exist_ok=True)
        candidate_config.write_text(
            json.dumps(candidate, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        result["candidate_config"] = str(candidate_config)
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result


def run_loop(
    *,
    resolved_config: Path,
    intent: Path,
    asset_manifest: Path,
    assets_root: Path,
    work_dir: Path,
    hardware_manifest: Path = Path("reports/environment/hardware-verified.json"),
    keep_frames: bool = False,
) -> dict[str, Any]:
    """Bounded single-shot preview→inspect→revise loop.

    Proxy acceptance uses the multi-shot wave scheduler; this function remains a
    useful diagnostic primitive for one shot and uses the same evidence gates.
    """
    work_dir.mkdir(parents=True, exist_ok=True)
    current = work_dir / "resolved-r0.json"
    shutil.copy2(resolved_config, current)
    prior_report: Path | None = None
    history: list[dict[str, Any]] = []

    while True:
        iteration = len(history)
        raw = json.loads(current.read_text(encoding="utf-8"))
        cfg = PipelineConfig.model_validate(raw)
        blend = work_dir / f"preview-r{iteration}.blend"
        build_report_path = work_dir / f"build-r{iteration}.json"
        build_report = build_shot(
            config=current,
            manifest=asset_manifest,
            output=blend,
            assets_root=assets_root,
            preview=True,
            report=build_report_path,
        )
        if build_report.get("status") != "ok":
            return {
                "status": "escalate",
                "reason": "preview build failed",
                "history": history,
                "build": build_report,
            }

        frames_dir = work_dir / f"frames-r{iteration}"
        frames = evidence_frame_numbers(cfg)
        wave = render_wave(
            jobs=[{
                "shot_id": cfg.metadata.shot_id,
                "blend": str(blend),
                "output_dir": str(frames_dir),
                "frames": frames,
            }],
            config=cfg,
            work_dir=work_dir / f"render-wave-r{iteration}",
            preview=True,
            hardware_manifest=hardware_manifest,
        )
        _ = wave
        rendered = sorted(frames_dir.glob("*.png"))
        evidence = build_delivery_evidence(
            rendered_frames=rendered,
            cfg=cfg,
            work_dir=work_dir / f"evidence-r{iteration}",
            asset_manifest=asset_manifest,
            assets_root=assets_root,
        )
        review_report = work_dir / f"review-r{iteration}.json"
        candidate = work_dir / f"resolved-r{iteration + 1}.json"
        result = review_iteration(
            preview=Path(evidence["contact_sheet"]),
            intent=intent,
            resolved_config=current,
            report=review_report,
            candidate_config=candidate,
            iteration=iteration,
            prior_report=prior_report,
            hardware_manifest=hardware_manifest,
        )
        history.append(result)
        if not keep_frames:
            shutil.rmtree(frames_dir, ignore_errors=True)
        if result["action"] != "revise":
            final = {
                "status": result["action"],
                "reason": result["reason"],
                "iterations": iteration + 1,
                "final_config": str(current),
                "final_blend": str(blend),
                "history": history,
            }
            (work_dir / "qa-loop.json").write_text(
                json.dumps(final, indent=2, sort_keys=True) + "\n", encoding="utf-8"
            )
            return final
        prior_report = review_report
        current = candidate
