from __future__ import annotations

import json
import re
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from .delivery import contact_sheet, ffprobe_json, sample_video_times
from .gpu_lock import gpu_lock
from .models import PipelineConfig
from .ollama_control import load_model, unload_model, wait_for_inference
from .vision_review import review_final_film


_FREEZE_START = re.compile(r"freeze_start:\s*([0-9.]+)")
_FREEZE_END = re.compile(r"freeze_end:\s*([0-9.]+)")
_FREEZE_DURATION = re.compile(r"freeze_duration:\s*([0-9.]+)")
_SILENCE_START = re.compile(r"silence_start:\s*([0-9.]+)")
_SILENCE_END = re.compile(r"silence_end:\s*([0-9.]+)")
_SILENCE_DURATION = re.compile(r"silence_duration:\s*([0-9.]+)")


class FinalFilmQAError(RuntimeError):
    pass


def _run_filter(video: Path, *, video_filter: str | None = None, audio_filter: str | None = None) -> str:
    if shutil.which("ffmpeg") is None:
        raise FinalFilmQAError("ffmpeg not found")
    cmd = ["ffmpeg", "-hide_banner", "-nostats", "-i", str(video)]
    if video_filter:
        cmd += ["-vf", video_filter]
    if audio_filter:
        cmd += ["-af", audio_filter]
    cmd += ["-f", "null", "-"]
    proc = subprocess.run(cmd, check=False, capture_output=True, text=True)
    # Detection filters normally exit 0 and log to stderr. Preserve the text even
    # on a non-zero exit so the evidence bundle can explain the failure.
    return proc.stderr


def _parse_freezes(text: str, film_duration: float) -> list[dict[str, float]]:
    starts = [float(v) for v in _FREEZE_START.findall(text)]
    ends = [float(v) for v in _FREEZE_END.findall(text)]
    durations = [float(v) for v in _FREEZE_DURATION.findall(text)]
    events: list[dict[str, float]] = []
    for index, start in enumerate(starts):
        end = ends[index] if index < len(ends) else film_duration
        duration = durations[index] if index < len(durations) else max(0.0, end - start)
        events.append({"start": start, "end": end, "duration": duration})
    return events


def _parse_silence(text: str, film_duration: float) -> list[dict[str, float]]:
    starts = [float(v) for v in _SILENCE_START.findall(text)]
    ends = [float(v) for v in _SILENCE_END.findall(text)]
    durations = [float(v) for v in _SILENCE_DURATION.findall(text)]
    events: list[dict[str, float]] = []
    for index, start in enumerate(starts):
        end = ends[index] if index < len(ends) else film_duration
        duration = durations[index] if index < len(durations) else max(0.0, end - start)
        events.append({"start": start, "end": end, "duration": duration})
    return events


def _duration(probe: dict[str, Any]) -> float:
    value = (probe.get("format") or {}).get("duration")
    if value is not None:
        return float(value)
    stream_values = [s.get("duration") for s in probe.get("streams", []) if s.get("duration")]
    return max((float(v) for v in stream_values), default=0.0)


def _stream_types(probe: dict[str, Any]) -> set[str]:
    return {str(stream.get("codec_type")) for stream in probe.get("streams", [])}


def _stream_signature(probe: dict[str, Any]) -> dict[str, Any]:
    """Return concat-relevant stream properties without volatile metadata."""
    result: dict[str, Any] = {}
    for stream in probe.get("streams", []):
        kind = str(stream.get("codec_type"))
        if kind == "video":
            result["video"] = {
                "codec": stream.get("codec_name"),
                "width": stream.get("width"),
                "height": stream.get("height"),
                "pix_fmt": stream.get("pix_fmt"),
                "r_frame_rate": stream.get("r_frame_rate"),
                "time_base": stream.get("time_base"),
            }
        elif kind == "audio":
            result["audio"] = {
                "codec": stream.get("codec_name"),
                "sample_rate": stream.get("sample_rate"),
                "channels": stream.get("channels"),
                "channel_layout": stream.get("channel_layout"),
                "time_base": stream.get("time_base"),
            }
    return result


def _join_times(segment_probes: list[dict[str, Any]]) -> list[float]:
    result: list[float] = []
    total = 0.0
    for probe in segment_probes[:-1]:
        total += _duration(probe)
        result.append(total)
    return result


def _event_crosses_join(event: dict[str, float], joins: list[float], tolerance: float = 0.12) -> bool:
    return any(event["start"] <= join + tolerance and event["end"] >= join - tolerance for join in joins)


def _expected_segment_duration(cfg: PipelineConfig) -> float:
    return (cfg.render.frame_end - cfg.render.frame_start + 1) / float(cfg.render.fps)


def _expected_audio_start(cfg: PipelineConfig) -> float | None:
    if not cfg.dialogue:
        return None
    return max(0.0, (cfg.dialogue[0].start_frame - cfg.render.frame_start) / float(cfg.render.fps))


def _leading_silence_end(events: list[dict[str, float]]) -> float:
    if events and events[0]["start"] <= 0.05:
        return float(events[0]["end"])
    return 0.0


def run_final_film_qa(
    *,
    film: Path,
    segments: list[Path],
    config: PipelineConfig,
    evidence_dir: Path,
    hardware_manifest: Path,
    expect_audio: bool,
    shot_configs: list[PipelineConfig] | None = None,
) -> dict[str, Any]:
    """QA the actual concatenated film, not only its source shots.

    Deterministic checks run first and cover streams, segment compatibility,
    expected frame-clock durations, join freezes, interior dead air, and dialogue
    onset. A transition-focused VLM then evaluates the delivered pixels.
    """
    evidence_dir.mkdir(parents=True, exist_ok=True)
    probe = ffprobe_json(film)
    segment_probes = [ffprobe_json(path) for path in segments]
    duration = _duration(probe)
    joins = _join_times(segment_probes)
    streams = _stream_types(probe)

    if shot_configs is not None and len(shot_configs) != len(segments):
        raise FinalFilmQAError(
            f"shot config count {len(shot_configs)} does not match segment count {len(segments)}"
        )

    with ThreadPoolExecutor(max_workers=2) as pool:
        freeze_future = pool.submit(
            _run_filter,
            film,
            video_filter=f"freezedetect=n=0.001:d={config.qa.freeze_duration_seconds}",
        )
        silence_future = None
        if "audio" in streams:
            silence_future = pool.submit(
                _run_filter,
                film,
                audio_filter=(
                    f"silencedetect=n={config.qa.silence_noise_db}dB:"
                    f"d={config.qa.silence_duration_seconds}"
                ),
            )
        freeze_text = freeze_future.result()
        silence_text = silence_future.result() if silence_future else ""

    # Preserve raw detector output so a false positive/negative can be diagnosed
    # without rerunning the full film.
    (evidence_dir / "freezedetect.log").write_text(freeze_text, encoding="utf-8")
    (evidence_dir / "silencedetect.log").write_text(silence_text, encoding="utf-8")

    freezes = _parse_freezes(freeze_text, duration)
    silences = _parse_silence(silence_text, duration)
    boundary_freezes = [event for event in freezes if _event_crosses_join(event, joins)]
    # Ignore tiny start/end padding, but interior long silence is a training-film defect.
    interior_silences = [
        event for event in silences
        if event["start"] > 0.30 and event["end"] < max(0.0, duration - 0.30)
    ]

    segment_durations = [_duration(item) for item in segment_probes]
    signatures = [_stream_signature(item) for item in segment_probes]
    signature_mismatches: list[dict[str, Any]] = []
    if signatures:
        reference = signatures[0]
        for index, signature in enumerate(signatures[1:], start=2):
            if signature != reference:
                signature_mismatches.append({
                    "segment": index,
                    "reference": reference,
                    "actual": signature,
                })

    duration_mismatches: list[dict[str, float | int]] = []
    audio_start_mismatches: list[dict[str, float | int]] = []
    segment_silence_events: list[list[dict[str, float]]] = [[] for _ in segments]
    if shot_configs is not None:
        for index, (cfg, actual) in enumerate(zip(shot_configs, segment_durations, strict=True), start=1):
            expected = _expected_segment_duration(cfg)
            delta = actual - expected
            if abs(delta) > cfg.qa.segment_duration_tolerance_seconds:
                duration_mismatches.append({
                    "segment": index,
                    "expected_seconds": expected,
                    "actual_seconds": actual,
                    "delta_seconds": delta,
                })

        if expect_audio:
            # Segment-local silence analysis directly verifies that the muxed WAV
            # begins on the same authored frame clock as captions/visemes.
            with ThreadPoolExecutor(max_workers=2) as pool:
                futures = {}
                for index, segment in enumerate(segments):
                    if "audio" not in _stream_types(segment_probes[index]):
                        continue
                    futures[pool.submit(
                        _run_filter,
                        segment,
                        audio_filter=(
                            f"silencedetect=n={config.qa.silence_noise_db}dB:"
                            "d=0.05"
                        ),
                    )] = index
                for future in as_completed(futures):
                    index = futures[future]
                    text = future.result()
                    (evidence_dir / f"segment-{index + 1:02d}-silencedetect.log").write_text(
                        text, encoding="utf-8"
                    )
                    segment_silence_events[index] = _parse_silence(text, segment_durations[index])

            for index, cfg in enumerate(shot_configs, start=1):
                expected_start = _expected_audio_start(cfg)
                if expected_start is None:
                    continue
                actual_start = _leading_silence_end(segment_silence_events[index - 1])
                delta = actual_start - expected_start
                if abs(delta) > cfg.qa.audio_start_tolerance_seconds:
                    audio_start_mismatches.append({
                        "segment": index,
                        "expected_seconds": expected_start,
                        "actual_seconds": actual_start,
                        "delta_seconds": delta,
                    })

    # Sample both global progression and both sides of every shot join.
    sample_times: list[float] = []
    labels: list[str] = []
    if duration > 0:
        for frac in (0.02, 0.25, 0.50, 0.75, 0.98):
            sample_times.append(duration * frac)
            labels.append(f"film {frac:.0%}")
    transition_labels: list[str] = []
    for index, join in enumerate(joins, start=1):
        before = max(0.0, join - 0.18)
        after = min(duration, join + 0.18)
        sample_times.extend([before, after])
        left = f"join {index} before"
        right = f"join {index} after"
        labels.extend([left, right])
        transition_labels.append(f"join-{index}")

    sampled_dir = evidence_dir / "sampled"
    frames = sample_video_times(video=film, times=sample_times, output_dir=sampled_dir, prefix="film")
    sheet = evidence_dir / "final-film-contact.png"
    # Keep the T4-proven small VLM within a compact visual token budget.
    columns = 5 if len(frames) >= 15 else 4
    thumb_width = max(160, 960 // columns)
    contact_sheet(
        frames=frames,
        output=sheet,
        columns=columns,
        thumb_width=thumb_width,
        labels=labels,
    )
    shutil.rmtree(sampled_dir, ignore_errors=True)

    deterministic = {
        "film": str(film),
        "duration_seconds": duration,
        "stream_types": sorted(streams),
        "shot_join_seconds": joins,
        "segment_durations_seconds": segment_durations,
        "segment_stream_signatures": signatures,
        "signature_mismatches": signature_mismatches,
        "duration_mismatches": duration_mismatches,
        "audio_start_mismatches": audio_start_mismatches,
        "freeze_events": freezes,
        "boundary_freezes": boundary_freezes,
        "silence_events": silences,
        "interior_silences": interior_silences,
        "expect_audio": expect_audio,
        "has_audio": "audio" in streams,
        "has_video": "video" in streams,
    }
    (evidence_dir / "film-probe.json").write_text(json.dumps(probe, indent=2) + "\n")
    (evidence_dir / "deterministic-film-qa.json").write_text(
        json.dumps(deterministic, indent=2, sort_keys=True) + "\n"
    )

    policy = config.resource_policy.gpu
    workload = policy.workloads["vision_qa"]
    with gpu_lock(
        workload="final_film_vision_qa",
        estimated_peak_mib=workload.estimated_peak_mib,
        reserve_mib=policy.reserve_mib,
        timeout_seconds=policy.lock_timeout_seconds,
        manifest_path=hardware_manifest,
        resource="compute",
        admission_wait_seconds=policy.admission_wait_seconds,
        admission_poll_seconds=policy.admission_poll_seconds,
    ):
        load_model(config.qa.vision_model, keep_alive=policy.vision_keep_alive)
        try:
            if not wait_for_inference(
                config.qa.vision_model,
                keep_alive=policy.vision_keep_alive,
                timeout_s=120.0,
            ):
                raise FinalFilmQAError(
                    f"VLM model '{config.qa.vision_model}' did not become inference-ready for final-film QA"
                )
            visual = review_final_film(
                sheet,
                transition_labels=transition_labels,
                deterministic_summary=deterministic,
                model=config.qa.vision_model,
                keep_alive=policy.vision_keep_alive,
                ensure_ready=False,
            )
        finally:
            # Always tear down the VLM before releasing the single-GPU compute lock,
            # including error/escalation paths. The next Cycles admission waits for
            # the live VRAM reading to confirm that model memory has actually drained.
            unload_model(config.qa.vision_model, tolerate_unavailable=True)
    visual_payload = visual.model_dump(mode="json")
    (evidence_dir / "final-film-visual-review.json").write_text(
        json.dumps(visual_payload, indent=2, sort_keys=True) + "\n"
    )

    # Final-film sampling is transition-focused; lip sync is already a required
    # per-shot observable and is informational here.
    blocking_visual_scores = [
        visual.transition_continuity.score,
        visual.caption_legibility.score,
        visual.prop_continuity.score,
        visual.visual_coherence.score,
    ]
    blockers: list[str] = []
    if "video" not in streams:
        blockers.append("final film has no video stream")
    if expect_audio and "audio" not in streams:
        blockers.append("final film has no audio stream")
    if signature_mismatches:
        blockers.append(f"{len(signature_mismatches)} segment stream signature mismatch(es)")
    if duration_mismatches:
        blockers.append(f"{len(duration_mismatches)} segment duration mismatch(es)")
    if audio_start_mismatches:
        blockers.append(f"{len(audio_start_mismatches)} dialogue audio-start mismatch(es)")
    if boundary_freezes:
        blockers.append(f"{len(boundary_freezes)} frozen interval(s) cross shot joins")
    if interior_silences:
        blockers.append(f"{len(interior_silences)} long interior silence interval(s) detected")
    if visual.verdict != "pass":
        blockers.append("final-film VLM requested escalation")
    if min(blocking_visual_scores) < config.qa.vision_pass_threshold:
        blockers.append(
            f"final-film visual score floor {min(blocking_visual_scores):.3f} < "
            f"{config.qa.vision_pass_threshold:.3f}"
        )

    result = {
        "status": "pass" if not blockers else "escalate",
        "blockers": blockers,
        "deterministic": deterministic,
        "visual": visual_payload,
        "contact_sheet": str(sheet),
    }
    (evidence_dir / "final-film-qa.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return result
