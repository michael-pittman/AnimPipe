from __future__ import annotations

import base64
import io
import json
import time
from pathlib import Path
from typing import Any, TypeVar

import httpx
from PIL import Image
from pydantic import BaseModel

from .ollama_control import model_available, wait_for_inference
from .qa_models import FinalFilmVisualReview, VisualReview


class ModelUnavailableError(RuntimeError):
    """Raised when the configured VLM is unavailable or cannot answer."""


T = TypeVar("T", bound=BaseModel)


def _encoded_image(image: Path, *, max_width: int = 960) -> str:
    source = Image.open(image).convert("RGB")
    if source.width > max_width:
        scale = max_width / source.width
        source = source.resize(
            (max(1, int(source.width * scale)), max(1, int(source.height * scale))),
            Image.Resampling.LANCZOS,
        )
    buffer = io.BytesIO()
    source.save(buffer, format="JPEG", quality=90, optimize=True)
    return base64.b64encode(buffer.getvalue()).decode("ascii")


def _config_summary(resolved_config_text: str) -> str:
    try:
        cfg = json.loads(resolved_config_text)
        keys = (
            "metadata", "camera", "lighting", "comp", "preview", "render", "style", "qa",
            "dialogue", "props", "blocking", "cast",
        )
        return json.dumps({key: cfg[key] for key in keys if key in cfg}, indent=2)
    except Exception:
        return resolved_config_text


def _structured_image_chat(
    *,
    image: Path,
    prompt: str,
    schema: type[T],
    model: str,
    base_url: str,
    keep_alive: str | int,
    num_ctx: int = 12288,
    num_predict: int = 2048,
    ensure_ready: bool = True,
) -> T:
    if not model_available(model, base_url):
        raise ModelUnavailableError(
            f"Ollama model '{model}' is not available at {base_url}; pull it before visual QA"
        )
    if ensure_ready and not wait_for_inference(
        model, base_url=base_url, keep_alive=keep_alive, timeout_s=120.0
    ):
        raise ModelUnavailableError(
            f"Ollama model '{model}' did not become inference-ready within 120 seconds"
        )

    payload = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": prompt,
                "images": [_encoded_image(image)],
            }
        ],
        "format": schema.model_json_schema(),
        "stream": False,
        "keep_alive": keep_alive,
        "options": {
            "temperature": 0,
            "num_ctx": num_ctx,
            "num_predict": num_predict,
            "seed": 7,
        },
    }

    last_error: Exception | None = None
    for attempt in range(3):
        try:
            with httpx.Client(timeout=300.0) as client:
                response = client.post(f"{base_url}/api/chat", json=payload)
                response.raise_for_status()
                content = response.json()["message"]["content"]
                return schema.model_validate_json(content)
        except Exception as exc:
            last_error = exc
            if attempt == 2:
                break
            time.sleep(4.0 * (attempt + 1))
    raise ModelUnavailableError(f"VLM review failed after retries: {last_error}")


def review_preview(
    image: Path,
    intent_text: str,
    resolved_config_text: str,
    model: str = "qwen2.5vl:3b",
    base_url: str = "http://127.0.0.1:11434",
    *,
    keep_alive: str | int = "10m",
    ensure_ready: bool = True,
) -> VisualReview:
    config_text = _config_summary(resolved_config_text)
    try:
        cfg = json.loads(resolved_config_text)
        observables = (cfg.get("qa") or {}).get("required_observables") or []
    except Exception:
        observables = []
    observable_text = json.dumps(observables, indent=2) if observables else "[]"

    prompt = (
        "You are the visual QA critic for an instructional Blender animation. "
        "The image is a labeled contact sheet sampled from the DELIVERED encoded shot, so captions "
        "and overlays in the image are part of the result. Judge only visible evidence. "
        "Score framing, legibility, staging, lighting, continuity, and instructional intent independently. "
        "Do not give identical scores by habit. If evidence is ambiguous, use warn/fail and lower the score. "
        "For every required observable, emit exactly one observables entry with the same id and say whether "
        "the evidence is actually visible. A required interaction is not satisfied merely because config says it exists. "
        "For prop continuity, inspect the earliest and latest labeled evidence frames and reject hand/prop drift, "
        "torso-crossing artifacts, unexplained teleportation, or unstable grips. "
        "For lip-sync or facial observables, require visible pose/expression differences across evidence frames. "
        "Honor the resolved style contract; for proxy_clay_v1 do not reward realism, texture detail, or decorative complexity. "
        "Never propose changes to style.*. Propose only configuration changes, never code. "
        "If the visible evidence contradicts the config, trust the pixels. "
        "All scores and change confidences are floats from 0.0 to 1.0. Notes must be under 24 words; "
        "summary under 48 words.\n\n"
        f"DIRECTOR INTENT:\n{intent_text}\n\n"
        f"REQUIRED OBSERVABLES:\n{observable_text}\n\n"
        f"RESOLVED CONFIG:\n{config_text}"
    )
    return _structured_image_chat(
        image=image,
        prompt=prompt,
        schema=VisualReview,
        model=model,
        base_url=base_url,
        keep_alive=keep_alive,
        ensure_ready=ensure_ready,
    )


def review_final_film(
    image: Path,
    *,
    transition_labels: list[str],
    deterministic_summary: dict[str, Any],
    model: str = "qwen2.5vl:3b",
    base_url: str = "http://127.0.0.1:11434",
    keep_alive: str | int = "10m",
    ensure_ready: bool = True,
) -> FinalFilmVisualReview:
    prompt = (
        "You are the FINAL-FILM visual QA critic for a portrait instructional animation. "
        "The image is a labeled evidence sheet sampled from the concatenated delivered MP4, including frames "
        "before and after shot joins. Judge the delivered film, not the source config. "
        "Check transition continuity, caption legibility, prop continuity, and overall visual coherence. "
        "Report lip-sync/facial-motion visibility as informational evidence only: the transition-focused sheet may not "
        "sample enough mouth motion, so do not escalate solely because lip sync is ambiguous. "
        "Pay special attention to prop ownership and hand position around transitions. "
        "A shot-level QA pass is not evidence that the final film is correct. "
        "If evidence is ambiguous, escalate. Scores are 0.0-1.0 and must be independently calibrated. "
        "Return transition ids from the provided label list when suspicious.\n\n"
        f"TRANSITION LABELS:\n{json.dumps(transition_labels, indent=2)}\n\n"
        f"DETERMINISTIC FILM CHECKS:\n{json.dumps(deterministic_summary, indent=2)}"
    )
    return _structured_image_chat(
        image=image,
        prompt=prompt,
        schema=FinalFilmVisualReview,
        model=model,
        base_url=base_url,
        keep_alive=keep_alive,
        ensure_ready=ensure_ready,
    )
