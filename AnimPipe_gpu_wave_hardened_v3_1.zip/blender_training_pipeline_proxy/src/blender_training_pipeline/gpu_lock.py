from __future__ import annotations

import argparse
import json
import os
import subprocess
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Callable, Iterator

from filelock import FileLock, Timeout as FileLockTimeout

from .hardware import GpuSnapshot, snapshot_dict, verify_live_identity

DEFAULT_MANIFEST = Path("reports/environment/hardware-verified.json")
DEFAULT_LOCK_DIR = Path("scratch/locks")


def _lock_path(resource: str) -> Path:
    safe = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in resource)
    return DEFAULT_LOCK_DIR / f"gpu.{safe}.lock"


@contextmanager
def gpu_lock(
    workload: str,
    estimated_peak_mib: int,
    reserve_mib: int,
    timeout_seconds: int,
    manifest_path: Path = DEFAULT_MANIFEST,
    lock_path: Path | None = None,
    state_path: Path | None = None,
    *,
    resource: str = "compute",
    before_admission: Callable[[], None] | None = None,
    admission_wait_seconds: float = 0.0,
    admission_poll_seconds: float = 1.0,
) -> Iterator[GpuSnapshot]:
    """Cross-platform GPU admission + resource lock.

    Cycles and VLM inference share ``resource=compute`` and therefore never run
    concurrently on the single T4. NVENC may use ``resource=encode`` when the
    policy explicitly allows fixed-function encode overlap; live VRAM is still
    rechecked after lock acquisition.
    """
    gpu = verify_live_identity(manifest_path)
    required = int(estimated_peak_mib) + int(reserve_mib)
    if required > gpu.memory_total_mib:
        raise RuntimeError(
            f"VRAM admission failed: estimate {estimated_peak_mib} + reserve {reserve_mib} "
            f"> total {gpu.memory_total_mib} MiB"
        )

    path = lock_path or _lock_path(resource)
    state = state_path or path.with_suffix(".json")
    path.parent.mkdir(parents=True, exist_ok=True)
    lock = FileLock(str(path))
    try:
        lock.acquire(timeout=timeout_seconds)
    except FileLockTimeout as exc:
        raise TimeoutError(f"timed out waiting for GPU {resource} lock: {workload}") from exc

    try:
        # Some transitions need to free the previous GPU resident while holding
        # the same compute lock that protects the next workload.  Running that
        # cleanup here avoids a race where another process could acquire/use the
        # T4 between model unload and VRAM admission.
        if before_admission is not None:
            before_admission()
        gpu = verify_live_identity(manifest_path)
        deadline = time.monotonic() + max(0.0, float(admission_wait_seconds))
        while gpu.memory_free_mib < required and time.monotonic() < deadline:
            time.sleep(max(0.05, float(admission_poll_seconds)))
            gpu = verify_live_identity(manifest_path)
        if gpu.memory_free_mib < required:
            raise RuntimeError(
                f"VRAM admission failed after lock: free {gpu.memory_free_mib} MiB < "
                f"required {required} MiB for {workload} after waiting "
                f"{float(admission_wait_seconds):.1f}s"
            )
        payload = {
            "pid": os.getpid(),
            "resource": resource,
            "workload": workload,
            "estimated_peak_mib": estimated_peak_mib,
            "reserve_mib": reserve_mib,
            "gpu": snapshot_dict(gpu),
            "acquired_epoch": time.time(),
        }
        state.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        yield gpu
    finally:
        state.unlink(missing_ok=True)
        lock.release()


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)
    run = sub.add_parser("run")
    run.add_argument("--workload", required=True)
    run.add_argument("--resource", choices=["compute", "encode"], default="compute")
    run.add_argument("--estimated-peak-mib", type=int, required=True)
    run.add_argument("--reserve-mib", type=int, required=True)
    run.add_argument("--timeout-seconds", type=int, default=3600)
    run.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command and args.command[0] == "--" else args.command
    if not command:
        raise SystemExit("command required after --")
    with gpu_lock(
        args.workload,
        args.estimated_peak_mib,
        args.reserve_mib,
        args.timeout_seconds,
        resource=args.resource,
    ):
        raise SystemExit(subprocess.call(command))


if __name__ == "__main__":
    main()
