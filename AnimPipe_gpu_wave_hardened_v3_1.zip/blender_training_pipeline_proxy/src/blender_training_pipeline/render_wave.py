from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

from .gpu_lock import gpu_lock
from .models import PipelineConfig
from .ollama_control import unload_model


class RenderWaveError(RuntimeError):
    pass


def render_wave(
    *,
    jobs: list[dict[str, Any]],
    config: PipelineConfig,
    work_dir: Path,
    preview: bool,
    hardware_manifest: Path,
    blender: str = "blender",
) -> dict[str, Any]:
    if not jobs:
        return {"status": "ok", "jobs": []}
    work_dir.mkdir(parents=True, exist_ok=True)
    jobs_file = work_dir / "render-wave-jobs.json"
    report_file = work_dir / "render-wave-report.json"
    jobs_file.write_text(json.dumps({"jobs": jobs}, indent=2) + "\n", encoding="utf-8")

    policy = config.resource_policy.gpu
    workload_name = "cycles_preview" if preview else "cycles_final"
    workload = policy.workloads[workload_name]

    with gpu_lock(
        workload=workload_name,
        estimated_peak_mib=workload.estimated_peak_mib,
        reserve_mib=policy.reserve_mib,
        timeout_seconds=policy.lock_timeout_seconds,
        manifest_path=hardware_manifest,
        resource="compute",
        admission_wait_seconds=policy.admission_wait_seconds,
        admission_poll_seconds=policy.admission_poll_seconds,
        before_admission=lambda: unload_model(
            config.qa.vision_model, tolerate_unavailable=True
        ),
    ):
        proc = subprocess.run(
            [
                blender, "--background", "--factory-startup", "--python",
                "scripts/render_wave_blender.py", "--", "--jobs", str(jobs_file),
                "--report", str(report_file),
            ],
            check=False,
        )
    if not report_file.exists():
        raise RenderWaveError(f"render wave produced no report (exit {proc.returncode})")
    report = json.loads(report_file.read_text(encoding="utf-8"))
    if report.get("status") != "ok":
        raise RenderWaveError(f"render wave failed: {report.get('error', report)}")
    return report
