from __future__ import annotations

import time
from typing import Any

import httpx


class OllamaControlError(RuntimeError):
    pass


def model_available(model: str, base_url: str = "http://127.0.0.1:11434") -> bool:
    try:
        with httpx.Client(timeout=10.0) as client:
            response = client.get(f"{base_url}/api/tags")
            response.raise_for_status()
            names = {str(item.get("name", "")) for item in response.json().get("models", [])}
            return model in names
    except Exception:
        return False


def set_model_residency(
    model: str,
    *,
    keep_alive: str | int,
    base_url: str = "http://127.0.0.1:11434",
    timeout_s: float = 60.0,
) -> dict[str, Any]:
    """Load or unload a model with an empty chat request.

    Ollama documents an empty messages list as the load/unload control path:
    keep_alive=0 unloads, while a negative value keeps the model resident.
    """
    payload = {"model": model, "messages": [], "stream": False, "keep_alive": keep_alive}
    with httpx.Client(timeout=timeout_s) as client:
        response = client.post(f"{base_url}/api/chat", json=payload)
        response.raise_for_status()
        return response.json()


def load_model(
    model: str,
    *,
    keep_alive: str | int = "10m",
    base_url: str = "http://127.0.0.1:11434",
) -> dict[str, Any]:
    return set_model_residency(model, keep_alive=keep_alive, base_url=base_url)


def unload_model(
    model: str,
    *,
    base_url: str = "http://127.0.0.1:11434",
    tolerate_unavailable: bool = True,
) -> dict[str, Any] | None:
    try:
        return set_model_residency(model, keep_alive=0, base_url=base_url)
    except Exception:
        if tolerate_unavailable:
            return None
        raise


def wait_for_inference(
    model: str,
    *,
    base_url: str = "http://127.0.0.1:11434",
    keep_alive: str | int = "10m",
    timeout_s: float = 120.0,
) -> bool:
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        try:
            with httpx.Client(timeout=20.0) as client:
                response = client.post(
                    f"{base_url}/api/chat",
                    json={
                        "model": model,
                        "messages": [{"role": "user", "content": "Reply with ready."}],
                        "stream": False,
                        "keep_alive": keep_alive,
                        "options": {"num_predict": 2, "temperature": 0},
                    },
                )
                if response.status_code == 200:
                    return True
        except Exception:
            pass
        time.sleep(3.0)
    return False
