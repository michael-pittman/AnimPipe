from __future__ import annotations

import json
import zipfile
from pathlib import Path


class EvidenceExportError(RuntimeError):
    pass


def export_qa_evidence(
    *,
    output: Path = Path("reports/acceptance/qa_evidence_bundle.zip"),
    evidence_dir: Path = Path("reports/acceptance/evidence"),
    acceptance_report: Path = Path("build/proxy_acceptance/acceptance_report.json"),
    film: Path = Path("build/proxy_acceptance/proxy_acceptance_film.mp4"),
    logs_dir: Path = Path("logs"),
    include_video: bool = False,
    max_log_bytes: int = 2_000_000,
) -> Path:
    if not evidence_dir.exists():
        raise EvidenceExportError(
            f"QA evidence directory does not exist: {evidence_dir}; run proxy acceptance with QA first"
        )
    output.parent.mkdir(parents=True, exist_ok=True)
    candidates: list[tuple[Path, str]] = []
    for path in sorted(evidence_dir.rglob("*")):
        if path.is_file():
            candidates.append((path, path.relative_to(evidence_dir.parent).as_posix()))
    if acceptance_report.exists():
        candidates.append((acceptance_report, "acceptance_report.json"))
    combined = Path("reports/acceptance/acceptance_results_combined.json")
    if combined.exists():
        candidates.append((combined, "acceptance_results_combined.json"))
    status = Path("docs/PIPELINE_STATUS.md")
    if status.exists():
        candidates.append((status, "PIPELINE_STATUS.md"))
    for path in sorted(Path("reports/environment").glob("*.json")):
        candidates.append((path, f"environment/{path.name}"))
    if logs_dir.exists():
        for path in sorted(logs_dir.rglob("*")):
            if not path.is_file() or path.name == ".gitkeep":
                continue
            # Keep the review handoff compact and avoid accidentally nesting
            # huge binary dumps. Text/runtime logs under this cap are enough to
            # diagnose the acceptance path alongside the machine-readable JSON.
            if path.stat().st_size <= max_log_bytes:
                candidates.append((path, f"logs/{path.relative_to(logs_dir).as_posix()}"))
    if include_video and film.exists():
        candidates.append((film, film.name))

    manifest = {
        "files": [arc for _src, arc in candidates],
        "include_video": include_video and film.exists(),
        "logs_included": sum(1 for _src, arc in candidates if arc.startswith("logs/")),
    }
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for source, arcname in candidates:
            archive.write(source, arcname)
        archive.writestr("evidence_manifest.json", json.dumps(manifest, indent=2) + "\n")
    return output
