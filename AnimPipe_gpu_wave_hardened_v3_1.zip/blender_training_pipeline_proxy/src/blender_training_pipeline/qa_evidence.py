from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

from .delivery import contact_sheet, encode, sample_video_frames
from .models import PipelineConfig


def evidence_frame_numbers(cfg: PipelineConfig) -> list[int]:
    """Return the deterministic QA frame set for a shot.

    Required semantic observables are only meaningful if the critic is shown
    the frames named by the contract.  Earlier acceptance runs rendered only
    ``preview.contact_sheet_frames`` which meant an interaction could require,
    for example, frame 44 while the VLM only saw 30 and 60.  The evidence set
    is therefore the union of authored preview beats and every required
    observable frame, sorted and range-checked against the shot.
    """
    authored = set(int(frame) for frame in cfg.preview.contact_sheet_frames)
    required: set[int] = set()
    for observable in cfg.qa.required_observables:
        if observable.required:
            required.update(int(frame) for frame in observable.frames)
    frames = sorted(authored | required)
    if not frames:
        frames = [cfg.render.frame_start, cfg.render.frame_end]
    invalid = [
        frame for frame in frames
        if frame < cfg.render.frame_start or frame > cfg.render.frame_end
    ]
    if invalid:
        raise ValueError(
            "QA evidence frames fall outside the configured render range "
            f"{cfg.render.frame_start}-{cfg.render.frame_end}: {invalid}"
        )
    return frames


def remap_sparse_delivery(
    cfg: PipelineConfig, sampled_frames: list[int]
) -> tuple[list[dict[str, Any]], dict[str, Any], dict[int, int]]:
    """Map real shot frame numbers onto a dense evidence sequence.

    QA previews render sparse frames. Delivery effects (captions/overlays) use
    original shot frame ranges, so they must be remapped before encoding a dense
    evidence clip or timing becomes meaningless.
    """
    dense_map = {frame: index for index, frame in enumerate(sampled_frames, start=1)}

    dialogue: list[dict[str, Any]] = []
    for line in cfg.dialogue:
        active = [dense_map[f] for f in sampled_frames if line.start_frame <= f <= (line.end_frame or f)]
        if not active:
            continue
        payload = line.model_dump(mode="json")
        payload["start_frame"] = min(active)
        payload["end_frame"] = max(active)
        dialogue.append(payload)

    comp = cfg.comp.model_dump(mode="json")
    overlays: list[dict[str, Any]] = []
    for spec in comp.get("overlay_slots") or []:
        active = [
            dense_map[f]
            for f in sampled_frames
            if int(spec["start_frame"]) <= f <= int(spec["end_frame"])
        ]
        if not active:
            continue
        payload = dict(spec)
        payload["start_frame"] = min(active)
        payload["end_frame"] = max(active)
        overlays.append(payload)
    comp["overlay_slots"] = overlays
    return dialogue, comp, dense_map


def build_delivery_evidence(
    *,
    rendered_frames: list[Path],
    cfg: PipelineConfig,
    work_dir: Path,
    asset_manifest: Path,
    assets_root: Path,
    keep_video: bool = False,
) -> dict[str, Any]:
    pngs = sorted((p for p in rendered_frames if p.suffix.lower() == ".png"), key=lambda p: int(p.stem))
    if not pngs:
        raise RuntimeError("visual QA requires PNG preview frames")

    sampled = [int(p.stem) for p in pngs]
    dialogue, comp, dense_map = remap_sparse_delivery(cfg, sampled)
    dense = work_dir / "delivery-input"
    dense.mkdir(parents=True, exist_ok=True)
    for source in pngs:
        index = dense_map[int(source.stem)]
        shutil.copy2(source, dense / f"{index:04d}.png")

    preview = work_dir / "delivery-evidence.mp4"
    encode(
        frames_dir=dense,
        output=preview,
        fps=cfg.render.fps,
        frame_start=1,
        codec="libx264",
        cq=cfg.output.cq,
        audio=None,
        audio_codec=cfg.output.audio_codec,
        metadata={"qa_evidence": "true"},
        comp=comp,
        dialogue=dialogue,
        asset_manifest=asset_manifest,
        assets_root=assets_root,
    )

    delivered_dir = work_dir / "delivered-frames"
    delivered = sample_video_frames(
        video=preview,
        frames=list(range(len(sampled))),
        output_dir=delivered_dir,
        prefix="delivered",
    )
    labels = [f"shot frame {frame}" for frame in sampled]
    sheet = work_dir / "contact-delivered.png"
    contact_sheet(frames=delivered, output=sheet, labels=labels)

    if not keep_video:
        shutil.rmtree(dense, ignore_errors=True)
        shutil.rmtree(delivered_dir, ignore_errors=True)
        preview.unlink(missing_ok=True)

    return {
        "contact_sheet": sheet,
        "sampled_frames": sampled,
        "labels": labels,
        "delivery_preview": preview if keep_video else None,
    }
