from __future__ import annotations

import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .config_patch import apply_review_candidate
from .delivery import build_shot
from .gpu_lock import gpu_lock
from .models import PipelineConfig
from .ollama_control import load_model, unload_model, wait_for_inference
from .qa_evidence import build_delivery_evidence, evidence_frame_numbers
from .qa_loop import dimension_failures, mean_review_score, observable_failures, revision_decision
from .render_wave import render_wave
from .vision_review import review_preview


@dataclass
class WaveShot:
    shot_id: str
    resolved_config: Path
    work_dir: Path
    iteration: int = 0
    prior_score: float | None = None
    history: list[dict[str, Any]] = field(default_factory=list)
    final_config: Path | None = None
    final_blend: Path | None = None
    status: str = "pending"
    reason: str = ""


def _cfg(path: Path) -> PipelineConfig:
    return PipelineConfig.model_validate(json.loads(path.read_text(encoding="utf-8")))


def _build_one(
    shot: WaveShot,
    *,
    manifest: Path,
    assets_root: Path,
) -> tuple[WaveShot, PipelineConfig, Path, dict[str, Any]]:
    cfg = _cfg(shot.resolved_config)
    blend = shot.work_dir / "qa" / f"preview-r{shot.iteration}.blend"
    report_path = shot.work_dir / "qa" / f"build-r{shot.iteration}.json"
    report = build_shot(
        config=shot.resolved_config,
        manifest=manifest,
        output=blend,
        assets_root=assets_root,
        preview=True,
        report=report_path,
    )
    if report.get("status") != "ok":
        raise RuntimeError(f"{shot.shot_id} preview build failed: {report}")
    return shot, cfg, blend, report


def _prepare_evidence(
    *,
    shot: WaveShot,
    cfg: PipelineConfig,
    frames_dir: Path,
    manifest: Path,
    assets_root: Path,
) -> dict[str, Any]:
    rendered = sorted(frames_dir.glob("*.png"))
    if not rendered:
        raise RuntimeError(f"{shot.shot_id} render wave produced no PNG frames")
    return build_delivery_evidence(
        rendered_frames=rendered,
        cfg=cfg,
        work_dir=shot.work_dir / "qa" / f"evidence-r{shot.iteration}",
        asset_manifest=manifest,
        assets_root=assets_root,
    )


def run_qa_wave(
    *,
    shots: list[WaveShot],
    intent: Path,
    manifest: Path,
    assets_root: Path,
    hardware_manifest: Path,
    work_dir: Path,
    build_workers: int = 2,
    evidence_dir: Path | None = None,
) -> dict[str, Any]:
    """Review many shots in GPU-efficient waves.

    Each revision round is split into four phases:
      1. CPU/Blender scene builds in parallel.
      2. One long Cycles render wave under one GPU lock/process.
      3. Delivery-evidence preparation in parallel on CPU.
      4. One VLM review wave with the model kept resident.

    Only shots that require revision enter the next round.
    """
    if not shots:
        return {"status": "pass", "shots": []}
    intent_text = intent.read_text(encoding="utf-8")
    active = list(shots)
    work_dir.mkdir(parents=True, exist_ok=True)
    if evidence_dir is not None:
        evidence_dir.mkdir(parents=True, exist_ok=True)
    wave_history: list[dict[str, Any]] = []

    while active:
        round_started = time.perf_counter()
        build_started = time.perf_counter()
        built: dict[str, tuple[PipelineConfig, Path, dict[str, Any]]] = {}
        with ThreadPoolExecutor(max_workers=max(1, build_workers)) as pool:
            futures = {
                pool.submit(_build_one, shot, manifest=manifest, assets_root=assets_root): shot
                for shot in active
            }
            for future in as_completed(futures):
                shot, cfg, blend, report = future.result()
                built[shot.shot_id] = (cfg, blend, report)
        build_seconds = time.perf_counter() - build_started

        first_cfg = next(iter(built.values()))[0]
        render_jobs: list[dict[str, Any]] = []
        frame_dirs: dict[str, Path] = {}
        for shot in active:
            cfg, blend, _report = built[shot.shot_id]
            frames_dir = shot.work_dir / "qa" / f"frames-r{shot.iteration}"
            frame_dirs[shot.shot_id] = frames_dir
            render_jobs.append({
                "shot_id": shot.shot_id,
                "blend": str(blend),
                "output_dir": str(frames_dir),
                "frames": evidence_frame_numbers(cfg),
            })

        render_started = time.perf_counter()
        render_report = render_wave(
            jobs=render_jobs,
            config=first_cfg,
            work_dir=work_dir / f"render-wave-r{max(s.iteration for s in active)}",
            preview=True,
            hardware_manifest=hardware_manifest,
        )
        render_seconds = time.perf_counter() - render_started

        evidence_started = time.perf_counter()
        evidence: dict[str, dict[str, Any]] = {}
        with ThreadPoolExecutor(max_workers=max(1, first_cfg.resource_policy.cpu_workers)) as pool:
            futures = {
                pool.submit(
                    _prepare_evidence,
                    shot=shot,
                    cfg=built[shot.shot_id][0],
                    frames_dir=frame_dirs[shot.shot_id],
                    manifest=manifest,
                    assets_root=assets_root,
                ): shot
                for shot in active
            }
            for future in as_completed(futures):
                shot = futures[future]
                evidence[shot.shot_id] = future.result()
        evidence_seconds = time.perf_counter() - evidence_started

        policy = first_cfg.resource_policy.gpu
        workload = policy.workloads["vision_qa"]
        next_active: list[WaveShot] = []
        round_results: list[dict[str, Any]] = []
        review_started = time.perf_counter()
        with gpu_lock(
            workload="vision_qa_wave",
            estimated_peak_mib=workload.estimated_peak_mib,
            reserve_mib=policy.reserve_mib,
            timeout_seconds=policy.lock_timeout_seconds,
            manifest_path=hardware_manifest,
            resource="compute",
            admission_wait_seconds=policy.admission_wait_seconds,
            admission_poll_seconds=policy.admission_poll_seconds,
        ):
            load_model(first_cfg.qa.vision_model, keep_alive=policy.vision_keep_alive)
            try:
                if not wait_for_inference(
                    first_cfg.qa.vision_model,
                    keep_alive=policy.vision_keep_alive,
                    timeout_s=120.0,
                ):
                    raise RuntimeError(
                        f"VLM model '{first_cfg.qa.vision_model}' did not become inference-ready for review wave"
                    )
                for shot in active:
                    cfg, blend, build_report = built[shot.shot_id]
                    try:
                        review = review_preview(
                            Path(evidence[shot.shot_id]["contact_sheet"]),
                            intent_text,
                            shot.resolved_config.read_text(encoding="utf-8"),
                            model=cfg.qa.vision_model,
                            keep_alive=policy.vision_keep_alive,
                            ensure_ready=False,
                        )
                    except Exception as exc:
                        result = {
                            "shot_id": shot.shot_id,
                            "iteration": shot.iteration,
                            "score": None,
                            "action": "escalate",
                            "reason": f"VLM review failed: {exc}",
                            "dimension_failures": [],
                            "observable_failures": [],
                            "review": None,
                            "build": build_report,
                            "contact_sheet": str(evidence[shot.shot_id]["contact_sheet"]),
                        }
                        shot.history.append(result)
                        shot.status = "escalate"
                        shot.reason = result["reason"]
                        report_path = shot.work_dir / "qa" / f"review-r{shot.iteration}.json"
                        report_path.write_text(
                            json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
                        )
                        round_results.append(result)
                        continue
                    score = mean_review_score(review)
                    action, reason = revision_decision(
                        review,
                        cfg,
                        iteration=shot.iteration,
                        prior_score=shot.prior_score,
                    )
                    result = {
                        "shot_id": shot.shot_id,
                        "iteration": shot.iteration,
                        "score": score,
                        "action": action,
                        "reason": reason,
                        "dimension_failures": dimension_failures(review, cfg),
                        "observable_failures": observable_failures(review, cfg),
                        "review": review.model_dump(mode="json"),
                        "build": build_report,
                        "contact_sheet": str(evidence[shot.shot_id]["contact_sheet"]),
                    }
                    shot.history.append(result)
                    report_path = shot.work_dir / "qa" / f"review-r{shot.iteration}.json"
                    report_path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
                    round_results.append(result)
                
                    if action == "pass":
                        shot.status = "pass"
                        shot.reason = reason
                        shot.final_config = shot.resolved_config
                        shot.final_blend = blend
                        if evidence_dir is not None:
                            import shutil
                            shutil.copy2(
                                Path(evidence[shot.shot_id]["contact_sheet"]),
                                evidence_dir / f"{shot.shot_id}.contact.png",
                            )
                            (evidence_dir / f"{shot.shot_id}.review.json").write_text(
                                json.dumps(result, indent=2, sort_keys=True) + "\n",
                                encoding="utf-8",
                            )
                        continue
                    if action == "escalate":
                        shot.status = "escalate"
                        shot.reason = reason
                        continue
                
                    raw = json.loads(shot.resolved_config.read_text(encoding="utf-8"))
                    candidate = apply_review_candidate(raw, review)
                    candidate_path = shot.work_dir / "qa" / f"resolved-r{shot.iteration + 1}.json"
                    candidate_path.write_text(
                        json.dumps(candidate, indent=2, sort_keys=True) + "\n", encoding="utf-8"
                    )
                    shot.prior_score = score
                    shot.iteration += 1
                    shot.resolved_config = candidate_path
                    next_active.append(shot)
                # Release VLM residency while the compute lock is still held so the
                # next Cycles wave cannot race model teardown/reacquisition.
            finally:
                # Release residency before releasing the compute lock, even on review failure.
                unload_model(first_cfg.qa.vision_model, tolerate_unavailable=True)
        review_seconds = time.perf_counter() - review_started

        wave_history.append({
            "round": len(wave_history),
            "render": render_report,
            "reviews": round_results,
            "timings_seconds": {
                "build": build_seconds,
                "render": render_seconds,
                "evidence": evidence_seconds,
                "vision_review": review_seconds,
                "total": time.perf_counter() - round_started,
            },
            "active_shots": [shot.shot_id for shot in active],
            "retry_shots": [shot.shot_id for shot in next_active],
        })
        active = next_active

    status = "pass" if all(shot.status == "pass" for shot in shots) else "escalate"
    result = {
        "status": status,
        "waves": wave_history,
        "shots": [
            {
                "shot_id": shot.shot_id,
                "status": shot.status,
                "reason": shot.reason,
                "iterations": len(shot.history),
                "final_config": str(shot.final_config) if shot.final_config else None,
                "final_blend": str(shot.final_blend) if shot.final_blend else None,
                "history": shot.history,
            }
            for shot in shots
        ],
    }
    (work_dir / "qa-wave.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return result
