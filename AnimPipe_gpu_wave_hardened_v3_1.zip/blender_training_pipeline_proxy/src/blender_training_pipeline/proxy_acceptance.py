from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from .config_compile import compile_pipeline
from .delivery import build_shot, encode, ffprobe_json
from .evidence_export import export_qa_evidence
from .final_film_qa import run_final_film_qa
from .gpu_lock import gpu_lock
from .models import PipelineConfig
from .qa_wave import WaveShot, run_qa_wave
from .render_wave import render_wave
from .tts import KokoroClient
from .visemes import rhubarb_cues


class ProxyAcceptanceError(RuntimeError):
    pass


@dataclass
class PreparedShot:
    shot_id: str
    shot_dir: Path
    config: PipelineConfig
    resolved: Path
    audio: Path | None
    blend: Path | None = None
    qa: dict[str, Any] | None = None


def _write_config(model: PipelineConfig, output: Path) -> Path:
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(model.model_dump(mode="json", by_alias=True), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return output


def _concat(segments: list[Path], output: Path) -> Path:
    if shutil.which("ffmpeg") is None:
        raise ProxyAcceptanceError("ffmpeg not found")
    concat_file = output.with_suffix(".concat.txt")
    concat_file.parent.mkdir(parents=True, exist_ok=True)
    concat_file.write_text(
        "\n".join(f"file '{p.resolve().as_posix()}'" for p in segments) + "\n",
        encoding="utf-8",
    )
    cmd = ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file), "-c", "copy", str(output)]
    proc = subprocess.run(cmd, check=False, capture_output=True, text=True)
    if proc.returncode != 0 or not output.exists():
        tail = "\n".join(proc.stderr.splitlines()[-10:])
        raise ProxyAcceptanceError(f"acceptance concat failed:\n{tail}")
    return output


def _shot_specs(plan_path: Path) -> list[dict[str, Any]]:
    raw = yaml.safe_load(plan_path.read_text(encoding="utf-8"))
    shots = raw.get("shots") if isinstance(raw, dict) else None
    if not isinstance(shots, list) or not shots:
        raise ProxyAcceptanceError("acceptance plan must contain a non-empty shots list")
    return shots


def _prepare_one(
    item: dict[str, Any],
    *,
    common_layers: list[Path],
    work_dir: Path,
    audio: bool,
) -> PreparedShot:
    shot_id = str(item["id"])
    shot_layer = Path(str(item["config"]))
    shot_dir = work_dir / shot_id
    shot_dir.mkdir(parents=True, exist_ok=True)
    overrides: list[str] = []
    if not audio:
        overrides.extend(["dialogue=[]", "comp.caption_style.burn_in=false"])
    initial, _, _ = compile_pipeline(common_layers + [shot_layer], overrides)

    wav: Path | None = None
    if audio and initial.dialogue:
        if len(initial.dialogue) != 1:
            raise ProxyAcceptanceError(
                f"proxy acceptance shot {shot_id} must use exactly one dialogue line"
            )
        line = initial.dialogue[0]
        wav = shot_dir / "audio" / "speech.wav"
        wav.parent.mkdir(parents=True, exist_ok=True)
        transcript = shot_dir / "audio" / "transcript.txt"
        cues = shot_dir / "audio" / "visemes.json"
        request_file = shot_dir / "audio" / "request.json"
        request = {
            "provider": "kokoro",
            "model": "tts-1",
            "voice": line.voice_id,
            "speed": 1.0,
            "text": line.text,
            # Operators can bump this when the local TTS image/model changes and
            # they want acceptance audio regenerated without deleting build/.
            "cache_version": os.getenv("ANIMPIPE_TTS_CACHE_VERSION", "1"),
        }
        reuse = False
        if request_file.exists() and wav.exists() and transcript.exists() and cues.exists():
            try:
                reuse = json.loads(request_file.read_text(encoding="utf-8")) == request
            except Exception:
                reuse = False
        if not reuse:
            KokoroClient().synthesize(line.text, wav, voice=line.voice_id, speed=1.0)
            transcript.write_text(line.text + "\n", encoding="utf-8")
            rhubarb_cues(wav, cues, transcript)
            request_file.write_text(
                json.dumps(request, indent=2, sort_keys=True) + "\n", encoding="utf-8"
            )

        # Do not let FFmpeg silently cut a narration line at the shot boundary.
        # The TTS file represents only spoken content; delivery later delays it
        # to start_frame on the exact same frame clock as visemes/captions.
        probe = ffprobe_json(wav)
        speech_duration = float((probe.get("format") or {}).get("duration") or 0.0)
        line_end = line.end_frame if line.end_frame is not None else initial.render.frame_end
        available = max(0.0, (line_end - line.start_frame + 1) / initial.render.fps)
        if speech_duration > available + (1.0 / initial.render.fps):
            raise ProxyAcceptanceError(
                f"shot {shot_id} TTS duration {speech_duration:.3f}s exceeds authored "
                f"dialogue window {available:.3f}s; increase end_frame or change speech pacing"
            )
        overrides.append(f"dialogue.0.viseme_artifact={cues.as_posix()}")

    cfg, _, _ = compile_pipeline(common_layers + [shot_layer], overrides)
    resolved = _write_config(cfg, shot_dir / "resolved_config.json")
    return PreparedShot(shot_id=shot_id, shot_dir=shot_dir, config=cfg, resolved=resolved, audio=wav)


def _build_one(
    shot: PreparedShot,
    *,
    manifest: Path,
    assets_root: Path,
    preview: bool,
) -> PreparedShot:
    blend = shot.shot_dir / ("scene.preview.blend" if preview else "scene.final.blend")
    report = build_shot(
        config=shot.resolved,
        manifest=manifest,
        output=blend,
        assets_root=assets_root,
        preview=preview,
        report=shot.shot_dir / ("build_preview.json" if preview else "build_final.json"),
    )
    if report.get("status") != "ok":
        raise ProxyAcceptanceError(f"shot {shot.shot_id} build blocked: {report}")
    shot.blend = blend
    return shot


def _encode_one(
    shot: PreparedShot,
    *,
    frames_dir: Path,
    manifest: Path,
    assets_root: Path,
    hardware_manifest: Path,
) -> Path:
    cfg = shot.config
    segment = shot.shot_dir / f"{shot.shot_id}.mp4"
    kwargs = dict(
        frames_dir=frames_dir,
        output=segment,
        fps=cfg.render.fps,
        frame_start=cfg.render.frame_start,
        codec=cfg.output.video_codec,
        cq=cfg.output.cq,
        audio=shot.audio,
        audio_start_frame=(cfg.dialogue[0].start_frame if shot.audio and cfg.dialogue else None),
        audio_codec=cfg.output.audio_codec,
        metadata=cfg.output.metadata,
        comp=cfg.comp.model_dump(mode="json"),
        dialogue=[d.model_dump(mode="json") for d in cfg.dialogue],
        asset_manifest=manifest,
        assets_root=assets_root,
    )
    if cfg.output.video_codec.endswith("_nvenc"):
        policy = cfg.resource_policy.gpu
        workload = policy.workloads["nvenc"]
        resource = "encode" if policy.allow_nvenc_overlap_with_compute else "compute"
        with gpu_lock(
            "nvenc",
            workload.estimated_peak_mib,
            policy.reserve_mib,
            policy.lock_timeout_seconds,
            manifest_path=hardware_manifest,
            resource=resource,
            admission_wait_seconds=policy.admission_wait_seconds,
            admission_poll_seconds=policy.admission_poll_seconds,
        ):
            return encode(**kwargs)
    return encode(**kwargs)


def run_proxy_acceptance(
    *,
    plan_path: Path = Path("proxy_kit/acceptance.yaml"),
    manifest: Path = Path("build/assets.proxy.resolved.json"),
    assets_root: Path = Path("assets"),
    work_dir: Path = Path("build/proxy_acceptance"),
    hardware_manifest: Path = Path("reports/environment/hardware-verified.json"),
    evidence_dir: Path = Path("reports/acceptance/evidence"),
    preview: bool = True,
    audio: bool = True,
    qa: bool = True,
) -> dict[str, Any]:
    run_started = time.perf_counter()
    if not manifest.exists():
        raise ProxyAcceptanceError("proxy manifest missing; run `pipe proxy generate` first")
    shot_specs = _shot_specs(plan_path)
    work_dir.mkdir(parents=True, exist_ok=True)
    evidence_dir.mkdir(parents=True, exist_ok=True)
    common_layers = [
        Path("config/base.yaml"),
        Path("config/proxy/style.yaml"),
        Path("config/proxy/vocabulary.yaml"),
        Path("config/proxy/acceptance/base.yaml"),
        Path("config/proxy/acceptance/scene.yaml"),
    ]

    # Resolve policy before fan-out. Audio/config preparation is CPU/network work
    # and can safely proceed in parallel while the T4 remains idle.
    seed_cfg, _, _ = compile_pipeline(common_layers + [Path(str(shot_specs[0]["config"]))], [])
    workers = seed_cfg.resource_policy.cpu_workers
    prepare_started = time.perf_counter()
    prepared: dict[str, PreparedShot] = {}
    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        futures = {
            pool.submit(
                _prepare_one,
                item,
                common_layers=common_layers,
                work_dir=work_dir,
                audio=audio,
            ): str(item["id"])
            for item in shot_specs
        }
        for future in as_completed(futures):
            shot = future.result()
            prepared[shot.shot_id] = shot
    shots = [prepared[str(item["id"])] for item in shot_specs]
    prepare_seconds = time.perf_counter() - prepare_started

    qa_result: dict[str, Any] | None = None
    qa_seconds = 0.0
    if qa:
        qa_started = time.perf_counter()
        qa_shots = [
            WaveShot(shot_id=s.shot_id, resolved_config=s.resolved, work_dir=s.shot_dir)
            for s in shots
        ]
        qa_result = run_qa_wave(
            shots=qa_shots,
            intent=Path("config/proxy/acceptance/scene.yaml"),
            manifest=manifest,
            assets_root=assets_root,
            hardware_manifest=hardware_manifest,
            work_dir=work_dir / "qa-wave",
            build_workers=seed_cfg.resource_policy.build_workers,
            evidence_dir=evidence_dir / "shots",
        )
        by_id = {item["shot_id"]: item for item in qa_result["shots"]}
        for shot in shots:
            item = by_id[shot.shot_id]
            shot.qa = item
            if item["status"] != "pass":
                report = {
                    "status": "escalate",
                    "stage": "shot_qa",
                    "shot": shot.shot_id,
                    "reason": item["reason"],
                    "qa": qa_result,
                }
                acceptance_report = work_dir / "acceptance_report.json"
                acceptance_report.write_text(
                    json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
                )
                reports_dir = Path("reports/acceptance")
                reports_dir.mkdir(parents=True, exist_ok=True)
                combined = reports_dir / "acceptance_results_combined.json"
                combined.write_text(
                    json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
                )
                try:
                    bundle = export_qa_evidence(
                        evidence_dir=evidence_dir,
                        acceptance_report=acceptance_report,
                        include_video=False,
                    )
                    report["evidence_bundle"] = str(bundle)
                except Exception as exc:
                    report["evidence_export_error"] = str(exc)
                acceptance_report.write_text(
                    json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
                )
                combined.write_text(
                    json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
                )
                return report
            shot.resolved = Path(str(item["final_config"]))
            shot.config = PipelineConfig.model_validate(
                json.loads(shot.resolved.read_text(encoding="utf-8"))
            )
            if preview:
                shot.blend = Path(str(item["final_blend"]))
        qa_seconds = time.perf_counter() - qa_started

    # Final-mode acceptance needs full-quality .blend artifacts. Preview-mode QA
    # already built the exact preview artifact for the final accepted config.
    to_build = [shot for shot in shots if shot.blend is None]
    build_started = time.perf_counter()
    if to_build:
        with ThreadPoolExecutor(max_workers=max(1, seed_cfg.resource_policy.build_workers)) as pool:
            futures = {
                pool.submit(
                    _build_one,
                    shot,
                    manifest=manifest,
                    assets_root=assets_root,
                    preview=preview,
                ): shot.shot_id
                for shot in to_build
            }
            for future in as_completed(futures):
                future.result()
    build_seconds = time.perf_counter() - build_started

    # One long Cycles/OptiX wave renders all accepted shots. The VLM is unloaded
    # before this call and is not reloaded until render work is complete.
    render_jobs: list[dict[str, Any]] = []
    frame_dirs: dict[str, Path] = {}
    for shot in shots:
        if shot.blend is None:
            raise ProxyAcceptanceError(f"shot {shot.shot_id} has no build artifact")
        frames_dir = shot.shot_dir / "frames"
        frame_dirs[shot.shot_id] = frames_dir
        render_jobs.append({
            "shot_id": shot.shot_id,
            "blend": str(shot.blend),
            "output_dir": str(frames_dir),
            "frames": None,
        })
    render_started = time.perf_counter()
    full_render = render_wave(
        jobs=render_jobs,
        config=shots[0].config,
        work_dir=work_dir / "final-render-wave",
        preview=preview,
        hardware_manifest=hardware_manifest,
    )
    render_seconds = time.perf_counter() - render_started

    segments: dict[str, Path] = {}
    # libx264 preview encodes are CPU work and can overlap. NVENC still passes
    # through the GPU resource policy inside _encode_one.
    encode_workers = max(1, seed_cfg.resource_policy.encode_workers)
    encode_started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=encode_workers) as pool:
        futures = {
            pool.submit(
                _encode_one,
                shot,
                frames_dir=frame_dirs[shot.shot_id],
                manifest=manifest,
                assets_root=assets_root,
                hardware_manifest=hardware_manifest,
            ): shot
            for shot in shots
        }
        for future in as_completed(futures):
            shot = futures[future]
            segments[shot.shot_id] = future.result()
    encode_seconds = time.perf_counter() - encode_started
    ordered_segments = [segments[shot.shot_id] for shot in shots]
    concat_started = time.perf_counter()
    final = _concat(ordered_segments, work_dir / "proxy_acceptance_film.mp4")
    concat_seconds = time.perf_counter() - concat_started

    final_qa: dict[str, Any] | None = None
    final_qa_seconds = 0.0
    if qa and shots[0].config.qa.final_film_enabled:
        final_qa_started = time.perf_counter()
        final_qa = run_final_film_qa(
            film=final,
            segments=ordered_segments,
            config=shots[0].config,
            shot_configs=[shot.config for shot in shots],
            evidence_dir=evidence_dir / "final_film",
            hardware_manifest=hardware_manifest,
            expect_audio=audio,
        )
        final_qa_seconds = time.perf_counter() - final_qa_started

    status = "ok"
    if final_qa and final_qa.get("status") != "pass":
        status = "escalate"
    report = {
        "status": status,
        "preview": preview,
        "audio": audio,
        "qa": qa,
        "pipeline_mode": "wave",
        "shots": [
            {
                "shot_id": shot.shot_id,
                "resolved_config": str(shot.resolved),
                "blend": str(shot.blend) if shot.blend else None,
                "frames_dir": str(frame_dirs[shot.shot_id]),
                "segment": str(segments[shot.shot_id]),
                "audio": str(shot.audio) if shot.audio else None,
                "qa": shot.qa,
            }
            for shot in shots
        ],
        "render_wave": full_render,
        "film": str(final),
        "segments": [str(path) for path in ordered_segments],
        "final_film_qa": final_qa,
        "evidence_dir": str(evidence_dir),
        "timings_seconds": {
            "prepare_config_audio": prepare_seconds,
            "shot_qa_waves": qa_seconds,
            "accepted_builds": build_seconds,
            "full_render_wave": render_seconds,
            "segment_encode": encode_seconds,
            "concat": concat_seconds,
            "final_film_qa": final_qa_seconds,
            "total": time.perf_counter() - run_started,
        },
    }
    acceptance_report = work_dir / "acceptance_report.json"
    reports_dir = Path("reports/acceptance")
    reports_dir.mkdir(parents=True, exist_ok=True)
    combined = reports_dir / "acceptance_results_combined.json"
    acceptance_report.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    combined.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    if qa:
        try:
            bundle = export_qa_evidence(
                evidence_dir=evidence_dir,
                acceptance_report=acceptance_report,
                film=final,
                include_video=False,
            )
            report["evidence_bundle"] = str(bundle)
        except Exception as exc:
            report["evidence_export_error"] = str(exc)
        acceptance_report.write_text(
            json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        combined.write_text(
            json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
    return report
