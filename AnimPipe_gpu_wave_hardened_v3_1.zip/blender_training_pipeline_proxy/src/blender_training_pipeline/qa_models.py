from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class DimensionReview(StrictModel):
    grade: Literal["pass", "warn", "fail"]
    note: str
    score: float = Field(ge=0.0, le=1.0)


class ObservableReview(StrictModel):
    id: str
    visible: bool
    note: str
    score: float = Field(ge=0.0, le=1.0)


class ConfigChange(StrictModel):
    path: str
    proposed_value: object
    rationale: str
    confidence: float = Field(ge=0.0, le=1.0)


class VisualReview(StrictModel):
    verdict: Literal["pass", "revise", "escalate"]
    summary: str
    framing: DimensionReview
    legibility: DimensionReview
    staging: DimensionReview
    lighting: DimensionReview
    continuity: DimensionReview
    instructional_intent: DimensionReview
    observables: list[ObservableReview] = Field(default_factory=list)
    changes: list[ConfigChange] = Field(default_factory=list)


class FinalFilmVisualReview(StrictModel):
    verdict: Literal["pass", "escalate"]
    summary: str
    transition_continuity: DimensionReview
    caption_legibility: DimensionReview
    prop_continuity: DimensionReview
    lip_sync_visibility: DimensionReview
    visual_coherence: DimensionReview
    suspicious_transitions: list[str] = Field(default_factory=list)
