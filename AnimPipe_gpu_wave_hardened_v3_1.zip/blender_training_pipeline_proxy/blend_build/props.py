"""Instantiate reusable prop assets and schedule character-bone attachments."""

from __future__ import annotations

import math
from typing import Any

import bpy

from .assets import instantiate_override, link_collection
from .context import BuildContext, BuildError


def _roots(collection: Any) -> list[Any]:
    return [obj for obj in collection.all_objects if obj.parent is None]


def _apply_transform(obj: Any, spec: dict[str, Any]) -> None:
    if "location" in spec:
        obj.location = tuple(float(v) for v in spec["location"])
    if "rotation_deg" in spec:
        obj.rotation_euler = tuple(math.radians(float(v)) for v in spec["rotation_deg"])
    if "scale" in spec:
        obj.scale = tuple(float(v) for v in spec["scale"])


def _key_transform(obj: Any, frame: int) -> None:
    for path in ("location", "rotation_euler", "scale"):
        obj.keyframe_insert(data_path=path, frame=frame)


def _set_constant(obj: Any) -> None:
    anim = obj.animation_data
    if anim is None or anim.action is None:
        return
    from .camera import _all_fcurves
    for curve in _all_fcurves(anim.action):
        for point in curve.keyframe_points:
            point.interpolation = "CONSTANT"


def _schedule_attachment(
    ctx: BuildContext,
    root: Any,
    spec: dict[str, Any],
    cast: dict[str, dict[str, Any]],
    label: str,
) -> None:
    character_id = str(spec["target_character_id"])
    handles = cast.get(character_id)
    if handles is None:
        raise BuildError(f"prop '{label}' attachment target '{character_id}' is not in cast")
    armature = handles["armature"]
    bone = str(spec["bone"])
    if bone not in armature.pose.bones:
        raise BuildError(
            f"prop '{label}' attachment bone '{bone}' is not present on '{character_id}'"
        )

    start = int(spec["start_frame"])
    end = spec.get("end_frame")
    constraint = root.constraints.new("CHILD_OF")
    constraint.name = f"ATTACH_{character_id}_{bone}_{start}"
    constraint.target = armature
    constraint.subtarget = bone

    # Preserve the configured world-space spawn until the attachment frame.
    # Earlier versions applied the bone-local offset immediately, which silently
    # overwrote spawn and made the prop drift/jump before the hand reached it.
    if start > 0:
        _key_transform(root, max(0, start - 1))

    # Resolve a reusable asset-authored grip first, then apply any shot-local
    # adjustment. Both are expressed in target-bone local coordinates.
    entry = ctx.asset(str(spec.get("asset_id") or "")) if spec.get("asset_id") else None
    grip = {}
    grip_id = spec.get("grip_id")
    if grip_id:
        # build_props injects the prop entry into the attachment spec below.
        grip = (spec.get("_asset_grip_transforms") or {}).get(str(grip_id)) or {}
        if not grip:
            raise BuildError(f"prop '{label}' requests unknown grip_id '{grip_id}'")
    offset = spec.get("offset") or {}
    merged = {
        "location": [
            float(grip.get("location", [0.0, 0.0, 0.0])[i])
            + float(offset.get("location", [0.0, 0.0, 0.0])[i])
            for i in range(3)
        ],
        "rotation_deg": [
            float(grip.get("rotation_deg", [0.0, 0.0, 0.0])[i])
            + float(offset.get("rotation_deg", [0.0, 0.0, 0.0])[i])
            for i in range(3)
        ],
        "scale": [
            float(grip.get("scale", [1.0, 1.0, 1.0])[i])
            * float(offset.get("scale", [1.0, 1.0, 1.0])[i])
            for i in range(3)
        ],
    }
    _apply_transform(root, merged)
    _key_transform(root, start)

    constraint.influence = 0.0
    constraint.keyframe_insert(data_path="influence", frame=max(0, start - 1))
    constraint.influence = 1.0
    constraint.keyframe_insert(data_path="influence", frame=start)

    if end is not None:
        finish = int(end)
        constraint.influence = 1.0
        constraint.keyframe_insert(data_path="influence", frame=finish)
        constraint.influence = 0.0
        constraint.keyframe_insert(data_path="influence", frame=finish + 1)
        release = spec.get("release_transform")
        if release:
            _apply_transform(root, release)
            _key_transform(root, finish + 1)

    _set_constant(root)
    ctx.assert_that(
        f"prop '{label}' attachment scheduled",
        True,
        f"{character_id}:{bone} frame {start}" + (f"-{end}" if end is not None else "+"),
    )


def build_props(ctx: BuildContext, cast: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    built: dict[str, dict[str, Any]] = {}
    for item in ctx.cfg.get("props", []):
        instance_id = str(item["id"])
        asset_id = str(item["asset_id"])
        if instance_id in built:
            raise BuildError(f"duplicate prop instance id '{instance_id}'")
        entry = ctx.asset(asset_id)
        if entry.get("kind") != "prop":
            raise BuildError(f"prop asset '{asset_id}' must be kind=prop")
        collection_name = entry.get("collection")
        if not collection_name:
            raise BuildError(
                f"prop '{asset_id}' must expose a collection so a writable Library Override can be created"
            )
        linked = link_collection(ctx.asset_path(asset_id), collection_name)
        override = instantiate_override(linked, f"{asset_id}:{instance_id}")
        roots = _roots(override)
        if len(roots) != 1:
            raise BuildError(
                f"prop collection '{collection_name}' must contain exactly one root object; found {len(roots)}"
            )
        root = roots[0]
        root.name = f"PROP_{instance_id}"
        _apply_transform(root, item.get("spawn") or {})
        for attachment in item.get("attachments", []):
            attachment_spec = dict(attachment)
            attachment_spec["asset_id"] = asset_id
            attachment_spec["_asset_grip_transforms"] = entry.get("grip_transforms", {})
            _schedule_attachment(ctx, root, attachment_spec, cast, instance_id)
        built[instance_id] = {"root": root, "collection": override, "entry": entry}
        ctx.assert_that(f"prop '{instance_id}' instantiated", True, asset_id)
    return built
