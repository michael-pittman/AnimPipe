# Blender Training-Video Pipeline — Final Architecture Pack

Target: Azure `Standard_NC4as_T4_v3` (4 vCPU / 28 GiB RAM / 1× NVIDIA Tesla T4)
IDE: Visual Studio Code Remote SSH
Authoring agent: Claude Code / Sonnet 4.6
Blender: 5.2.1 LTS
Config: OmegaConf merge + Pydantic v2 validation
Live inspection: official Blender Lab MCP, scratch scene only
Local AI: Ollama + `qwen2.5vl:3b` (Azure/T4-proven baseline) for visual QA; Kokoro for default TTS

## Governing principle

**The `.blend` is a build artifact, not a document.** Production scenes are rebuilt from authored configuration and source assets. The official Blender MCP exists only for inspection and diagnosis of scratch copies.

## First-run order

1. `python3 scripts/00_hardware_preflight.py`
2. `bash scripts/10_install_base_host.sh`
3. `bash scripts/20_install_azure_grid_driver.sh`
4. Reboot the VM.
5. `python3 scripts/30_verify_gpu.py`
6. `bash scripts/40_install_blender.sh`
7. `bash scripts/50_install_python_envs.sh`
8. `bash scripts/55_install_rhubarb.sh`
9. `bash scripts/60_install_official_blender_mcp.sh`
10. Install/enable the official Blender Lab MCP add-on in the scratch Blender profile.
11. `bash scripts/65_install_claude_code.sh`, then authenticate once with `claude`.
12. `bash scripts/66_install_claude_plugins.sh`
13. `bash scripts/70_start_local_ai.sh`
14. `bash scripts/80_smoke_test.sh`
15. Generate and admit the Proxy Animation Kit, then run the 10-shot acceptance film before replacing proxy art with production assets.

No GPU admission gate is permitted to run until `reports/environment/hardware-verified.json` exists and a fresh live GPU identity check matches it.

## What is included

- final architecture and build specification
- hardware-first Azure setup scripts
- explicit no-host-CUDA-toolkit dependency policy
- Blender 5.2.1 installer, matched fake-bpy stubs, and OptiX probe
- official Blender MCP project configuration and security boundaries
- Docker Compose stack for Ollama/Qwen2.5-VL and Kokoro
- host GPU lock/admission implementation
- OmegaConf/Pydantic configuration compiler
- director-script scene schema and shot schema
- first-class asset manifest/doctor with normalized-rig and camera-path contracts
- first-class Proxy Animation Kit v1: neutral clay style contract, procedural proxy character/set/props/paths/overlays, reusable action/pose/viseme vocabulary, semantic camera/light templates, and a 10-shot acceptance film
- GPU-efficient wave QA: CPU-parallel prepare/build → one Cycles render wave → one resident-VLM review wave → dirty-shot-only retries
- SHA-256 + perceptual hash + SSIM regression utilities
- GPU-gated rendering/NVENC plus FFmpeg LUT/caption/overlay delivery stage and post-concat freeze/silence/transition QA
- Kokoro/faster-whisper/Rhubarb audio CLI
- ten Claude agents, including a dedicated deterministic Asset Factory
- concise single-purpose project skills
- the six user-provided `.skill` packages, unpacked and preserved
- selected Blender-agent upstream skills with exact source provenance
- VS Code workspace settings/tasks and Claude Code/plugin bootstrap
- CPU-only GitHub Actions source CI for schema/skills/bundle/tests/lint/type/compile gates before Azure GPU time

Start with `RUNBOOK.md`; use `docs/ARCHITECTURE.md` and `docs/BUILD_SPEC_FINAL.md` for the full design.


## Finalization notes

See `docs/FINAL_DECISIONS.md` and `docs/BLENDER_AGENT_INTEGRATION.md` for the locked decisions and exact handling of the supplied Blender-agent archive. Generated `.skill` packages for every active project skill are under `skill_packages/generated/`; the six user-supplied original `.skill` archives remain preserved separately.

## Review status

The post-builder multi-track review and web/API verification are recorded in `docs/TEAM_REVIEW.md`. `docs/BUILDER.md` now lists all formerly documented gaps as resolved; only target-VM acceptance remains environment-dependent.

## Proxy Animation Kit milestone

The first full-system acceptance target is the style-neutral `proxy_clay_v1` kit. After the VM smoke gate passes:

```bash
.venv/bin/pipe proxy validate
.venv/bin/pipe proxy generate
.venv/bin/pipe proxy acceptance --preview --audio --qa
.venv/bin/pipe proxy evidence
```

`pipe proxy generate` starts from `proxy_kit/kit.yaml`, creates the character/set/props/camera paths/graphics through pinned Blender, builds a logical asset manifest, and runs Asset Doctor. The acceptance controller then compiles and builds ten five-second shots through the normal production path. Qwen visual QA is enabled by default, required visual observables are score-gated, and final sign-off requires post-concat film QA. The compact evidence bundle preserves the actual QA pixels/JSON even when reproducible heavyweight build artifacts are excluded from Git. See `docs/PROXY_ANIMATION_KIT.md`.
