#!/usr/bin/env python3
"""Create a clean Git/Azure release ZIP from the repository tree.

Runtime media, caches, machine-local secrets, generated proxy assets, and transient
reports are intentionally excluded. QA evidence travels separately via
`pipe proxy evidence` so source handoffs stay deterministic and reviewable.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

_EXCLUDED_DIR_NAMES = {
    ".git",
    ".venv",
    ".venv-bpy",
    ".pytest_cache",
    "__pycache__",
    "build",
    "renders",
    "cache",
    "out",
    "scratch",
}
_EXCLUDED_EXACT = {
    "infra/.env",
    "infra/.env.locked",
    "infra/kokoro.env",
    "assets/assets.proxy.yaml",
    "reports/acceptance/qa_evidence_bundle.zip",
}
_EXCLUDED_PREFIXES = {
    "reports/environment/",
    "reports/proxy/",
    "reports/acceptance/",
    "assets/proxy/",
}


def excluded(relative: Path, *, include_evidence: bool = False) -> bool:
    posix = relative.as_posix()
    if any(part in _EXCLUDED_DIR_NAMES for part in relative.parts):
        return True
    if posix == "reports/acceptance/qa_evidence_bundle.zip" and include_evidence:
        return False
    if posix in _EXCLUDED_EXACT:
        return True
    if any(posix.startswith(prefix) for prefix in _EXCLUDED_PREFIXES):
        # Preserve the source placeholder for the generated proxy directory.
        return posix != "assets/proxy/.gitkeep"
    if relative.suffix in {".pyc", ".pyo"}:
        return True
    if relative.name in {".DS_Store", "Thumbs.db"}:
        return True
    return False


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def package(output: Path, root_name: str, *, include_evidence: bool = False) -> tuple[Path, str, int]:
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    files: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if path.resolve() == output or rel.as_posix() == "MANIFEST.sha256" or excluded(rel, include_evidence=include_evidence):
            continue
        files.append(path)

    manifest_lines: list[str] = []
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for path in sorted(files):
            rel = path.relative_to(ROOT).as_posix()
            payload = path.read_bytes()
            info = zipfile.ZipInfo(f"{root_name}/{rel}")
            # Reproducible metadata rather than source filesystem mtimes/users.
            info.date_time = (2026, 9, 21, 0, 0, 0)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o100644 & 0xFFFF) << 16
            if os.access(path, os.X_OK):
                info.external_attr = (0o100755 & 0xFFFF) << 16
            zf.writestr(info, payload)
            manifest_lines.append(f"{hashlib.sha256(payload).hexdigest()}  {rel}")

        manifest_payload = ("\n".join(manifest_lines) + "\n").encode("utf-8")
        manifest_info = zipfile.ZipInfo(f"{root_name}/MANIFEST.sha256")
        manifest_info.date_time = (2026, 9, 21, 0, 0, 0)
        manifest_info.compress_type = zipfile.ZIP_DEFLATED
        manifest_info.external_attr = (0o100644 & 0xFFFF) << 16
        zf.writestr(manifest_info, manifest_payload)

    digest = sha256(output)
    checksum = output.with_suffix(output.suffix + ".sha256")
    checksum.write_text(f"{digest}  {output.name}\n", encoding="utf-8")
    return output, digest, len(files) + 1


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT.parent / "AnimPipe_gpu_wave_hardened.zip")
    parser.add_argument("--root-name", default="blender_training_pipeline_proxy")
    parser.add_argument(
        "--include-evidence",
        action="store_true",
        help="include reports/acceptance/qa_evidence_bundle.zip when it exists",
    )
    args = parser.parse_args()
    output, digest, count = package(
        args.output, args.root_name, include_evidence=args.include_evidence
    )
    print(f"packaged {count} files -> {output}")
    print(f"sha256 {digest}")


if __name__ == "__main__":
    main()
