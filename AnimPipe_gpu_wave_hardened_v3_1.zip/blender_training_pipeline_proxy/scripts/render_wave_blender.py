#!/usr/bin/env python3
"""Render multiple .blend jobs inside one Blender process.

Keeping a single Blender process alive avoids repeatedly reinitializing the
OptiX/Cycles runtime between acceptance shots. Each .blend remains an immutable
build artifact; this script only opens it and renders configured frames.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import bpy


def _args() -> argparse.Namespace:
    raw = sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []
    parser = argparse.ArgumentParser()
    parser.add_argument("--jobs", required=True)
    parser.add_argument("--report", required=True)
    return parser.parse_args(raw)


def _render_job(job: dict) -> dict:
    blend = Path(job["blend"]).resolve()
    output_dir = Path(job["output_dir"]).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    # A rerendered dirty shot must not inherit stale frames from an earlier
    # iteration or frame range. Only PNG is produced by this acceptance path.
    for stale in output_dir.glob("*.png"):
        stale.unlink()
    frames = job.get("frames")

    started = time.perf_counter()
    bpy.ops.wm.open_mainfile(filepath=str(blend), load_ui=False)
    scene = bpy.context.scene
    if hasattr(scene.render, "use_persistent_data"):
        scene.render.use_persistent_data = True
    scene.render.filepath = str(output_dir / "####")
    # QA and acceptance contracts currently require PNG evidence/output.
    scene.render.image_settings.file_format = "PNG"

    if frames:
        for frame in [int(v) for v in frames]:
            scene.frame_set(frame)
            scene.render.filepath = str(output_dir / f"{frame:04d}.png")
            bpy.ops.render.render(write_still=True)
    else:
        scene.render.filepath = str(output_dir / "####")
        bpy.ops.render.render(animation=True)

    rendered = sorted(output_dir.glob("*.png"))
    if not rendered:
        raise RuntimeError(f"render wave job produced no frames: {blend}")
    return {
        "shot_id": job.get("shot_id"),
        "blend": str(blend),
        "output_dir": str(output_dir),
        "frames": len(rendered),
        "elapsed_seconds": time.perf_counter() - started,
    }


def main() -> None:
    ns = _args()
    payload = json.loads(Path(ns.jobs).read_text(encoding="utf-8"))
    jobs = payload.get("jobs", [])
    report = {
        "status": "ok",
        "blender_version": bpy.app.version_string,
        "jobs": [],
        "started_epoch": time.time(),
    }
    try:
        for job in jobs:
            report["jobs"].append(_render_job(job))
    except Exception as exc:
        import traceback
        report.update({"status": "blocked", "error": str(exc), "traceback": traceback.format_exc()})
    report["finished_epoch"] = time.time()
    out = Path(ns.report)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if report["status"] != "ok":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
