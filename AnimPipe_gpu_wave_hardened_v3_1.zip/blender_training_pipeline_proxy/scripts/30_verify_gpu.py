#!/usr/bin/env python3
from __future__ import annotations

import json, platform, re, subprocess
from pathlib import Path

PREFLIGHT=Path('reports/environment/hardware-preflight.json')
OUT=Path('reports/environment/hardware-verified.json')


def version_tuple(s: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r'\d+', s)[:3])


def main() -> None:
    if not PREFLIGHT.exists() or json.loads(PREFLIGHT.read_text()).get('status') != 'pass':
        raise SystemExit('passing preflight report required')
    q='index,uuid,name,memory.total,memory.free,driver_version'
    result=subprocess.run(['nvidia-smi', f'--query-gpu={q}', '--format=csv,noheader,nounits'], check=True, text=True, capture_output=True)
    rows=[x.strip() for x in result.stdout.splitlines() if x.strip()]
    if len(rows) != 1:
        raise SystemExit(f'expected exactly one GPU, found {len(rows)}')
    parts=[p.strip() for p in rows[0].split(',')]
    if len(parts) != 6:
        raise SystemExit(f'unexpected nvidia-smi output: {rows[0]}')
    index, uuid, name, total, free, driver=parts
    total_i=int(total)
    checks={
      'gpu_count_exact': len(rows)==1,
      'tesla_t4_exact_family': 'T4' in name.upper(),
      'memory_t4_range': 15000 <= total_i <= 16000,
      'uuid_present': uuid.startswith('GPU-'),
      'driver_optix_floor': version_tuple(driver) >= (575,0,0),
    }
    runtime_os = platform.system()
    documented_driver_profile = (
      {
        'os': 'Linux',
        'azure_profile': 'NCasT4_v3 GRID',
        'documented_version': '595.58.03-grid-azure',
      }
      if runtime_os == 'Linux'
      else {
        'os': runtime_os,
        'azure_profile': 'NCasT4_v3 vGPU20.2 on supported Windows OS',
        'documented_version': 'vGPU20.2',
      }
      if runtime_os == 'Windows'
      else {
        'os': runtime_os,
        'azure_profile': 'verify against current Azure N-series documentation',
        'documented_version': None,
      }
    )
    report={
      'status':'pass' if all(checks.values()) else 'fail',
      'checks':checks,
      'azure_sku':json.loads(PREFLIGHT.read_text())['azure']['vmSize'],
      'gpu':{'index':int(index),'uuid':uuid,'name':name,'memory_total_mib':total_i,'memory_free_mib_at_verify':int(free),'driver_version':driver},
      'runtime_os': runtime_os,
      'documented_driver_profile': documented_driver_profile,
    }
    OUT.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))
    if report['status']!='pass':
        raise SystemExit('post-driver hardware verification failed')


if __name__=='__main__':
    main()
