# Final Architecture

## 1. Source → build → inspect → revise

```text
Narrative / training objective
        │
        ▼
Animation Director
        │
        ├── scene director-script YAML
        └── shot YAML
                │
base < project < scene < shot < CLI
                │
                ▼
            OmegaConf
                │
                ▼
           Pydantic v2
                │
                ▼
      resolved_config.json + hash
                │
                ▼
       Blender 5.2.1 builder
                │
        ┌───────┴─────────┐
        ▼                 ▼
  generated .blend   preview frames
                          │
                 deterministic QA
                          │
                          ▼
                    Qwen2.5-VL critic
                          │
                    structured JSON
                          │
                    config patch only
                          │
                          └──► validate/rebuild, capped loop
```

The production builder never depends on a live LLM or MCP.

## 2. Runtime separation

### Host Python 3.11
Owns OmegaConf/Pydantic merge, CLI, asset manifest validation, TTS clients, Whisper orchestration, VLM QA client, hashing, SSIM/pHash, scheduling, provenance, and n8n/Flamenco integration.

### Blender 5.2.1 embedded Python 3.13
Owns only scene construction and Blender-native validation. Input is a fully resolved JSON artifact.

### Python 3.13 `bpy` test environment
Used for integration/unit checks against `bpy==5.2.1`. Passing here is useful but not a substitute for testing in the Blender executable.

### Containers
- `ollama`: local visual critic; GPU; model stays resident only for a bounded VLM review wave, then is explicitly unloaded before Cycles resumes.
- `kokoro`: local OpenAI-compatible TTS; CPU by default.
- optional Kokoro GPU override: same API, must acquire GPU lock before use.

## 3. Hardware trust chain

```text
Azure IMDS + /proc + PCI inventory (read-only)
               │
               ▼
 hardware-preflight.json
 expected SKU == Standard_NC4as_T4_v3
               │
               ▼
 host packages / documented Azure GRID procedure
               │
             reboot
               │
               ▼
 nvidia-smi exact GPU identity check
 Tesla T4 × 1 + UUID + VRAM + driver
               │
               ▼
 hardware-verified.json
               │
        every GPU workload
               │
 fresh UUID/model/VRAM check + lock + admission gate
```

A config declaration can never establish hardware identity.

## 4. GPU resource policy

One T4 means compute is serialized deliberately in v1.

Workloads requiring `gpu.compute`:
- Blender Cycles/OptiX render or OptiX denoise
- Ollama/Qwen2.5-VL preview critique
- faster-whisper GPU mode
- optional Kokoro GPU mode

The lock is an OS `flock`, not merely a marker file. A JSON sidecar records holder metadata. Before acquisition, `gpu_lock.py` revalidates the live GPU UUID against the verified hardware manifest. The VRAM admission gate then evaluates configured estimated peak + safety reserve against total and current free memory.

Ollama stays resident for one bounded review wave via `resource_policy.gpu.vision_keep_alive`, then is explicitly unloaded before the next Cycles wave. Cycles and Qwen never share the T4 compute lane concurrently.

## 5. Semantic hierarchy

### Director script = scene intent
The scene schema adopts Anim-Director's useful semantic decomposition: instructional objective, character roles/profiles, interior/exterior setting, continuity, and ordered scene events/beats.

### Shot config = realization
Shot config carries camera, blocking, NLA action sequencing, lighting, dialogue timing, compositing, overlays, output and preview values.

### Resolved config = Blender contract
All defaults and overrides are compiled to a complete object. The builder never asks where a value came from.

## 6. Asset subsystem

Every asset is admitted before use. `pipe asset doctor <id>` validates the manifest, then optionally launches Blender headless for datablock/rig/action/shape-key inspection.

Character contracts include:
- logical ID + semantic version + checksum
- Blender compatibility
- linked collection/datablock
- units/up/forward/scale
- armature identity and retarget profile
- named action vocabulary
- viseme mapping
- geometry/texture complexity estimates
- provenance/license

A missing action is an asset contract failure, not an invitation to hardcode a one-off animation.

## 7. Performance grammar

Claude composes named actions on NLA tracks. Raw keys remain valid for blocking transforms, procedural constraints, camera moves, viseme shape keys, and asset-authoring work, but not as the normal performance vocabulary.

The supplied Blender-agent `animating-basics` skill is used for Blender 5.x layered Action API knowledge. Its separate custom `anim(...)`, `pose(...)`, and `rig(...)` tools are not assumed to exist.

## 8. Preview QA loop

Each preview run produces:
1. deterministic checks: missing frame, alpha/black-frame/NaN checks where applicable, config/render manifest consistency;
2. exact SHA-256 identity;
3. pHash + SSIM against an approved baseline preview;
4. contact sheet / beat frame set;
5. structured local VLM review against the director intent and instructional rubric.

The VLM returns a schema-validated patch proposal targeting allow-listed config paths. It cannot edit code or assets. The proposed candidate is Pydantic-validated before rebuild. Iteration count and minimum improvement are config values.

## 9. MCP boundary

The official Blender Lab MCP is known to the `blender-debugger` agent only. It attaches to a scratch Blender instance loaded from a copied build artifact. The debugger can inspect, render thumbnails, search Blender docs and execute diagnostic Python. It writes a structured patch proposal, never production code.

## 10. Storage

Persistent disk / Blob:
- repository and canonical assets
- final renders/published video
- build and render manifests required for provenance

Azure temporary disk:
- render scratch
- intermediate frames that can be regenerated
- TTS/model caches if loss is acceptable
- MCP scratch copies

Use quotas/cleanup because EXR sequences expand quickly.

## Proxy Animation Kit acceptance architecture

The first full-system target is `proxy_clay_v1`, generated from `proxy_kit/kit.yaml`. An Asset Factory agent owns reusable asset generation; the Animation Director owns semantic composition through the admitted vocabulary. The Proxy Kit does not create a second render pipeline: generated assets are registered in the same logical manifest and consumed by the same deterministic Blender builder, GPU gates, QA and FFmpeg delivery stages.

The style boundary is explicit. Scene/shot semantics reference material roles, action names, camera templates, light presets and logical assets rather than final colors/meshes. A later style package may replace those assets while preserving the same interfaces.

## Single-T4 wave scheduler

The T4 is modeled as one exclusive compute lane plus an optional encode lane. CPU-safe work fans out with `cpu_workers` / `build_workers`; GPU work is grouped to reduce startup and CUDA/OptiX context churn.

```text
CPU: compile + TTS + Rhubarb ─┐
CPU: deterministic builds ────┴─ parallel
                               ↓
GPU compute: Cycles preview/final wave
                               ↓
CPU: delivery preview/contact sheets ─ parallel
                               ↓
GPU compute: resident Qwen review wave
                               ↓
only dirty shots repeat
                               ↓
CPU/NVENC: encode → concat
                               ↓
CPU + GPU review: final-film acceptance
```

`render_wave.py` holds the compute lock across all jobs in a render wave and runs one Blender process. `qa_wave.py` holds the lock while Qwen remains resident across the review set. NVENC overlap is disabled by default and must be measured before enabling `allow_nvenc_overlap_with_compute`.

## Acceptance evidence boundary

A slim source handoff must not claim visual acceptance unless it carries the compact QA evidence bundle. `pipe proxy evidence` exports contact sheets and reports while excluding regenerable frame trees and secrets.
