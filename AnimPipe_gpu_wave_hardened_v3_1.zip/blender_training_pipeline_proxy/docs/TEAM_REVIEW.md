# Multi-Team Pipeline Review — 2026-09-11

Seven independent review tracks were applied to the updated builder. This document records findings, fixes, and what still requires the real Azure VM.

## 1. Architecture & contracts

**Finding:** The host/Blender boundary remains correct, but several schema fields had drifted ahead of implementation.

**Resolved:** Follow Path, set dressing, post-render comp, retarget normalization, typed caption/overlay contracts, path asset kind, and bounded QA orchestration now have executable implementations or explicit admission semantics.

## 2. Blender / bpy compatibility

**Finding:** The schema still admitted the pre-5.0 engine ID `BLENDER_EEVEE_NEXT`. Blender 5.x uses `BLENDER_EEVEE`. Blender 5.x also requires `ImageFormatSettings.media_type` to be selected before `file_format`.

**Resolved:** IDs and setup order corrected. Added `scripts/45_blender_api_contract_probe.py` to assert the exact APIs used by the builder under the pinned Blender 5.2.1 executable.

**Verified externally:** current Blender release/API documentation, NLA slots, Follow Path properties, background `gpu.init()`, and Cycles texture simplification behavior.

## 3. GPU / Azure runtime

**Finding:** CLI rendering could bypass the live hardware/VRAM gate when `--config` was omitted, and NVENC encoding had no GPU lock.

**Resolved:** `pipe render frames` now requires resolved config and always selects `cycles_preview` or `cycles_final` admission policy. NVENC encode also uses the exclusive GPU scheduler. Live UUID/name/VRAM validation remains authoritative; the manifest's texture estimate is only an early warning.

**Verified externally:** Microsoft still documents `595.58.03-grid-azure` for NCasT4_v3 and requires Secure Boot/vTPM disabled for the manual GRID procedure.

## 4. Claude agents / skills

**Finding:** Existing boundaries remain sound: only the debugger gets official Blender MCP and no agent preloads more than four skills. The operational skills did not yet mention the now-executable QA loop or Follow Path behavior.

**Resolved:** project skills updated to describe executable gates and boundaries. Vendor Blender-agent custom MCP operations remain inactive; only standard-bpy-compatible knowledge is used.

## 5. Audio / TTS / lipsync

**Finding:** Kokoro and Rhubarb modules existed but had no first-class CLI workflow; faster-whisper was installed but not exposed for alignment.

**Resolved:** added `pipe audio synthesize`, `pipe audio visemes`, and `pipe audio align`. Alignment is CPU/int8. The supported host environment installs neither a CUDA development toolkit nor CUDA Python user-space runtime for Whisper.

## 6. Render QA / vision loop

**Finding:** `review_iteration` enforced one critic step but did not itself own build→render→review→revision.

**Resolved:** `pipe qa run-loop` now owns the bounded loop. Each candidate is allow-list patched and Pydantic-validated before the next build. Cycles preview and Qwen VLM calls independently pass through the live GPU/VRAM gate. The loop terminates on pass, explicit escalation, insufficient score improvement, build failure, or revision cap.

## 7. Operations / delivery

**Finding:** FFmpeg assumed frame 0, while Blender shots typically start at frame 1 or another configured frame. Post-render comp fields were not applied.

**Resolved:** encode uses `render.frame_start`; LUT, captions, and overlays are applied in FFmpeg; captions require explicit frame bounds. Smoke tests now check required FFmpeg filters and run the unit suite plus Blender API probe.

## External verification snapshot

As of 2026-09-11:

- Blender 5.2.1 is the active 5.2 LTS patch release.
- official `bpy==5.2.1` requires CPython 3.13; host pipeline stays Python 3.11.
- `fake-bpy-module-5.2==20260730` is the current version-specific IDE stub package.
- Microsoft documents GRID `595.58.03-grid-azure` for NCasT4_v3.
- FFmpeg documents `lut3d` and `overlay`; smoke test additionally verifies the installed build exposes `subtitles`.

## VM-only acceptance remaining (historical first-review list)

The Azure run has since proven several of these checks; the 2026-09-21 addendum below is authoritative for the current state. The original list is retained for traceability:

1. Azure IMDS reports the expected SKU.
2. the actual PCI/GPU identity is one Tesla T4 with expected VRAM.
3. GRID installation succeeds and survives reboot.
4. Blender 5.2.1 sees OptiX and passes the API contract probe.
5. FFmpeg's installed build exposes NVENC + required filters.
6. NVIDIA Container Toolkit passes T4 through to Ollama.
7. The configured Qwen VLM and Kokoro service smoke calls succeed.
8. one real admitted character/set/path asset completes build→preview→QA→encode.

## 8. Security & configuration boundaries

**Finding:** delivery artwork initially resolved raw paths and overlay coordinates accepted unrestricted FFmpeg expressions. The local Kokoro service also generated an API key that the host CLI did not automatically read.

**Resolved:** LUT/overlay artwork is now referenced only by logical manifest IDs; manifest file paths are constrained to relative paths under the configured asset root and checked again after resolution. Overlay coordinates accept only simple arithmetic tokens, preventing filter-graph separator/quoting injection. `pipe audio synthesize` now reads `KOKORO_API_KEY` from the process environment or `infra/kokoro.env`, matching the service bootstrap.

## Local release validation

The reviewed bundle is regenerated and tested after all fixes. See `FINAL_VALIDATION.md` and `reports/final-validation.json` for exact machine-readable results. Target-GPU checks remain deliberately separated from source validation because they can only be proved on the Azure VM.


## 2026-09-21 Azure evidence hardening addendum

A second multi-track review used the Azure-generated status/reports as the ground truth. The prior per-shot report gave every dimension of all ten shots exactly 0.90 while delivered-output review separately documented a shot-6 prop-continuity defect; the critic path had executed but its acceptance gate was too permissive. The current implementation adds required visual observables, per-dimension floors, observable-specific sampling frames, a three-shot block interaction for shots 6–8, and post-concat film QA.

Throughput is now wave-oriented for the single 16 GiB T4: CPU preparation/audio and scene builds fan out, dirty shots render in one Blender/Cycles process with Persistent Data enabled, the Qwen model is then kept resident for one review wave, and only revised shots repeat. VLM teardown occurs while the same compute lock is held before the next live VRAM admission, preventing a Cycles/Ollama transition race. CPU libx264 encode concurrency is capped at one on the 4-vCPU target unless telemetry justifies a change.

Clock correctness was also tightened. Required-observable frames are forced into the QA evidence set; caption/overlay timing is relative to Blender `frame_start`; TTS is delayed to the authored dialogue start frame and padded through the shot; unchanged TTS/viseme artifacts are cached; narration duration is checked against the authored dialogue window. Final-film acceptance now uses ffprobe plus FFmpeg freeze/silence detection and a transition-focused VLM review.

The exact commit-pinned slim ZIP inspected for this review still contained only `build/.gitkeep` and `logs/.gitkeep`, not the generated media/log contents. The release therefore adds `pipe proxy evidence` and a release-packager `--include-evidence` option so future slim handoffs preserve the contact sheets and QA JSON used to make acceptance decisions without committing the reproducible full render tree.

The existing Azure evidence came from a Windows/TCC runtime. Linux bootstrap scripts and Linux GRID package-version guidance remain the automated provisioning path, while runtime acceptance is OS-aware: a qualified Windows host is validated by live GPU identity/VRAM, supported driver/OptiX floor, Blender API probes, and actual workload success rather than by equality to the Linux GRID package version.

## 2026-09-21 v3 fan-out review

The hardening pass was divided using the repository agent contracts as independent review lanes: architecture/contracts (`pipeline-architect`), runtime/GPU (`environment-bootstrapper` + `pipeline-runner`), Blender/asset correctness (`blender-builder` + `asset-validator`), performance/continuity (`animation-director`), audio clock (`audio-lipsync-engineer`), and delivered-output QA (`render-qa`). In this chat environment these were review roles rather than independently executing Claude Code processes; `CLAUDE.md` now tells the Azure Claude Code orchestrator how to launch and reconcile those lanes without concurrent mutation of the same files.

Key outcomes: one T4 is intentionally one compute lane; safe parallelism is concentrated in CPU config/TTS/build/evidence work. Cycles jobs are batched into a Blender render wave; VLM jobs are batched into a resident Ollama wave; dirty-shot revisions alone repeat. Required visual observables and per-dimension floors prevent the uniform-score false positive seen in the prior Azure report. The shot-6 acceptance fixture now uses the block/grip contract rather than the visually unstable pointer. Final-film QA additionally validates concat stream signatures, segment duration, dialogue audio onset, transition freezes, interior silence and delivered visual continuity.

Current external verification also distinguishes platform provisioning from runtime qualification: Microsoft documents NCasT4_v3 as a 16-GB Tesla T4 Windows GRID-capable family, while the original Linux scripts retain the Linux GRID provisioning path. The existing Azure evidence is Windows/TCC and is therefore accepted by live identity/VRAM, driver floor, Blender API and workload probes rather than an exact Linux package-version match.

## 9. Source CI gate

A CPU-only GitHub Actions workflow now runs Python 3.11 dependency installation, schema regeneration, skill packaging, bundle validation, pytest, Ruff, mypy, and compile checks. It intentionally does not claim GPU/render acceptance; Azure remains authoritative for T4/OptiX/Ollama/Kokoro and delivered-film evidence.
