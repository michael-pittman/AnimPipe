# Proxy Animation Kit v1

## Purpose

The Proxy Animation Kit proves the automation architecture before the project commits to a final art style. It is intentionally monochrome, low-detail, texture-free and modular. The test succeeds when the kit can be regenerated from contracts and the acceptance film can be rebuilt without manually editing Blender files.

The proxy kit is **not** a look-development target. It is a diagnostic language for motion, staging, facial/lip animation, camera grammar, lighting, props, graphics and delivery.

## Source of truth

- `proxy_kit/kit.yaml` — generated-asset specification and canonical action vocabulary.
- `config/proxy/style.yaml` — role-based `proxy_clay_v1` style contract.
- `config/proxy/vocabulary.yaml` — semantic camera and lighting template libraries.
- `config/proxy/acceptance/` — 10-shot system acceptance film.
- `scripts/100_generate_proxy_kit_blender.py` — deterministic Blender asset generator.

Generated files beneath `assets/proxy/`, `assets/assets.proxy.yaml`, and `build/assets.proxy.resolved.json` are build artifacts and should be regenerated rather than hand edited.

## Visual language

The kit uses a single neutral hue family with role-separated values:

| Semantic role | Purpose |
|---|---|
| `background` | lightest environment plane/block |
| `set` | mid-light architecture and furniture |
| `character` | darker primary subject |
| `foreground` | darkest occlusion/depth elements |
| `prop` | middle-value interaction objects |
| `focus` | bright screen/eyes/high-value focus item |
| `ui` | graphics and overlay elements |

The style contract forbids textures, phototextures, cloth, hair simulation, particle effects and displacement. The material implementation is simple Principled BSDF so the same assets work in EEVEE preview and Cycles final validation.

## Generated asset inventory

`pipe proxy generate` creates:

### Character

`char.proxy_instructor` / `COL_PROXY_CHARACTER` / `RIG_PROXY`

The mannequin is rigid bone-parented geometry built from simple primitives. This intentionally separates animation failures from skin-weight/topology failures.

Rig capabilities:
- root/pelvis/spine/chest/neck/head;
- left/right upper arm, forearm and hand;
- left/right thigh, shin and foot;
- `hand.L` / `hand.R` attachment bones;
- normalized retarget profile `proxy_rig_v1`.

### Motion Actions

Reusable motion Actions:
- `idle_neutral_loop`
- `walk_cycle`
- `turn_left_90`
- `turn_right_90`
- `gesture_present`
- `point_left`
- `point_right`
- `wave`
- `head_nod`
- `head_shake`
- `reach_grab`
- `place_release`

Held one-frame pose Actions:
- `pose_neutral`
- `pose_present`
- `pose_listen`
- `pose_think`
- `pose_point`
- `pose_hold`
- `pose_ready`
- `pose_end`

The director composes these through existing NLA tracks rather than inventing shot-specific armature keyframes.

### Face contract

Rhubarb visemes:
- `VISEME_A` through `VISEME_H`
- `VISEME_X` rest

Proxy facial controls:
- `BLINK`
- `BROW_UP`
- `BROW_DOWN`
- `EXP_smile`
- `EXP_frown`
- `EXP_surprise`
- `LOOK_LEFT`
- `LOOK_RIGHT`

These are exaggerated diagnostic morphs. They prove that facial-cue and lip-sync channels are functioning; they are not intended as final facial art.

### Environment

`set.proxy_room` contains a modular neutral room with:
- floor/back/side architecture;
- presentation screen;
- pedestal/table/chair;
- two foreground frame objects;
- two background depth blocks.

The environment intentionally includes FG/MG/BG value separation so occlusion, parallax, framing and VLM composition judgment can be evaluated.

### Props

Six collection-backed props are generated so each instance can receive a writable Library Override:
- `prop.proxy_block`
- `prop.proxy_cylinder`
- `prop.proxy_card`
- `prop.proxy_document`
- `prop.proxy_tablet`
- `prop.proxy_pointer`

Shot config can schedule a prop attachment to an admitted character bone and an explicit release transform. Runtime prop interaction never invents a bone name or writes back to the source asset.

### Camera paths

- `path.proxy_short_arc`
- `path.proxy_side_dolly`

Both are manifest-backed CURVE objects for Follow Path testing.

### Graphics

Transparent generated overlays:
- `overlay.proxy.title_panel`
- `overlay.proxy.highlight_ring`
- `overlay.proxy.arrow`
- `overlay.proxy.focus_frame`
- `overlay.proxy.end_card`

They exercise the existing manifest-resolved FFmpeg overlay stage without adding final brand art.

## Semantic camera vocabulary

The proxy config supplies seven templates:
- `wide_stage`
- `medium_presenter`
- `close_face`
- `over_shoulder`
- `insert_prop`
- `path_move`
- `topdown`

Each template defines lens, subject-relative camera offset and a subject target offset. The builder creates a child aim target when required so templates frame the torso/face rather than blindly tracking the character root at floor height.

## Lighting vocabulary

Four deterministic presets are supplied:
- `high_key_neutral` — default diagnostic light;
- `three_point_character` — character readability;
- `screen_demo` — presenter + display balance;
- `dramatic_test` — deliberate high-contrast stress case.

Creative light values remain in validated config rather than builder literals.


## Diagnostic control strategy

Proxy v1 intentionally has **zero required third-party art assets**. The simple generated primitives are the deterministic control fixtures: they remove topology, texture, cloth/hair, and style dependencies while exercising the same manifest/builder interfaces as future production assets. External CC0 control assets can later be registered under separate logical IDs for differential debugging, but they are not vendored into Git or required for the acceptance film.

## Asset Factory workflow

```bash
.venv/bin/pipe proxy validate
.venv/bin/pipe proxy generate
```

Generation performs:
1. Pydantic validation of `proxy_kit/kit.yaml`;
2. deterministic Blender generation of character/set/props/paths;
3. deterministic Pillow generation of graphics overlays;
4. SHA-256 manifest construction;
5. manifest JSON export;
6. static Asset Doctor for every logical asset;
7. a saved-file Blender doctor for the generated character, including collection, armature, all Actions, Action slots, viseme set and facial controls.

No generated asset is considered admitted if those checks fail.

## Acceptance film

Run after Phase-0 Azure validation, local AI startup and proxy generation:

```bash
.venv/bin/pipe proxy acceptance --preview --audio
```

The acceptance controller builds ten 5-second shots (~50 seconds nominal), exercising:

1. walk cycle + blocking;
2. speech + gesture layering;
3. close-up face controls + lip sync;
4. pointing + caption/overlay delivery;
5. foreground/midground/background staging;
6. reach + prop attachment;
7. held prop + speech/face motion;
8. prop release/placement;
9. manifest-controlled Follow Path camera;
10. nod + wave + end-card overlay.

For every shot the controller:
- compiles OmegaConf layers into Pydantic-validated resolved JSON;
- generates Kokoro speech and Rhubarb cues when audio is enabled;
- runs the bounded production **build → preview → contact sheet → Qwen2.5-VL review → validated config revision → rebuild** loop;
- requires the visual critic to reach `pass` rather than silently accepting an escalation;
- builds a fresh delivery `.blend` from the QA-approved resolved config;
- acquires the configured GPU lock for rendering;
- encodes through the existing NVENC/FFmpeg delivery path;
- concatenates the compatible segments into `build/proxy_acceptance/proxy_acceptance_film.mp4`.

Visual QA is enabled by default. Use `--no-qa` only to isolate Blender/render infrastructure, `--no-audio` to isolate visual behavior, and `--final` only after preview acceptance succeeds.

## Definition of done

The proxy milestone passes when, from a clean checkout on the qualified Azure VM:

```bash
.venv/bin/pipe proxy validate
.venv/bin/pipe proxy generate
.venv/bin/pipe proxy acceptance --preview --audio
```

produces the final acceptance film without opening Blender interactively and without manual edits to generated `.blend` files.

At that point a future art-style package can replace the proxy assets while preserving the director-script, action/camera/lighting vocabulary interfaces and the production builder.
