# External Verification Sources

Verified for the 2026-09-21 GPU-hardening pass. These are implementation references, not runtime substitutes for the VM probes.

| Area | Source | Pipeline use |
|---|---|---|
| Blender Cycles Persistent Data | https://docs.blender.org/manual/en/5.2/render/cycles/render_settings/performance.html | Blender documents Persistent Data as keeping render data in memory for faster re-renders/animation at the cost of memory. The render wave enables it but still respects the VRAM admission policy. |
| Blender Cycles GPU Compute | https://docs.blender.org/manual/en/5.2/render/cycles/render_settings/index.html | Confirms GPU Compute is a supported Cycles device mode. Live OptiX availability is still proved by the VM smoke probe. |
| Ollama FAQ model residency/concurrency | https://docs.ollama.com/faq | Documents negative `keep_alive` for residency, `0` for immediate unload, and the VRAM/context cost of parallel requests. The scheduler keeps one Qwen model resident for a review wave with one parallel inference lane, then unloads it before Cycles resumes. |
| Qwen2.5-VL 3B | https://ollama.com/library/qwen2.5vl:3b | Current T4-proven baseline: text + image input, ~3.2 GB package, Ollama 0.7+ requirement. |
| FFmpeg `freezedetect` | https://ffmpeg.org/ffmpeg-filters.html#freezedetect | Post-concat detector for frozen video intervals, especially shot joins. |
| FFmpeg `silencedetect` | https://ffmpeg.org/ffmpeg-filters.html#silencedetect | Post-concat audio dead-air detector when speech is expected. |
| Azure NCasT4_v3 Windows driver matrix | https://learn.microsoft.com/en-us/azure/virtual-machines/windows/n-series-driver-setup | Confirms NCasT4_v3 uses a 16-GB Tesla T4 and current Windows GRID/vGPU support. Runtime qualification remains live-probe based. |

## Runtime evidence priority

The external documentation verifies API semantics. Actual acceptance continues to rely on the generated Azure reports for GPU identity, driver, Blender version/API probes, FFmpeg filters and container GPU access.
