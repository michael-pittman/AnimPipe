# Final Architecture Decisions

1. OmegaConf is the initial layering mechanism. Hydra is deferred.
2. Hardware identity is proven before any mutable GPU setup and revalidated before every GPU workload.
3. Azure NCasT4_v3 follows Microsoft's current GRID procedure; post-reboot verification records exact GPU UUID/model/VRAM/driver.
4. No host CUDA Toolkit is installed. Workload-specific CUDA user-space libraries inside containers/Python packages are allowed when required.
5. Blender 5.2.1 LTS is pinned; host pipeline Python is 3.11 and `bpy` test Python is 3.13.
6. Assets are a first-class admitted subsystem with logical IDs, hashes, coordinate/rig/action/viseme contracts and Blender-backed inspection.
7. Anim-Director's director-script decomposition is adapted as the semantic scene layer; shot config is the Blender realization layer.
8. SceneCraft's render-inspect-revise pattern is adapted as a bounded, structured preview QA loop. The VLM may propose config changes only.
9. Local VLM QA uses Docker Ollama + `qwen2.5vl:3b` by default on the T4. The model stays resident across a review wave and unloads before Cycles resumes.
10. Kokoro CPU is the default local TTS service. GPU Kokoro and Orpheus/Ollama are optional providers, not baseline dependencies.
11. One host `flock` serializes GPU compute in v1. VRAM admission is evaluated only after live hardware verification.
12. Final renders are image sequences. FFmpeg/NVENC performs delivery encoding.
13. QA uses SHA-256 + pHash + SSIM + semantic VLM review.
14. Visual Studio Code Remote SSH is the documented IDE topology.
15. The official Blender Lab MCP is the only configured live Blender MCP and is debugging-only.
16. The user-supplied Blender-agent archive contributes selected standard-`bpy` skills; custom extension-dependent tools are not assumed.
17. Claude agents preload at most four concise, single-purpose skills each.
