# Azure GPU Evidence Review — 2026-09-21

Source reviewed: commit-pinned `blender_training_pipeline_proxy_slim.zip` at AnimPipe commit `00e780a8482367ef1d7a64143a4264db552006f1`, plus the Azure-generated machine-readable reports contained in that archive.

## Artifact accuracy assessment

### High-confidence runtime evidence

The hardware verification report records one Tesla T4 with 16384 MiB, a stable GPU UUID and the expected Azure SKU. The Blender API-contract report records Blender 5.2.1 and confirms the engine/NLA/Follow Path APIs the pipeline relies on. Proxy generation reports all declared action, set, path and prop assets and a successful deep character doctor pass.

These reports are internally consistent with the pipeline's runtime contracts.

### QA evidence that should not be trusted as final sign-off

`acceptance_results_combined.json` reports 10/10 pass with a 0.90 mean, and every individual dimension is also exactly 0.90. Shot 6 receives a 0.90 continuity score even though `PIPELINE_STATUS.md` records a delivered pointer drift/torso-crossing defect. The uniform scores and contradiction indicate an overly permissive/calibrated critic gate.

The source hardening therefore treats the old report as execution evidence only and adds required-observable gating plus a post-concat film gate.

### Missing visual media in the slim export

Central-directory inspection of the exact commit-pinned ZIP found only `build/.gitkeep` and `logs/.gitkeep`; no `.blend`, `.mp4`, `.wav`, EXR, generated render frames, QA contact sheets, or runtime log payloads were actually packaged. Only static proxy overlay PNGs are included. Direct visual confirmation of the previous rendered film is therefore impossible from that archive alone.

Subsequent QA-enabled acceptance runs now automatically export `reports/acceptance/qa_evidence_bundle.zip`; it contains contact sheets and QA JSON while remaining small enough for Git or chat review.

## Efficiency review

The single 16 GiB T4 should be treated as one compute lane. Cycles/OptiX and Qwen should not contend for it. The optimized schedule is CPU-parallel preparation/builds followed by a long render wave, then a long VLM review wave. Revised shots alone re-enter subsequent waves. CPU libx264 delivery can run in parallel after rendering; NVENC remains resource-gated if enabled.

## 2026-09-21 v3 hardening decisions

- Required-observable frame numbers are forcibly added to preview evidence so semantic checks cannot be sampled away.
- Audio, visemes, captions and overlays share the Blender `frame_start` clock; TTS is delayed to the authored dialogue start and narration longer than its dialogue window is rejected.
- Final-film QA verifies concat stream signatures, per-segment duration and dialogue onset in addition to freeze/silence/transition review.
- Ollama is pre-warmed once per VLM wave, kept resident across that wave, explicitly unloaded in `finally`, and the next GPU workload waits for live free-VRAM recovery.
- Wave telemetry records preparation, QA, accepted builds, render, encode, concat and final-film QA durations for measured tuning on the 4-vCPU/1-T4 target.
