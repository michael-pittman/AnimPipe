# Local AI Services: Ollama Vision + Kokoro TTS

## Ollama visual QA

The Azure/T4-proven baseline is `qwen2.5vl:3b`. It is a text+image model small enough to coexist operationally with this 16 GiB T4 **when workloads are scheduled in waves rather than concurrently**.

Ollama binds only to `127.0.0.1:11434`; it is never exposed publicly. Visual reviews use structured JSON output and temperature 0.

### Residency policy

Cycles/OptiX and the VLM share the same compute resource. The supported sequence is:

```text
CPU config/audio/build fan-out
        ↓
explicitly unload VLM
        ↓
one Cycles render wave under gpu.compute lock
        ↓
load Qwen once
        ↓
one serial VLM review wave under gpu.compute lock
        ↓
unload Qwen before releasing the lock
        ↓
rerender only dirty/revised shots
```

`resource_policy.gpu.vision_keep_alive` controls model residency *within* a review wave. Do not prewarm the model immediately before Cycles. Do not run Qwen and Cycles simultaneously on the single T4.

`infra/Modelfile.qwen25vl` documents the baseline context/temperature settings. The actual configured model comes from `QWEN_VISION_MODEL` / `qa.vision_model`.

## Kokoro

Default TTS is Kokoro in a CPU Docker service bound to `127.0.0.1:8880`. This preserves the T4 for Blender and visual QA. Shot preparation may synthesize independent lines concurrently within `resource_policy.cpu_workers`.

An optional GPU Kokoro compose override remains experimental. If enabled, it must acquire `gpu.compute` and therefore cannot overlap Cycles or Qwen.

## Why not Ollama TTS?

Ollama can host speech-token models, but the token-to-audio path requires extra decoder/frontend plumbing. Kokoro remains the deterministic baseline; an Ollama speech provider can be added behind the TTS provider boundary later.
