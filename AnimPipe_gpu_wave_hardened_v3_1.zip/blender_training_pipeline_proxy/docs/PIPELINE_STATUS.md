# Pipeline Status — 2026-09-21

This is the live source-state reference after reviewing the Azure GPU run captured in `blender_training_pipeline_proxy_slim.zip`.

## What the Azure run proved

- Azure reported `Standard_NC4as_T4_v3` with one Tesla T4 / 16384 MiB and passed the project's live identity checks.
- Blender 5.2.1 passed the runtime API contract used by the builder.
- Proxy generation and deep character Asset Doctor completed successfully.
- All ten acceptance shots built/rendered far enough to produce per-shot QA reports.
- Portrait framing, captions/overlays, sparse-preview timing and visible face/lip proxy motion were iterated on the real runtime.

## Evidence-quality finding

The previous combined QA report is **not sufficient final sign-off**. It assigned 0.90 to every scored dimension of every shot, including shot 6, while delivered-output review separately recorded a visible pointer-continuity defect. Treat that report as evidence that the QA path executed, not evidence that calibration was correct.

The uploaded slim ZIP contains source/config/reports and overlay PNGs but **does not contain the generated `build/` media tree, `.blend` files, final MP4, audio, or rendered shot frames**. Therefore the film pixels cannot be independently re-reviewed from that archive. The new compact evidence exporter prevents this gap on subsequent handoffs.

## Source fixes now implemented

- Shots 6–8 now form one continuous block interaction: shot 6 grabs the block with a bounded `reach_grab` followed by `pose_hold`, shot 7 maintains the same held-block contract, and shot 8 releases it. This replaces the visually unstable pointer experiment while keeping the pointer asset available for future tests.
- Required visual observables gate semantic behaviors; a generic VLM pass no longer overrides missing evidence.
- GPU execution is wave-based: parallel CPU preparation/build, one Cycles render wave, one resident VLM review wave, then dirty-shot-only retries.
- Qwen baseline is the Azure-proven `qwen2.5vl:3b`.
- VLM residency is explicitly released under the compute lock before Cycles resumes; admission waits for live VRAM to drain rather than assuming model unload is instantaneous.
- Final concatenated-film QA now checks stream signatures, authored-vs-encoded segment duration, dialogue audio onset, frozen intervals across joins, interior silence and visual transition continuity.
- QA-enabled acceptance automatically creates a compact review bundle for future off-VM inspection; `pipe proxy evidence` can regenerate it or optionally include the MP4.
- Release packaging excludes caches, runtime secrets and heavyweight reproducible build artifacts.

## Current acceptance state

**Source hardened; Azure rerun required.**

The next Azure run must regenerate the Proxy Kit and acceptance film with this source, then pass both per-shot observable QA and post-concat final-film QA. Until that run produces a compact evidence bundle, the pipeline should not be marked final-delivery accepted.

## Next Azure commands

```bash
.venv/bin/pipe proxy validate
.venv/bin/pipe proxy generate
.venv/bin/pipe proxy acceptance --preview --audio --qa
# Evidence is exported automatically. Optional explicit regeneration:
.venv/bin/pipe proxy evidence
```

If preview acceptance passes, repeat with `--final` for the full-quality acceptance film.
