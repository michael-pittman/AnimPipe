# QA: Shot Waves + Final-Film Acceptance

QA evaluates **delivered evidence**, not merely schema validity or the model's confidence.

## Per-shot wave

For all dirty shots in a round:

```text
parallel CPU config/audio preparation
        ↓
parallel deterministic .blend builds
        ↓
one GPU preview render wave
        ↓
parallel CPU delivery-preview/contact-sheet preparation
        ↓
one resident Qwen review wave
        ↓
pass | validated config revision | escalate
        ↓
next round contains revised shots only
```

This avoids repeatedly tearing down/reinitializing Cycles and Ollama for every shot.

### Deterministic checks

- build/config validity and provenance
- expected frame evidence exists
- exact SHA-256 plus perceptual hash/SSIM when a baseline is available
- asset/rig contracts remain valid

### Required observables

`qa.required_observables` converts semantic claims into explicit evidence gates. Every required observable has an ID, description and frame set. The critic must return an `ObservableReview`; missing, invisible, or below-threshold evidence fails the gate even if its generic verdict is `pass`.

Examples used by Proxy acceptance include locomotion progression, visible facial/lip motion, block grab/late hold, stable held block, release placement, camera motion and ending progression. The pointer remains an available asset but is no longer the acceptance interaction fixture.

### VLM scoring

Baseline model: `qwen2.5vl:3b`.

The critic receives a contact sheet sampled from a delivery-style encoded preview, the director intent and QA-relevant resolved configuration. It scores framing, legibility, staging, lighting, continuity and instructional intent independently. It must not infer success solely from config text. `style.*` is not patchable.

A shot passes only when:

- critic verdict is pass;
- mean visual score meets `qa.vision_pass_threshold`; and
- every required observable is visible and meets `qa.observable_pass_threshold`.

Revisions remain allow-listed config-only changes and are bounded by `max_revisions` plus `min_score_improvement`.

## Post-concat final-film QA

After shot segments are encoded and concatenated, `final_film_qa.py` inspects the actual MP4:

1. `ffprobe` verifies stream presence/duration.
2. FFmpeg `freezedetect` runs across the film; frozen intervals crossing shot joins block acceptance.
3. FFmpeg `silencedetect` checks for long interior dead air when audio is expected.
4. Each encoded segment is compared with the authored Blender frame clock for duration and dialogue-audio onset.
5. Concat-relevant stream signatures are compared before accepting the assembled film.
6. Frames are sampled globally and on both sides of every join into `final-film-contact.png`.
7. Qwen reviews transition continuity, caption legibility, prop continuity and overall coherence.

Lip-sync remains primarily a per-shot required-observable check because a transition-focused final-film sheet is not a reliable audio/visual synchronization measurement. Final-film audio gates focus on missing audio, silence and abrupt continuity symptoms.

## Compact evidence

Every QA-enabled proxy acceptance run automatically writes `reports/acceptance/qa_evidence_bundle.zip`. `pipe proxy evidence` remains available to regenerate it or include the final MP4. The bundle contains the compact QA evidence directory, JSON reports, status/environment reports and bounded logs without the full render tree. Use `--include-video` only when a film must travel with the evidence bundle.
