# The Builder

The builder turns validated, fully resolved JSON plus an admitted asset manifest into a generated Blender scene. The `.blend` is a build artifact, never an authoring document.

## Pipeline

```text
assets.yaml ──► pipe asset doctor/export-manifest ──► build/assets.resolved.json
config/*.yaml ─► pipe config compile ──────────────► build/<shot>/resolved_config.json
                                                            │
                                                            ▼
                                     pipe build shot --preview/final
                                                            │
                                                   build/<shot>/scene.blend
                                                   build/<shot>/build_manifest.json
                                                            │
                               verified GPU/VRAM gate ───────┤
                                                            ▼
                                      pipe render frames ───► renders/<shot>/####.png|exr
                                                            │
                                      pipe qa run-loop ──────┤ bounded preview/revise
                                                            │
                                      pipe render encode ───► LUT + captions + overlays
                                                            │
                                                            ▼
                                                      out/<shot>.mp4
```

## Module map

| Module | Responsibility |
|---|---|
| `context.py` | Config access, easing translation, Kelvin→linear RGB, assertion log |
| `assets.py` | Library linking, character/set override hierarchy, path assets, look/dressing overrides |
| `performance.py` | NLA assembly and Blender 5.x slotted-action slot assignment |
| `props.py` | Manifest-backed prop instances plus timed bone attachment/release |
| `camera.py` | Semantic camera templates, subject-relative framing, keyed moves, Follow Path, DOF |
| `stages.py` | Config-defined lighting presets, blocking, facial cues, viseme lip sync, compositor |
| `scene.py` | Blender 5.2 render settings, preview overrides, OptiX setup, pre-save assertions |
| `entrypoint.py` | Orchestration, build report, non-zero exit on failure |
| host `delivery.py` | image-sequence rendering, LUT/captions/overlays, NVENC mux, contact sheets |
| host `qa_loop.py` | single-shot diagnostic preview/revise loop |
| host `qa_wave.py` | multi-shot dirty-set controller: parallel builds, one render wave, one VLM wave |
| host `render_wave.py` | one GPU lock + one Blender process for a shot render wave |
| host `final_film_qa.py` | post-concat stream/freeze/silence/transition acceptance |
| host `qa_evidence.py` | sparse-preview timing remap and delivery-style evidence |

## No third-party imports inside Blender

Blender's bundled Python does not need Pydantic, PyYAML, OmegaConf, HTTP clients, TTS, or orchestration packages. The builder consumes JSON that was already validated host-side:

- `pipe asset export-manifest` validates and emits the JSON asset snapshot.
- `pipe config compile` resolves OmegaConf layers and validates them with Pydantic.
- Blender consumes only those two generated artifacts.

## Blender 5.2.1 contract

The runtime is pinned to Blender 5.2.1 LTS. A VM smoke probe asserts the APIs the builder relies on before production work:

- EEVEE engine identifier `BLENDER_EEVEE`;
- `ImageFormatSettings.media_type = IMAGE` before `file_format`;
- NLA `action_slot` and `action_suitable_slots`;
- Follow Path `offset_factor`, `use_fixed_location`, forward/up axes;
- Cycles render texture-size-limit API (`texture_resolution_render` on Blender 5.2, with compatibility probe);
- background `gpu.init()`.

If a future Blender upgrade breaks one of these, the environment fails before a shot build.

## Slotted actions

Blender 4.4+ Actions are layered/slotted. Assigning an Action to an NLA strip without an appropriate slot can evaluate no animation. `performance.assign_slot` selects a target-compatible slot and the builder asserts that every strip receives one.

`animation_data.action` is cleared before the stack is assembled so a leftover active Action cannot mask the NLA stack.

## Repeat, not scale

A strip whose configured duration exceeds the source Action repeats the Action. It is not silently time-scaled. If a performance must change speed, that must become an explicit contract field rather than an implicit builder behavior.

## Follow Path cameras

`camera.move.type: follow_path` uses a manifest asset of `kind: path`. The asset must name a CURVE object directly or a collection containing exactly one CURVE. The builder links that path read-only, adds a Follow Path constraint, uses Fixed Position, and keys `offset_factor` from `start_factor` to `end_factor` with configured easing. Matching forward/up axes are rejected at config validation.

## Set dressing

Sets remain linked when no mutation is requested. If `set.dressing_overrides` is non-empty, the builder creates a fully editable Library Override for the set hierarchy and applies only the named transform/visibility changes. Source asset files remain untouched.

## Retargeting boundary

Runtime retargeting is intentionally not part of shot assembly. Character assets are admitted after normalization to a named `rig.retarget_profile`; their production Actions must already be native to that normalized rig. `pipe asset doctor` requires the profile and the builder rejects a cast member whose requested profile differs from the admitted profile. This makes animation evaluation deterministic and moves destructive/ambiguous rig conversion out of render time.

## Post-render comp

The Blender compositor owns render-native effects such as configured glow/vignette. Delivery-only effects run in FFmpeg so they can be revised without rerendering Cycles:

- `comp.grade_lut_asset_id` → manifest-resolved `.cube` → `lut3d`;
- enabled burn-in captions → deterministic SRT generated from dialogue frame bounds plus the `subtitles` filter;
- `comp.overlay_slots` → static overlay inputs with configured frame windows, position, width and opacity.

Caption burn-in refuses dialogue without `end_frame`; timing is never guessed.

## GPU gating

The manifest texture-memory assertion is a static early warning only. It is **not** the real admission gate. Every production GPU execution path performs:

1. verified hardware-manifest load;
2. live `nvidia-smi` identity check against GPU UUID/name/total VRAM;
3. configured estimate + reserve check;
4. exclusive GPU lock acquisition;
5. a second live identity/free-VRAM check after acquiring the lock;
6. workload execution.

`render frames`, VLM review, the bounded QA loop, NVENC encode, and any optional GPU TTS profile use that policy. faster-whisper remains CPU/int8 in the supported build.

## Validation assertions

`scene.validate` runs before save and blocks on failure:

- scene has a camera, every cast member resolves, frame range is non-empty;
- no Principled BSDF has an unlinked black Base Color;
- characters with blocking actually carry animation data;
- declared texture weight does not exceed the configured Cycles workload estimate.

Failures are collected so one builder run reports the whole failing set before exiting non-zero.

## Proxy Animation Kit integration

The builder now has a concrete style-neutral acceptance target. `pipe proxy generate` creates reusable assets from `proxy_kit/kit.yaml`; `pipe proxy acceptance` proves those assets through the same build/render/encode path used later for final art. No special Blender scene path exists for the proxy kit.

Key builder extensions:
- `PipelineConfig.style` carries the style contract into resolved JSON and VLM context without allowing the VLM to rewrite style;
- camera templates resolve lens/offset/aim target semantically relative to the framed cast member;
- lighting preset values live in config;
- cast members can schedule validated facial shape-key cues;
- `props` instantiate manifest-backed collection assets and schedule explicit bone attachment/release windows;
- character admission can declare `facial_controls` in addition to normalized rig/actions/visemes.

The proxy character uses rigid bone-parented primitives on purpose. It proves the animation system independently of skinning quality; a deforming production character is a later asset concern, not a prerequisite for pipeline acceptance.

## Previously documented gaps — resolved

| Prior gap | Resolution |
|---|---|
| `follow_path` raised | Path asset contract + Follow Path builder implementation |
| set dressing parsed but ignored | Conditional set Library Override + transform/visibility application |
| LUT/captions/overlays schema-only | Deterministic FFmpeg post-render comp |
| retarget profile had no runtime behavior | Explicit normalization-at-admission contract + doctor/builder enforcement |

There are **no known blocking builder gaps in the source bundle**. Hardware-dependent behavior remains intentionally unclaimed until `scripts/80_smoke_test.sh` passes on the target Azure `Standard_NC4as_T4_v3` VM.

## Delivered-output acceptance

The GPU trial exposed a distinction the original builder checks could not catch: a correct scene/config can still produce a visually wrong delivered interaction. Per-shot QA now declares required visual observables, and a shot cannot pass when the critic omits or fails one even if its generic verdict says pass.

The concatenated MP4 is a separately validated artifact. `final_film_qa.py` checks stream presence, frozen intervals crossing joins, long interior silence, and visual transition continuity. This closes the former pre-concat QA gap.

For the Proxy Kit, shots 6–8 now use the same block across grab → hold → release. Shot 6 separates the one-shot `reach_grab` action from a held pose and uses the block’s semantic `center` grip. This removes the former pointer drift and gives final-film QA a real cross-shot prop-continuity target.
