# Blender Training Pipeline — Operator Runbook

This runbook is the supported path from an Azure T4 host to the deterministic Proxy acceptance film.
The repository contains a Linux provisioning path, but the pipeline runtime itself also supports the already-qualified Windows/TCC Azure host captured in the GPU evidence. Detailed rationale is in `docs/`.

## 1. Choose the host path and qualify the Azure VM

**Fresh Ubuntu/Linux VM:** run the pre-driver hardware gate before changing the GPU stack:

```bash
python3 scripts/00_hardware_preflight.py
```

Do not continue unless `reports/environment/hardware-preflight.json` is `pass`. The Linux provisioning scripts check the Azure SKU/host shape and raw NVIDIA T4 PCI identity before driver installation.

**Existing Windows/TCC Azure host:** do not run the Linux `/proc`/`/sys` preflight or Linux GRID installer. Preserve the working NVIDIA driver and use the existing `reports/environment/hardware-verified.json` plus `scripts/30_verify_gpu.py` from the active Python environment. The runtime gate is the live GPU UUID/name/VRAM and Blender OptiX floor, not a Linux package-version equality check.

## 2. Linux provisioning only: install the host and Microsoft-documented GRID driver

```bash
bash scripts/10_install_base_host.sh
bash scripts/20_install_azure_grid_driver.sh
sudo reboot
```

After reconnecting:

```bash
python3 scripts/30_verify_gpu.py
```

This writes the authoritative GPU UUID/name/VRAM/driver record. Every GPU admission later re-queries `nvidia-smi` and compares the live device to this record. On Windows, use the installed Microsoft/NVIDIA-supported N-series graphics driver path rather than the Linux package command above.

## 3. Install Blender, host Python, audio tooling, MCP, and Claude Code

```bash
bash scripts/40_install_blender.sh
bash scripts/50_install_python_envs.sh
bash scripts/55_install_rhubarb.sh
bash scripts/60_install_official_blender_mcp.sh
bash scripts/65_install_claude_code.sh
bash scripts/66_install_claude_plugins.sh
```

The default host Python environment does not install CUDA development/runtime wheels for
Whisper. Faster-whisper begins CPU-side. There is no host CUDA Toolkit dependency.

Install/enable the official Blender Lab MCP add-on in the **scratch Blender profile only**.
The `.mcp.json` project config supplies the stdio server to Claude Code; only the
`blender-debugger` agent is granted that MCP server.

## 4. Start local AI services

```bash
bash scripts/70_start_local_ai.sh
```

This starts:
- Ollama on `127.0.0.1:11434` with the Azure-proven `qwen2.5vl:3b` baseline for preview/final-film critique.
- Kokoro on `127.0.0.1:8880` for CPU TTS.

The Qwen model is pulled and then unloaded so it does not retain T4 VRAM while idle.

## 5. Run the Phase-0 smoke gate

```bash
bash scripts/80_smoke_test.sh
```

The smoke gate verifies live T4 identity, Docker GPU passthrough, Blender/OptiX, the pinned
Blender 5.2 API contract, NVENC plus LUT/subtitle/overlay filters, Rhubarb, the full Python
test suite, config/schema compilation, local services, skill packaging, and bundle structure.

## 6. Open the project in VS Code

Use **VS Code Remote SSH** and open this repository on the VM. Accept the recommended
extensions from `.vscode/extensions.json`.

Start Claude Code from the repository root:

```bash
claude
```

Project model settings pin Sonnet 4.6. The project agents and skills under `.claude/` are
loaded from the repository.

## 7. Generate and admit the Proxy Animation Kit

Before introducing real art assets, prove the complete production path with the neutral proxy kit:

```bash
.venv/bin/pipe proxy validate
.venv/bin/pipe proxy generate
```

Generation is deterministic from `proxy_kit/kit.yaml`. It creates the proxy mannequin, 20 reusable Actions/poses, nine Rhubarb visemes, facial controls, modular FG/MG/BG set pieces, six interaction props, two camera paths, five graphics overlays, and the manifest used by the normal builder. Blender-side Asset Doctor must pass before the kit is admitted.

Then run the ~50-second acceptance film through the wave scheduler:

```bash
.venv/bin/pipe proxy acceptance --preview --audio --qa
.venv/bin/pipe proxy evidence
```

On Windows PowerShell use the equivalent `.\.venv\Scripts\pipe.exe ...` entry point. Visual QA is enabled by default. Add `--no-qa` only when isolating a build/render failure; it is not the acceptance criterion. The acceptance path fans out CPU preparation/build work, renders dirty shots in one GPU wave, reviews them in one resident-VLM wave, and re-enters only revised shots. After concat, the final MP4 must pass deterministic and visual film-level QA. The ten shots deliberately exercise locomotion, NLA layering, facial cues, visemes, captions/overlays, FG/MG/BG staging, prop attach/release, Follow Path camera movement, lighting presets and final delivery. Generated proxy assets are build artifacts and remain ignored by Git.

See `docs/PROXY_ANIMATION_KIT.md` for the complete vocabulary and acceptance contract.

## 8. Compile the example director scene + shot

```bash
.venv/bin/pipe config validate-scene config/scene/module_01.yaml
.venv/bin/pipe config compile \
  config/base.yaml \
  config/project.yaml \
  config/scene/module_01.yaml \
  config/shot/m01_s030.yaml \
  -o build/m01_s030/resolved_config.json
```

The JSON output, not the layered YAML, is the Blender build contract.

## 9. Admit real assets before shot authoring

Copy `assets/assets.yaml.example` to `assets/assets.yaml`, populate logical asset IDs, then:

```bash
.venv/bin/pipe asset doctor char.instructor_a
.venv/bin/pipe asset doctor char.instructor_a --blender
```

Do not work around a failed rig/action/viseme contract in shot code.

## 10. Exercise the deterministic Blender entry point

Once assets pass admission, export the manifest and use the host wrapper:

```bash
.venv/bin/pipe asset export-manifest --manifest assets/assets.yaml -o build/assets.resolved.json
.venv/bin/pipe build shot \
  --config build/m01_s030/resolved_config.json \
  --manifest build/assets.resolved.json \
  --output build/m01_s030/scene.blend \
  --preview
```

Production build commands never use MCP.

## 11. GPU workload rule

Any Cycles render, Ollama vision review, optional GPU Kokoro job, or NVENC delivery task
must run through the host GPU lock/admission policy. Example for a custom command:

```bash
.venv/bin/pipe gpu run cycles-final 12000 -- blender --background ...
```

The configured workload estimates live in `resource_policy.gpu.workloads`; prefer those over
ad-hoc estimates in orchestration code.

## 12. Preview QA loop

The preferred path is the bounded controller, not manual iteration:

```bash
.venv/bin/pipe qa run-loop \
  --config build/m01_s030/resolved_config.json \
  --intent config/scene/module_01.yaml \
  --asset-manifest build/assets.resolved.json \
  --work-dir reports/qa/m01_s030
```

The controller rebuilds a preview, acquires the `cycles_preview` GPU gate, renders configured
beat frames, generates a contact sheet, acquires the `vision_qa` gate, asks the configured Qwen VLM for the
schema-constrained review, validates allow-listed config changes, and repeats. It terminates
on pass, explicit escalation, insufficient score improvement, build failure, or revision cap.

`pipe qa review-iteration` remains available for diagnostics, but production orchestration should
use `qa run-loop`. Human approval remains the final policy gate before final render/publish.

## 13. Acceptance evidence and performance telemetry

Every QA-enabled acceptance run writes stage timings to `build/proxy_acceptance/acceptance_report.json` and wave timings to the QA wave report. Tune worker counts only from this measured breakdown; on the single T4, do not overlap Cycles/OptiX with VLM compute.

QA-enabled acceptance now creates the compact review handoff automatically. Regenerate or expand it when needed:

```bash
.venv/bin/pipe proxy evidence
# For a one-time review handoff that also needs the final MP4:
.venv/bin/pipe proxy evidence --include-video
```

The evidence bundle contains per-shot contact sheets/reviews, final-film transition evidence, deterministic stream-signature/duration/audio-onset/freeze/silence checks, environment reports, acceptance metadata, and bounded-size text logs. It exists specifically so a slim source handoff cannot accidentally omit the pixels used for QA.

## 14. MCP debugging rule

Copy a generated blend into scratch space and inspect that copy with `blender-debugger`.
Never turn a mutated MCP scratch scene into a deliverable. The debugger returns a config/code
patch proposal; the builder then recreates the scene cleanly.

## 15. Audio and lip sync

```bash
.venv/bin/pipe audio synthesize "Welcome to the module." -o scratch/audio/line.wav
.venv/bin/pipe audio align scratch/audio/line.wav -o scratch/audio/line.words.json
.venv/bin/pipe audio visemes scratch/audio/line.wav -o scratch/audio/line.visemes.json
```

Alignment is CPU/int8 in the supported build. No CUDA toolkit or CUDA Python runtime is installed for faster-whisper.

## 16. Final render and publish

```bash
.venv/bin/pipe render frames build/m01_s030/scene.blend \
  --config build/m01_s030/resolved_config.json \
  -o renders/m01_s030

.venv/bin/pipe render encode renders/m01_s030 \
  --config build/m01_s030/resolved_config.json \
  -o out/m01_s030.mp4
```

`render frames` cannot bypass the verified GPU/VRAM gate. NVENC encode acquires the same
exclusive GPU scheduler. `render encode` applies configured LUT, burn-in captions and overlay
slots without rerendering Cycles.

Persist config hash,
git SHA, asset fingerprints, Blender/GPU identity, model/provider versions, image comparison
metrics, and final encoding settings in the run manifest.
