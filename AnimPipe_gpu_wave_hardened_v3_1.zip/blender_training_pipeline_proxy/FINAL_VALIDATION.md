# GPU Wave Hardening v3 Validation — 2026-09-21

Package version: **0.6.1**  
Global contract schema: **1.0.1**  
Source evidence commit: `00e780a8482367ef1d7a64143a4264db552006f1`

This revision incorporates the real Azure/T4 findings and hardens the Proxy Animation Kit for efficient single-GPU execution and truthful delivered-output QA.

## Azure evidence incorporated

The supplied reports establish the expected `Standard_NC4as_T4_v3`, one Tesla T4 with 16384 MiB, Blender 5.2.1 API-contract success, Proxy Kit generation/deep character admission, and execution of all ten per-shot QA paths. They do **not** establish final delivery acceptance: the previous critic assigned every scored dimension of every shot exactly 0.90 while delivered-output review separately documented a shot-6 prop-continuity defect.

Central-directory inspection of the exact commit-pinned slim ZIP found only `build/.gitkeep` and `logs/.gitkeep`; the generated MP4, `.blend`, audio, frames, contact sheets and runtime logs are not present in that committed archive. The old machine-readable report is therefore treated as execution evidence, not independent visual sign-off.

## v3 hardening implemented

- CPU-parallel config/TTS/build preparation with a single exclusive T4 compute lane.
- Long Blender/Cycles render waves and resident Ollama/Qwen review waves; revised shots alone repeat.
- Live GPU identity/VRAM admission with post-unload wait/poll so the next workload does not assume model memory disappeared synchronously.
- Ollama pre-warm once per review wave and guaranteed model unload in `finally` paths.
- Required visual observables force their authored frame numbers into QA evidence; generic VLM confidence cannot override missing evidence.
- Per-dimension and observable score floors prevent the uniform-score false-positive seen in the previous Azure report.
- Shots 6–8 use a stable block grab/hold/release fixture with asset-authored grip transforms; the pointer remains available but is not the acceptance continuity fixture.
- Audio, visemes, captions and overlays share the Blender `frame_start` clock. TTS is delayed to authored dialogue onset and narration overflow is rejected.
- TTS/viseme caching avoids regenerating unchanged speech artifacts.
- Final-film QA checks stream signatures, segment duration, dialogue audio onset, freeze intervals crossing joins, interior silence and transition-focused delivered-pixel review.
- Stage telemetry records preparation, shot QA, accepted builds, render, encode, concat and final-film QA time.
- QA-enabled acceptance automatically writes a compact `qa_evidence_bundle.zip`; full reproducible render trees remain outside source releases.
- Release packaging excludes runtime media, caches, machine-local secrets and stale runtime reports, and generates a fresh SHA-256 manifest for exactly the packaged files.
- Runtime qualification is OS-aware. The existing evidence is Windows/TCC; Linux GRID package guidance remains a provisioning path rather than an equality requirement for Windows acceptance.
- CPU-only GitHub Actions source CI now catches schema/skill/test/lint/type/compile regressions before Azure GPU acceptance.

## Source validation

- Pytest: **66 passed / 0 failed**.
- Bundle validator: **PASS**.
- Claude project: **10 agents / 21 active skills**, all within the project skill-size limit.
- Generated `.skill` packages: **21**.
- Pydantic JSON schemas: regenerated after contract patch bump.
- Python compile checks: **PASS**.
- Shell script `bash -n`: **PASS**.
- Ruff/mypy: not installed in this packaging environment; the Azure VM dev/bootstrap environment remains responsible for these gates.

## Acceptance state

**Source hardened; Azure rerun required for delivered acceptance.**

The next Azure execution must regenerate the assets/film from this revision and pass both the per-shot observable gates and the post-concat final-film gate. A QA-enabled run will automatically emit `reports/acceptance/qa_evidence_bundle.zip` for independent visual review.
