# Claude Code Project Instructions — Blender Training Video Pipeline

## Mission
Build short instructional animations deterministically from validated configuration. The source of truth is text config + admitted assets + code. `.blend`, renders, audio cues, and videos are generated artifacts.

## Non-negotiable invariants

1. Use **OmegaConf**, not Hydra, for initial config layering: `base < project < scene < shot < CLI`.
2. Validate the fully resolved object with **Pydantic v2**, then emit immutable `resolved_config.json` plus a SHA-256 hash.
3. Production Blender receives resolved JSON only. Do not import OmegaConf, TTS, Ollama, or orchestration libraries into Blender's embedded Python.
4. No magic production values in builder code. Values come from the resolved config or asset contract.
5. Assets are referenced only by logical IDs from `assets/assets.yaml`.
6. Character performance composes named NLA actions; do not author bespoke raw performance keyframes when a vocabulary action exists.
6a. Proxy/future generated assets follow a style contract and asset spec. Generated `.blend` files are rebuildable outputs, never the editable source of truth.
7. The official Blender MCP is **inspection/debug only**. It must operate on a scratch copy, never the canonical repo build artifact.
8. Do not use MCP-generated scene mutations as deliverables. Diagnose, propose a patch, then modify config/builder code and rebuild.
9. Never assume the GPU. Before GPU work, require `reports/environment/hardware-verified.json` and confirm the live GPU UUID still matches it.
10. Acquire the host GPU lock before Cycles/OptiX, Ollama VLM inference, GPU faster-whisper, or optional GPU TTS.
11. There is **no host CUDA Toolkit dependency**. Do not install `cuda-toolkit`, `nvidia-cuda-toolkit`, or `nvcc`. Driver/runtime libraries inside a container or Python wheel are acceptable when required by that workload.
12. Render final output to EXR/PNG image sequences, never directly to video. FFmpeg/NVENC performs mux/encode.
13. Every QA revision is a **config-only proposal**. A vision model must never patch `bpy` builder code.
14. Cap automated preview-revise iterations; default policy is in config.
15. Use structured handoffs and preserve provenance hashes.

## Runtime boundaries

- Host pipeline: Python 3.11
- `bpy` integration test env: Python 3.13 + `bpy==5.2.1`
- Production Blender: Blender 5.2.1 embedded Python 3.13
- Local visual QA: Docker Ollama, `qwen2.5vl:3b` Azure/T4-proven default
- TTS: Docker Kokoro CPU default; GPU profile optional

## Agent routing

- architecture/schema: `pipeline-architect`
- VM/bootstrap/hardware: `environment-bootstrapper`
- asset creation/regeneration: `asset-factory`
- asset admission: `asset-validator`
- instructional/creative config: `animation-director`
- deterministic bpy code: `blender-builder`
- speech/visemes: `audio-lipsync-engineer`
- live Blender diagnosis: `blender-debugger`
- render/semantic QA: `render-qa`
- safe execution/publishing: `pipeline-runner`

Do not load every skill into every agent. Each agent is intentionally scoped to a small set of skills.

## Parallel integration fan-out

For acceptance/integration work, the **main Claude Code session** is the orchestrator. Fan out independent read/audit tasks first, then serialize overlapping mutations. Use this default lane map:

1. `pipeline-architect` — contracts/schema/orchestration invariants.
2. `environment-bootstrapper` + `pipeline-runner` — hardware, driver, GPU admission and stage telemetry.
3. `blender-builder` + `asset-validator` — generated assets, NLA/props/camera/Blender runtime correctness.
4. `audio-lipsync-engineer` — TTS cache, dialogue clock, Rhubarb and A/V timing.
5. `render-qa` — per-shot observable gates, final-film QA and evidence calibration.
6. `animation-director` — acceptance-shot continuity and whether observable requirements actually prove the intended animation vocabulary.

Do not let parallel agents edit the same files concurrently. Read-only audits may run together; the main session assigns each accepted patch to one owning agent and then reruns affected tests. `blender-debugger` is invoked only after static evidence cannot explain a Blender failure.

Single-T4 optimization rule: parallelize CPU preparation/build/evidence work, but keep Cycles/OptiX and VLM inference in separate long GPU waves. Do not increase Ollama parallelism or overlap GPU compute merely to create apparent concurrency.
